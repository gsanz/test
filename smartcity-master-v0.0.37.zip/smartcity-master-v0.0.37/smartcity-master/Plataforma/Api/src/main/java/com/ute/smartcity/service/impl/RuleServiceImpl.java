package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.Rule;
import com.ute.smartcity.domain.RuleCompareFields;
import com.ute.smartcity.repository.RuleActionRepository;
import com.ute.smartcity.repository.RuleCompareFieldsRepository;
import com.ute.smartcity.repository.RuleRepository;
import com.ute.smartcity.repository.RuleUpdateFieldsRepository;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.service.platform.fiware.FiwarePerseoService;
import com.ute.smartcity.service.dto.DeviceTypeDTO;
import com.ute.smartcity.service.dto.RuleActionDTO;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.mapper.FiwareRuleMapper;
import com.ute.smartcity.service.mapper.RuleMapper;
import com.ute.smartcity.service.platform.fiware.FiwarePerseoService;
import net.minidev.json.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing Rule.
 */
@Service
@Transactional
public class RuleServiceImpl implements RuleService {

    private final Logger log = LoggerFactory.getLogger(RuleServiceImpl.class);

    private final RuleRepository ruleRepository;

    private final RuleCompareFieldsService ruleCompareFieldsService;

    private final RuleActionService ruleActionService;

    private final DeviceTypeService deviceTypeService;

    private final RuleUpdateFieldsService ruleUpdateFieldsService;

    private final FiwarePerseoService fiwarePerseoService;

    private final RuleMapper ruleMapper;

    private final FiwareRuleMapper fiwareRuleMapper;

    public RuleServiceImpl(RuleRepository ruleRepository,
                           RuleCompareFieldsService ruleCompareFieldsService,
                           RuleActionService ruleActionService,
                           DeviceTypeService deviceTypeService,
                           RuleUpdateFieldsService ruleUpdateFieldsService,
                           FiwarePerseoService fiwarePerseoService,
                           RuleMapper ruleMapper, FiwareRuleMapper fiwareRuleMapper) {
        this.ruleRepository = ruleRepository;
        this.ruleCompareFieldsService = ruleCompareFieldsService;
        this.ruleActionService = ruleActionService;
        this.deviceTypeService = deviceTypeService;
        this.ruleUpdateFieldsService = ruleUpdateFieldsService;
        this.fiwarePerseoService = fiwarePerseoService;
        this.ruleMapper = ruleMapper;
        this.fiwareRuleMapper = fiwareRuleMapper;
    }

    /**
     * Save a rule.
     *
     * @param ruleDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public RuleDTO save(RuleDTO ruleDTO) throws ParseException, PlatformException {
        log.debug("Request to save Rule : {}", ruleDTO);

        String json = fiwareRuleMapper.toString(ruleDTO,false); // Transforma los datos a JSON (string)
        fiwarePerseoService.addRule(json,ruleDTO.getDeviceTypeReference());

        final Rule rule = ruleMapper.toEntity(ruleDTO);
        boolean ruleExists = (rule.getId()!=null);

        //Delete actual RuleCompareFields
        List<RuleCompareFields> actualRuleCompareFields = ruleCompareFieldsService.findByRuleId(rule.getId());

        actualRuleCompareFields.forEach(item -> {
            ruleCompareFieldsService.delete(item.getId());
            //ruleCompareFieldsService.
        });
        rule.setRuleCompareFields(null);
        ruleRepository.save(rule);

        //Save New RuleCompareFields
        ruleDTO.getRuleCompareFields().forEach(ruleCompareFieldsDTO -> {
            ruleCompareFieldsDTO.setRuleId(rule.getId());
            ruleCompareFieldsService.save(ruleCompareFieldsDTO);
        });

        ruleDTO.getRuleActions().forEach((ruleActionDTO -> {
            ruleActionDTO.setRuleId(rule.getId());
            RuleActionDTO ruleActionDTONew = ruleActionService.save(ruleActionDTO);
            ruleActionDTO.getRuleUpdateFields().forEach(ruleUpdateFieldsDTO -> {
                    ruleUpdateFieldsDTO.setRuleActionId(ruleActionDTONew.getId());
                    ruleUpdateFieldsService.save(ruleUpdateFieldsDTO);
                });
        }));

        if (ruleExists) {

            Optional<DeviceTypeDTO> deviceTypeDTO = deviceTypeService.findOne(ruleDTO.getDeviceTypeId());

            String reference = ruleDTO.getReference();
            if(deviceTypeDTO.isPresent()) {
                String servicepath = deviceTypeDTO.get().getReference();
                deleteFromFiware(reference, servicepath);
            }
        }
        return ruleMapper.toDto(rule);
    }

    /**
     * Get all the rules.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<RuleDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Rules");
        return ruleRepository.findAll(pageable)
            .map(ruleMapper::toDto);
    }

    /**
     * Get all the Rule with eager load of many-to-many relationships.
     *
     * @return the list of entities
     */
    public Page<RuleDTO> findAllWithEagerRelationships(Pageable pageable) {
        return ruleRepository.findAllWithEagerRelationships(pageable).map(ruleMapper::toDto);
    }


    /**
     * Get one rule by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<RuleDTO> findOne(Long id) {
        log.debug("Request to get Rule : {}", id);
        return ruleRepository.findOneWithEagerRelationships(id)
            .map(ruleMapper::toDto);
    }

    /**
     * Delete the rule by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) throws PlatformException {
        log.debug("Request to delete Rule : {}", id);
        Optional<RuleDTO> ruleDTOOptional = findOne(id);
        if (ruleDTOOptional.isPresent()) {
            RuleDTO ruleDTO = ruleDTOOptional.get();

            Optional<DeviceTypeDTO> deviceTypeDTO = deviceTypeService.findOne(ruleDTO.getDeviceTypeId());
            String reference = ruleDTO.getReference();
            if(deviceTypeDTO.isPresent()) {
                String servicepath = deviceTypeDTO.get().getReference();
                deleteFromFiware(reference, servicepath);
            }
        }


        ruleRepository.deleteById(id);
    }

    @Override
    public Optional<RuleDTO> findByReference(String rule) {
        return ruleRepository.findByReference(rule).map(ruleMapper::toDto);
    }

    @Override
    public Optional<List<RuleDTO>> findByDevice(Device device) {
        return ruleRepository.findByDevices(device).map(ruleMapper::toDto);
    }

    @Override
    public Optional<List<RuleDTO>> findByDeviceType(Long id) {
        return ruleRepository.findByDeviceTypeId(id).map(ruleMapper::toDto);
    }

    /**
     * Delete the rule by id.
     *
     * @param ruleName the rule name
     */

    public void deleteFromFiware(String ruleName,String servicePath) throws PlatformException {
        log.debug("Request to delete Rule from fiware : {}", ruleName);
        /*Long deviceTypeId = ruleDTO.get().getDeviceTypeId();
        Optional<DeviceTypeDTO> deviceTypeDTO = deviceTypeService.findOne(deviceTypeId);

        String reference = ruleDTO.get().getReference();
        String servicepath = deviceTypeDTO.get().getReference();*/

        fiwarePerseoService.deleteRule(ruleName, servicePath);
    }

}

package com.ute.smartcity.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.ute.smartcity.domain.enumeration.TipoCambio;

/**
 * The Auditoria entity.
 * @author javi.jimenez
 */
@ApiModel(description = "The Auditoria entity. @author javi.jimenez")
@Entity
@Table(name = "auditoria")
public class Auditoria implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    /**
     * entidadNombre
     */
    @NotNull
    @Size(max = 250)
    @ApiModelProperty(value = "entidadNombre", required = true)
    @Column(name = "entity_name", length = 250, nullable = false)
    private String entityName;

    /**
     * usuarioLogin
     */
    @NotNull
    @Size(max = 250)
    @ApiModelProperty(value = "usuarioLogin", required = true)
    @Column(name = "usuario_login", length = 250, nullable = false)
    private String usuarioLogin;

    /**
     * tipoCambio
     */
    @NotNull
    @ApiModelProperty(value = "tipoCambio", required = true)
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_cambio", nullable = false)
    private TipoCambio tipoCambio;

    /**
     * fecha
     */
    @NotNull
    @ApiModelProperty(value = "fecha", required = true)
    @Column(name = "jhi_date", nullable = false)
    private Instant date;

    /**
     * entidadId
     */
    @ApiModelProperty(value = "entidadId")
    @Column(name = "entity_id")
    private Integer entityId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEntityName() {
        return entityName;
    }

    public Auditoria entityName(String entityName) {
        this.entityName = entityName;
        return this;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getUsuarioLogin() {
        return usuarioLogin;
    }

    public Auditoria usuarioLogin(String usuarioLogin) {
        this.usuarioLogin = usuarioLogin;
        return this;
    }

    public void setUsuarioLogin(String usuarioLogin) {
        this.usuarioLogin = usuarioLogin;
    }

    public TipoCambio getTipoCambio() {
        return tipoCambio;
    }

    public Auditoria tipoCambio(TipoCambio tipoCambio) {
        this.tipoCambio = tipoCambio;
        return this;
    }

    public void setTipoCambio(TipoCambio tipoCambio) {
        this.tipoCambio = tipoCambio;
    }

    public Instant getDate() {
        return date;
    }

    public Auditoria date(Instant date) {
        this.date = date;
        return this;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public Integer getEntityId() {
        return entityId;
    }

    public Auditoria entityId(Integer entityId) {
        this.entityId = entityId;
        return this;
    }

    public void setEntityId(Integer entityId) {
        this.entityId = entityId;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Auditoria auditoria = (Auditoria) o;
        if (auditoria.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), auditoria.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Auditoria{" +
            "id=" + getId() +
            ", entityName='" + getEntityName() + "'" +
            ", usuarioLogin='" + getUsuarioLogin() + "'" +
            ", tipoCambio='" + getTipoCambio() + "'" +
            ", date='" + getDate() + "'" +
            ", entityId=" + getEntityId() +
            "}";
    }
}

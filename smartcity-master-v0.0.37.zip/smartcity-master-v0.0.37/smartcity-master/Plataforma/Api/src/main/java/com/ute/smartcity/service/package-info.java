/**
 * Service layer beans.
 */
package com.ute.smartcity.service;

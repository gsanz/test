package com.ute.smartcity.service.dto;

import io.swagger.annotations.ApiModel;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Lob;

/**
 * A DTO for the Usuario entity.
 */
@ApiModel(description = "The Usuario entity. @author hector.fornes")
public class UsuarioDTO implements Serializable {

    private Long id;

    @NotNull
    @Size(min = 9, max = 50)
    private String phone;

    @NotNull
    private Boolean doubleFactorAuthentication;

    @Lob
    private byte[] image;
    private String imageContentType;

    private ZonedDateTime lastPasswordDate;

    private Long userId;

    private UserDTO user;

    private Set<DeviceTypeDTO> devicesTypes = new HashSet<>();

    private String doubleAuthKey;

    private ZonedDateTime createAtDoubleAuthKey;

    private Integer numberAttemptsDoubleAuth;

    private Long providerId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Boolean isDoubleFactorAuthentication() {
        return doubleFactorAuthentication;
    }

    public void setDoubleFactorAuthentication(Boolean doubleFactorAuthentication) {
        this.doubleFactorAuthentication = doubleFactorAuthentication;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getImageContentType() {
        return imageContentType;
    }

    public void setImageContentType(String imageContentType) {
        this.imageContentType = imageContentType;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public Set<DeviceTypeDTO> getDevicesTypes() {
        return devicesTypes;
    }

    public void setDevicesTypes(Set<DeviceTypeDTO> deviceTypes) {
        this.devicesTypes = deviceTypes;
    }

    public String getDoubleAuthKey() {
        return doubleAuthKey;
    }

    public void setDoubleAuthKey(String doubleAuthKey) {
        this.doubleAuthKey = doubleAuthKey;
    }

    public ZonedDateTime getCreateAtDoubleAuthKey() {
        return createAtDoubleAuthKey;
    }

    public void setCreateAtDoubleAuthKey(ZonedDateTime createAtDoubleAuthKey) {
        this.createAtDoubleAuthKey = createAtDoubleAuthKey;
    }

    public Integer getNumberAttemptsDoubleAuth() {
        return numberAttemptsDoubleAuth;
    }

    public void setNumberAttemptsDoubleAuth(Integer numberAttemptsDoubleAuth) {
        this.numberAttemptsDoubleAuth = numberAttemptsDoubleAuth;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UsuarioDTO usuarioDTO = (UsuarioDTO) o;
        if (usuarioDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), usuarioDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "UsuarioDTO{" +
            "id=" + getId() +
            ", phone='" + getPhone() + "'" +
            ", doubleFactorAuthentication='" + isDoubleFactorAuthentication() + "'" +
            ", image='" + getImage() + "'" +
            ", doubleAuthKey='" + getDoubleAuthKey() + "'" +
            ", createAtDoubleAuthKey='" + getCreateAtDoubleAuthKey() + "'" +
            ", numberAttemptsDoubleAuth=" + getNumberAttemptsDoubleAuth() +
            ", lastPasswordDate='" + getLastPasswordDate() + "'" +
            ", user=" + getUserId() +
            ", provider=" + getProviderId() +
            "}";
    }

    public ZonedDateTime getLastPasswordDate() {
        return lastPasswordDate;
    }

    public void setLastPasswordDate(ZonedDateTime lastPasswordDate) {
        this.lastPasswordDate = lastPasswordDate;
    }

    public Long getProviderId() {
        return providerId;
    }

    public void setProviderId(Long providerId) {
        this.providerId = providerId;
    }
}

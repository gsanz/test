package com.ute.smartcity.web.rest;

import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.ZoneQueryService;
import com.ute.smartcity.service.ZoneService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.ZoneCriteria;
import com.ute.smartcity.service.dto.ZoneDTO;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Zone.
 */
@RestController
@RequestMapping("/api")
public class ZoneResourceExt {

    private final Logger log = LoggerFactory.getLogger(ZoneResourceExt.class);

    private static final String ENTITY_NAME = "zone";

    private final ZoneService zoneService;

    private final ZoneQueryService zoneQueryService;

    public ZoneResourceExt(ZoneService zoneService, ZoneQueryService zoneQueryService) {
        this.zoneService = zoneService;
        this.zoneQueryService = zoneQueryService;
    }

    /**
     * POST  /zones : Create a new zone.
     *
     * @param zoneDTO the zoneDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new zoneDTO, or with status 400 (Bad Request) if the zone has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/zones")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<ZoneDTO> createZone(@Valid @RequestBody ZoneDTO zoneDTO) throws URISyntaxException {
        log.debug("REST request to save Zone : {}", zoneDTO);
        if (zoneDTO.getId() != null) {
            throw new BadRequestAlertException("A new zone cannot already have an ID", ENTITY_NAME, "idexists");
        }
        String name = zoneDTO.getName().trim();
        if(zoneDTO.getName() == null || zoneDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("The field name is required", ENTITY_NAME, "noname");
        }
        String reference = zoneDTO.getReference().trim();
        if(zoneDTO.getReference() == null || zoneDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("The field reference is required", ENTITY_NAME, "noreference");
        }
        ZoneDTO result = zoneService.save(zoneDTO);
        return ResponseEntity.created(new URI("/api/zones/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /zones : Updates an existing zone.
     *
     * @param zoneDTO the zoneDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated zoneDTO,
     * or with status 400 (Bad Request) if the zoneDTO is not valid,
     * or with status 500 (Internal Server Error) if the zoneDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/zones")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<ZoneDTO> updateZone(@Valid @RequestBody ZoneDTO zoneDTO) throws URISyntaxException {
        log.debug("REST request to update Zone : {}", zoneDTO);
        if (zoneDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String name = zoneDTO.getName().trim();
        if(zoneDTO.getName() == null || zoneDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("The field name is required", ENTITY_NAME, "noname");
        }
        String reference = zoneDTO.getReference().trim();
        if(zoneDTO.getReference() == null || zoneDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("The field reference is required", ENTITY_NAME, "noreference");
        }
        ZoneDTO result = zoneService.save(zoneDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, zoneDTO.getId().toString()))
            .body(result);
    }
}

package com.ute.smartcity.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.ute.smartcity.domain.SubscriptionTemplate;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.SubscriptionTemplateRepository;
import com.ute.smartcity.service.dto.SubscriptionTemplateCriteria;
import com.ute.smartcity.service.dto.SubscriptionTemplateDTO;
import com.ute.smartcity.service.mapper.SubscriptionTemplateMapper;

/**
 * Service for executing complex queries for SubscriptionTemplate entities in the database.
 * The main input is a {@link SubscriptionTemplateCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link SubscriptionTemplateDTO} or a {@link Page} of {@link SubscriptionTemplateDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class SubscriptionTemplateQueryService extends QueryService<SubscriptionTemplate> {

    private final Logger log = LoggerFactory.getLogger(SubscriptionTemplateQueryService.class);

    private final SubscriptionTemplateRepository subscriptionTemplateRepository;

    private final SubscriptionTemplateMapper subscriptionTemplateMapper;

    public SubscriptionTemplateQueryService(SubscriptionTemplateRepository subscriptionTemplateRepository, SubscriptionTemplateMapper subscriptionTemplateMapper) {
        this.subscriptionTemplateRepository = subscriptionTemplateRepository;
        this.subscriptionTemplateMapper = subscriptionTemplateMapper;
    }

    /**
     * Return a {@link List} of {@link SubscriptionTemplateDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<SubscriptionTemplateDTO> findByCriteria(SubscriptionTemplateCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<SubscriptionTemplate> specification = createSpecification(criteria);
        return subscriptionTemplateMapper.toDto(subscriptionTemplateRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link SubscriptionTemplateDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<SubscriptionTemplateDTO> findByCriteria(SubscriptionTemplateCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<SubscriptionTemplate> specification = createSpecification(criteria);
        return subscriptionTemplateRepository.findAll(specification, page)
            .map(subscriptionTemplateMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(SubscriptionTemplateCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<SubscriptionTemplate> specification = createSpecification(criteria);
        return subscriptionTemplateRepository.count(specification);
    }

    /**
     * Function to convert SubscriptionTemplateCriteria to a {@link Specification}
     */
    private Specification<SubscriptionTemplate> createSpecification(SubscriptionTemplateCriteria criteria) {
        Specification<SubscriptionTemplate> specification = Specification.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildSpecification(criteria.getId(), SubscriptionTemplate_.id));
            }
            if (criteria.getName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getName(), SubscriptionTemplate_.name));
            }
            if (criteria.getDescription() != null) {
                specification = specification.and(buildStringSpecification(criteria.getDescription(), SubscriptionTemplate_.description));
            }
            if (criteria.getEndpoint() != null) {
                specification = specification.and(buildStringSpecification(criteria.getEndpoint(), SubscriptionTemplate_.endpoint));
            }
        }
        return specification;
    }
}

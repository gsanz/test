package com.ute.smartcity.web.rest;

import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.DataModelCriteria;
import com.ute.smartcity.service.dto.DataModelDTO;
import com.ute.smartcity.service.dto.DeviceTypeCriteria;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing DeviceType.
 */
@RestController
@RequestMapping("/api")

public class DataModelsResourceExt {

    private final Logger log = LoggerFactory.getLogger(DataModelsResourceExt.class);

    private static final String ENTITY_NAME = "deviceType";

    private final DeviceTypeService deviceTypeService;

    private final DataModelQueryService dataModelQueryService;


    public DataModelsResourceExt(DeviceTypeService deviceTypeService, DataModelQueryService deviceTypeQueryService) {
        this.deviceTypeService = deviceTypeService;
        this.dataModelQueryService = deviceTypeQueryService;

    }

    /**
     * GET  /device-types : get all the deviceTypes.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of deviceTypes in body
     */
    @GetMapping("/datamodels")
     public ResponseEntity<List<DataModelDTO>> getAllDeviceTypes(DataModelCriteria criteria, Pageable pageable) {
        log.debug("REST request to get DeviceTypes by criteria: {}", criteria);

        Page<DataModelDTO> page = dataModelQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/device-types");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }


}

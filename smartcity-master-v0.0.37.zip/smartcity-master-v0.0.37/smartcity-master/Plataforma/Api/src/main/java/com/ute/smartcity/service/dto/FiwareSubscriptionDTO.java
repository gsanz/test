package com.ute.smartcity.service.dto;

import com.ute.smartcity.domain.enumeration.EvaluationType;
import com.ute.smartcity.domain.enumeration.LevelRule;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * A DTO for the subscription entity.
 */
public class FiwareSubscriptionDTO implements Serializable {

    private String description;

    private String idPattern;

    private String type;

    private String condition;

    private String url;

    private String  attrsFormat;

    private String throttling;

    public String getServicepath() {
        return servicepath;
    }

    public void setServicepath(String servicepath) {
        this.servicepath = servicepath;
    }

    private String servicepath;


    private String subject;

    private String notification;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIdPattern() {
        return idPattern;
    }

    public void setIdPattern(String idPattern) {
        this.idPattern = idPattern;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAttrsFormat() {
        return attrsFormat;
    }

    public void setAttrsFormat(String attrsFormat) {
        this.attrsFormat = attrsFormat;
    }

    public String getThrottling() {
        return throttling;
    }

    public void setThrottling(String throttling) {
        this.throttling = throttling;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getNotification() {
        return notification;
    }

    public void setNotification(String notification) {
        this.notification = notification;
    }
}

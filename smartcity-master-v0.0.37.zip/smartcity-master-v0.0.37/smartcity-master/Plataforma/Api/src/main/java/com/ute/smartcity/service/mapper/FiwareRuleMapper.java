package com.ute.smartcity.service.mapper;


import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ute.smartcity.service.dto.RuleActionDTO;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import net.minidev.json.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class FiwareRuleMapper {
    private static final String ENTITY_NAME = "rule";

    private final Logger log = LoggerFactory.getLogger(FiwareRuleMapper.class);

    public String toString(RuleDTO ruleDTO , Boolean update) throws ParseException {
        JsonObject jsonObjSend = new JsonObject();
        JsonArray actions = new JsonArray();
        JsonObject action = new  JsonObject();

        Set<RuleActionDTO> ruleActions = ruleDTO.getRuleActions();
        boolean hasActions =  (ruleActions.size()>0);
        if (hasActions) {
            RuleActionDTO ruleActionDTO = ruleActions.iterator().next();
            JsonParser parser = new JsonParser();
            Boolean isTypePost = false;
            if (ruleActionDTO.getPostParameters() != null){
                isTypePost = !ruleActionDTO.getPostParameters().isEmpty();
            }
            if (isTypePost) {
                action.addProperty("type", "post");

                JsonObject parameters = parser.parse(ruleActionDTO.getPostParameters()).getAsJsonObject();

                JsonObject jsonParameters = parameters.getAsJsonObject("json");

                try {
                    Boolean idNotExits = jsonParameters.get("id").isJsonNull();
                    Boolean ruleNameNotExists = jsonParameters.get("rule").isJsonNull();
                    Boolean levelNotExits = jsonParameters.get("level").isJsonNull();

                    if (idNotExits && ruleNameNotExists && levelNotExits){
                        throw new Exception("id, level and rulename are mandatory ");
                    }

                    action.add("parameters", parameters);
                    actions.add(action);
                } catch (Exception e) {
                    throw new BadRequestAlertException("id, level and rulename are mandatory ", ENTITY_NAME, "noRulenameOrID");
                }

            }

        }

        jsonObjSend.addProperty("name", ruleDTO.getReference());
        jsonObjSend.addProperty("text", ruleDTO.getTextEPL());
        jsonObjSend.add("action",actions);

        return jsonObjSend.toString().replaceAll("\\\\n", " ").replaceAll("\\\\t", " ");
    }
}

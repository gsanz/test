package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.DeviceTypeDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity DeviceType and its DTO DeviceTypeDTO.
 */
@Mapper(componentModel = "spring", uses = {FieldsMapper.class})
public interface DeviceTypeMapper extends EntityMapper<DeviceTypeDTO, DeviceType> {


    @Mapping(target = "fields", ignore = false)
    @Mapping(target = "usuarios", ignore = true)
    DeviceType toEntity(DeviceTypeDTO deviceTypeDTO);

    default DeviceType fromId(Long id) {
        if (id == null) {
            return null;
        }
        DeviceType deviceType = new DeviceType();
        deviceType.setId(id);
        return deviceType;
    }
}

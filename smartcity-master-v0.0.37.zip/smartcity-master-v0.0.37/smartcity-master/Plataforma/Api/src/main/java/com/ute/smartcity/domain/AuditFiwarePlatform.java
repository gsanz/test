package com.ute.smartcity.domain;



import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * A AuditFiwarePlatform.
 */
@Entity
@Table(name = "audit_fiware_platform")
public class AuditFiwarePlatform implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "jhi_date", nullable = false)
    private Instant date;

    @NotNull
    @Column(name = "jhi_type", nullable = false)
    private String type;

    @NotNull
    @Size(max = 3500)
    @Column(name = "request_url", length = 3500, nullable = false)
    private String requestUrl;

    @NotNull
    @Size(max = 3500)
    @Column(name = "request_content", length = 3500, nullable = false)
    private String requestContent;

    @NotNull
    @Size(max = 3500)
    @Column(name = "response_content", length = 3500, nullable = false)
    private String responseContent;

    @NotNull
    @Column(name = "response_code", nullable = false)
    private Integer responseCode;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Instant getDate() {
        return date;
    }

    public AuditFiwarePlatform date(Instant date) {
        this.date = date;
        return this;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public AuditFiwarePlatform type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public AuditFiwarePlatform requestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
        return this;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    public String getRequestContent() {
        return requestContent;
    }

    public AuditFiwarePlatform requestContent(String requestContent) {
        this.requestContent = requestContent;
        return this;
    }

    public void setRequestContent(String requestContent) {
        this.requestContent = requestContent;
    }

    public String getResponseContent() {
        return responseContent;
    }

    public AuditFiwarePlatform responseContent(String responseContent) {
        this.responseContent = responseContent;
        return this;
    }

    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }

    public Integer getResponseCode() {
        return responseCode;
    }

    public AuditFiwarePlatform responseCode(Integer responseCode) {
        this.responseCode = responseCode;
        return this;
    }

    public void setResponseCode(Integer responseCode) {
        this.responseCode = responseCode;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AuditFiwarePlatform auditFiwarePlatform = (AuditFiwarePlatform) o;
        if (auditFiwarePlatform.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), auditFiwarePlatform.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "AuditFiwarePlatform{" +
            "id=" + getId() +
            ", date='" + getDate() + "'" +
            ", type='" + getType() + "'" +
            ", requestUrl='" + getRequestUrl() + "'" +
            ", requestContent='" + getRequestContent() + "'" +
            ", responseContent='" + getResponseContent() + "'" +
            ", responseCode=" + getResponseCode() +
            "}";
    }
}

package com.ute.smartcity.service.platform.generic;

import com.ute.smartcity.service.dto.FiwareSubscriptionDTO;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface SmartCityPlatformSubscriptionService {

    List<FiwareSubscriptionDTO> addSubscriptions(List<FiwareSubscriptionDTO> subscriptionDTOList) throws Exception;
    ResponseEntity<String> addSubscription(FiwareSubscriptionDTO subscriptionDTO) throws Exception;
}

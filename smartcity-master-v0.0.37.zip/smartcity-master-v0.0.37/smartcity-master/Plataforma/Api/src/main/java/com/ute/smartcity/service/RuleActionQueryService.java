package com.ute.smartcity.service;

import java.util.List;

import javax.persistence.criteria.JoinType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.ute.smartcity.domain.RuleAction;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.RuleActionRepository;
import com.ute.smartcity.service.dto.RuleActionCriteria;
import com.ute.smartcity.service.dto.RuleActionDTO;
import com.ute.smartcity.service.mapper.RuleActionMapper;

/**
 * Service for executing complex queries for RuleAction entities in the database.
 * The main input is a {@link RuleActionCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link RuleActionDTO} or a {@link Page} of {@link RuleActionDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class RuleActionQueryService extends QueryService<RuleAction> {

    private final Logger log = LoggerFactory.getLogger(RuleActionQueryService.class);

    private final RuleActionRepository ruleActionRepository;

    private final RuleActionMapper ruleActionMapper;

    public RuleActionQueryService(RuleActionRepository ruleActionRepository, RuleActionMapper ruleActionMapper) {
        this.ruleActionRepository = ruleActionRepository;
        this.ruleActionMapper = ruleActionMapper;
    }

    /**
     * Return a {@link List} of {@link RuleActionDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<RuleActionDTO> findByCriteria(RuleActionCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<RuleAction> specification = createSpecification(criteria);
        return ruleActionMapper.toDto(ruleActionRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link RuleActionDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page     The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<RuleActionDTO> findByCriteria(RuleActionCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<RuleAction> specification = createSpecification(criteria);
        return ruleActionRepository.findAll(specification, page)
            .map(ruleActionMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(RuleActionCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<RuleAction> specification = createSpecification(criteria);
        return ruleActionRepository.count(specification);
    }

    /**
     * Function to convert RuleActionCriteria to a {@link Specification}
     */
    private Specification<RuleAction> createSpecification(RuleActionCriteria criteria) {
        Specification<RuleAction> specification = Specification.where(null);
        if (criteria == null) {
            return specification;
        }
        if (criteria.getId() != null) {
            specification = specification.and(buildSpecification(criteria.getId(), RuleAction_.id));
        }
        if (criteria.getRuleActionType() != null) {
            specification = specification.and(buildSpecification(criteria.getRuleActionType(), RuleAction_.ruleActionType));
        }
        if (criteria.getSubject() != null) {
            specification = specification.and(buildStringSpecification(criteria.getSubject(), RuleAction_.subject));
        }
        if (criteria.getTemplate() != null) {
            specification = specification.and(buildStringSpecification(criteria.getTemplate(), RuleAction_.template));
        }
        if (criteria.getFrom() != null) {
            specification = specification.and(buildStringSpecification(criteria.getFrom(), RuleAction_.from));
        }
        if (criteria.getTo() != null) {
            specification = specification.and(buildStringSpecification(criteria.getTo(), RuleAction_.to));
        }
        if (criteria.getPostParameters() != null) {
            specification = specification.and(buildStringSpecification(criteria.getPostParameters(), RuleAction_.postParameters));
        }
        if (criteria.getRuleId() != null) {
            specification = specification.and(buildSpecification(criteria.getRuleId(),
                root -> root.join(RuleAction_.rule, JoinType.LEFT).get(Rule_.id)));
        }
        if (criteria.getRuleUpdateFieldsId() != null) {
            specification = specification.and(buildSpecification(criteria.getRuleUpdateFieldsId(),
                root -> root.join(RuleAction_.ruleUpdateFields, JoinType.LEFT).get(RuleUpdateFields_.id)));
        }
        return specification;
    }
}

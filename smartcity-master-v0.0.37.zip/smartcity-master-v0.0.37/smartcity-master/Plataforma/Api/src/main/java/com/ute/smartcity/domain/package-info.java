/**
 * JPA domain objects.
 */
package com.ute.smartcity.domain;

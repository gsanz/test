package com.ute.smartcity.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ute.smartcity.domain.enumeration.RuleActionType;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A RuleAction.
 */
@Entity
@Table(name = "rule_action")
public class RuleAction implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "rule_action_type", nullable = false)
    private RuleActionType ruleActionType;

    @Size(max = 250)
    @Column(name = "subject", length = 250)
    private String subject;

    @Size(max = 3500)
    @Column(name = "template", length = 3500)
    private String template;

    @Size(max = 100)
    @Column(name = "jhi_from", length = 100)
    private String from;

    @Size(max = 100)
    @Column(name = "jhi_to", length = 100)
    private String to;

    @Size(max = 3500)
    @Column(name = "post_parameters", length = 3500)
    private String postParameters;

    @ManyToOne
    @JsonIgnoreProperties("ruleActions")
    private Rule rule;

    @OneToMany(mappedBy = "ruleAction", fetch=FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<RuleUpdateFields> ruleUpdateFields = new HashSet<>();
    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RuleActionType getRuleActionType() {
        return ruleActionType;
    }

    public RuleAction ruleActionType(RuleActionType ruleActionType) {
        this.ruleActionType = ruleActionType;
        return this;
    }

    public void setRuleActionType(RuleActionType ruleActionType) {
        this.ruleActionType = ruleActionType;
    }

    public String getSubject() {
        return subject;
    }

    public RuleAction subject(String subject) {
        this.subject = subject;
        return this;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTemplate() {
        return template;
    }

    public RuleAction template(String template) {
        this.template = template;
        return this;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getFrom() {
        return from;
    }

    public RuleAction from(String from) {
        this.from = from;
        return this;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public RuleAction to(String to) {
        this.to = to;
        return this;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getPostParameters() {
        return postParameters;
    }

    public RuleAction postParameters(String postParameters) {
        this.postParameters = postParameters;
        return this;
    }

    public void setPostParameters(String postParameters) {
        this.postParameters = postParameters;
    }

    public Rule getRule() {
        return rule;
    }

    public RuleAction rule(Rule rule) {
        this.rule = rule;
        return this;
    }

    public void setRule(Rule rule) {
        this.rule = rule;
    }

    public Set<RuleUpdateFields> getRuleUpdateFields() {
        return ruleUpdateFields;
    }

    public RuleAction ruleUpdateFields(Set<RuleUpdateFields> ruleUpdateFields) {
        this.ruleUpdateFields = ruleUpdateFields;
        return this;
    }

    public RuleAction addRuleUpdateFields(RuleUpdateFields ruleUpdateFields) {
        this.ruleUpdateFields.add(ruleUpdateFields);
        ruleUpdateFields.setRuleAction(this);
        return this;
    }

    public RuleAction removeRuleUpdateFields(RuleUpdateFields ruleUpdateFields) {
        this.ruleUpdateFields.remove(ruleUpdateFields);
        ruleUpdateFields.setRuleAction(null);
        return this;
    }

    public void setRuleUpdateFields(Set<RuleUpdateFields> ruleUpdateFields) {
        this.ruleUpdateFields = ruleUpdateFields;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RuleAction ruleAction = (RuleAction) o;
        if (ruleAction.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), ruleAction.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RuleAction{" +
            "id=" + getId() +
            ", ruleActionType='" + getRuleActionType() + "'" +
            ", subject='" + getSubject() + "'" +
            ", template='" + getTemplate() + "'" +
            ", from='" + getFrom() + "'" +
            ", to='" + getTo() + "'" +
            ", postParameters='" + getPostParameters() + "'" +
            "}";
    }
}

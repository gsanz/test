package com.ute.smartcity.web.rest;

import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.FieldsCriteria;
import com.ute.smartcity.service.dto.FieldsDTO;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.DeviceTypeMapper;
import com.ute.smartcity.service.mapper.FieldsMapper;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Fields.
 */
@RestController
@RequestMapping("/api")
public class FieldsResource {

    private final Logger log = LoggerFactory.getLogger(FieldsResource.class);

    private final FieldsService fieldsService;

    private final FieldsQueryService fieldsQueryService;


    public FieldsResource(FieldsService fieldsService, FieldsQueryService fieldsQueryService, DeviceService deviceService, DeviceMapper deviceMapper, DeviceTypeService deviceTypeService, DeviceTypeMapper deviceTypeMapper, SmartCityPlatformService smartCityPlatformService, FieldsMapper fieldsMapper) {
        this.fieldsService = fieldsService;
        this.fieldsQueryService = fieldsQueryService;
    }

    /**
     * GET  /fields : get all the fields.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of fields in body
     */
    @GetMapping("/fields")
    public ResponseEntity<List<FieldsDTO>> getAllFields(FieldsCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Fields by criteria: {}", criteria);
        Page<FieldsDTO> page = fieldsQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/fields");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /fields/count : count all the fields.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/fields/count")
    public ResponseEntity<Long> countFields(FieldsCriteria criteria) {
        log.debug("REST request to count Fields by criteria: {}", criteria);
        return ResponseEntity.ok().body(fieldsQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /fields/:id : get the "id" fields.
     *
     * @param id the id of the fieldsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the fieldsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/fields/{id}")
    public ResponseEntity<FieldsDTO> getFields(@PathVariable Long id) {
        log.debug("REST request to get Fields : {}", id);
        Optional<FieldsDTO> fieldsDTO = fieldsService.findOne(id);
        return ResponseUtil.wrapOrNotFound(fieldsDTO);
    }

}

package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.SubscriptionsService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.SubscriptionsDTO;
import com.ute.smartcity.service.dto.SubscriptionsCriteria;
import com.ute.smartcity.service.SubscriptionsQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Subscriptions.
 */
@RestController
@RequestMapping("/api")
public class SubscriptionsResource {

    private final Logger log = LoggerFactory.getLogger(SubscriptionsResource.class);

    private static final String ENTITY_NAME = "subscriptions";

    private final SubscriptionsService subscriptionsService;

    private final SubscriptionsQueryService subscriptionsQueryService;

    public SubscriptionsResource(SubscriptionsService subscriptionsService, SubscriptionsQueryService subscriptionsQueryService) {
        this.subscriptionsService = subscriptionsService;
        this.subscriptionsQueryService = subscriptionsQueryService;
    }

    /**
     * POST  /subscriptions : Create a new subscriptions.
     *
     * @param subscriptionsDTO the subscriptionsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new subscriptionsDTO, or with status 400 (Bad Request) if the subscriptions has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/subscriptions")
    public ResponseEntity<SubscriptionsDTO> createSubscriptions(@Valid @RequestBody SubscriptionsDTO subscriptionsDTO) throws URISyntaxException {
        log.debug("REST request to save Subscriptions : {}", subscriptionsDTO);
        if (subscriptionsDTO.getId() != null) {
            throw new BadRequestAlertException("A new subscriptions cannot already have an ID", ENTITY_NAME, "idexists");
        }
        SubscriptionsDTO result = subscriptionsService.save(subscriptionsDTO);
        return ResponseEntity.created(new URI("/api/subscriptions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /subscriptions : Updates an existing subscriptions.
     *
     * @param subscriptionsDTO the subscriptionsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated subscriptionsDTO,
     * or with status 400 (Bad Request) if the subscriptionsDTO is not valid,
     * or with status 500 (Internal Server Error) if the subscriptionsDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/subscriptions")
    public ResponseEntity<SubscriptionsDTO> updateSubscriptions(@Valid @RequestBody SubscriptionsDTO subscriptionsDTO) throws URISyntaxException {
        log.debug("REST request to update Subscriptions : {}", subscriptionsDTO);
        if (subscriptionsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        SubscriptionsDTO result = subscriptionsService.save(subscriptionsDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, subscriptionsDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /subscriptions : get all the subscriptions.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of subscriptions in body
     */
    @GetMapping("/subscriptions")
    public ResponseEntity<List<SubscriptionsDTO>> getAllSubscriptions(SubscriptionsCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Subscriptions by criteria: {}", criteria);
        Page<SubscriptionsDTO> page = subscriptionsQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/subscriptions");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /subscriptions/count : count all the subscriptions.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/subscriptions/count")
    public ResponseEntity<Long> countSubscriptions(SubscriptionsCriteria criteria) {
        log.debug("REST request to count Subscriptions by criteria: {}", criteria);
        return ResponseEntity.ok().body(subscriptionsQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /subscriptions/:id : get the "id" subscriptions.
     *
     * @param id the id of the subscriptionsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the subscriptionsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/subscriptions/{id}")
    public ResponseEntity<SubscriptionsDTO> getSubscriptions(@PathVariable Long id) {
        log.debug("REST request to get Subscriptions : {}", id);
        Optional<SubscriptionsDTO> subscriptionsDTO = subscriptionsService.findOne(id);
        return ResponseUtil.wrapOrNotFound(subscriptionsDTO);
    }

    /**
     * DELETE  /subscriptions/:id : delete the "id" subscriptions.
     *
     * @param id the id of the subscriptionsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/subscriptions/{id}")
    public ResponseEntity<Void> deleteSubscriptions(@PathVariable Long id) {
        log.debug("REST request to delete Subscriptions : {}", id);
        subscriptionsService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

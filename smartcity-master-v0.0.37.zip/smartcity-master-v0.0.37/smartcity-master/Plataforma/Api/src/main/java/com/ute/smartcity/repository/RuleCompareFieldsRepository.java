package com.ute.smartcity.repository;

import com.ute.smartcity.domain.RuleCompareFields;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * Spring Data  repository for the RuleCompareFields entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RuleCompareFieldsRepository extends JpaRepository<RuleCompareFields, Long>, JpaSpecificationExecutor<RuleCompareFields> {

     List<RuleCompareFields> findByRuleId(Long id);

    void deleteByRuleId(Long id);
}

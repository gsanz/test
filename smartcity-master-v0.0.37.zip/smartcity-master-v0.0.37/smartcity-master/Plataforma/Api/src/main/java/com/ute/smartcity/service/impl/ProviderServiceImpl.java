package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.User;
import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.repository.UserRepository;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.ProviderService;
import com.ute.smartcity.domain.Provider;
import com.ute.smartcity.repository.ProviderRepository;
import com.ute.smartcity.service.UsuarioService;
import com.ute.smartcity.service.dto.ProviderDTO;
import com.ute.smartcity.service.dto.UserDTO;
import com.ute.smartcity.service.dto.UsuarioDTO;
import com.ute.smartcity.service.mapper.ProviderMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Optional;

/**
 * Service Implementation for managing Provider.
 */
@Service
@Transactional
public class ProviderServiceImpl implements ProviderService {

    private final Logger log = LoggerFactory.getLogger(ProviderServiceImpl.class);

    private final ProviderRepository providerRepository;

    private final ProviderMapper providerMapper;

    private final UsuarioService usuarioService;

    private final UserRepository userRepository;

    public ProviderServiceImpl(ProviderRepository providerRepository, ProviderMapper providerMapper, UsuarioService usuarioService, UserRepository userRepository) {
        this.providerRepository = providerRepository;
        this.providerMapper = providerMapper;
        this.usuarioService = usuarioService;
        this.userRepository = userRepository;
    }

    /**
     * Save a provider.
     *
     * @param providerDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public ProviderDTO save(ProviderDTO providerDTO) {
        log.debug("Request to save Provider : {}", providerDTO);

        Provider provider = providerMapper.toEntity(providerDTO);
        provider = providerRepository.save(provider);

        UsuarioDTO usuarioDTO = setUsuarioParams(provider);

        String OldEmail = null;
        Optional<User> user = null;
        if (usuarioDTO.getId() != null){
            Long userId = usuarioDTO.getId();
            user = userRepository.findById(usuarioDTO.getId());
            if(user.isPresent() ) {
                Optional<User> userinOptional = userRepository.findById(userId);
                if(userinOptional.isPresent()) {
                    OldEmail = userinOptional.get().getEmail();
                }
            }
            String newEmail = usuarioDTO.getUser().getEmail();

            if (OldEmail!=null && !OldEmail.equals(newEmail)) {
                usuarioService.updateUsuarioWithEmail(usuarioDTO);
            } else {
                usuarioService.updateUsuario(usuarioDTO);
            }
        }

        return providerMapper.toDto(provider);
    }

    /**
     * create a provider.
     *
     * @param providerDTO the entity to create
     * @return the persisted entity
     */
    @Override
    public ProviderDTO create(ProviderDTO providerDTO) {
        log.debug("Request to create Provider : {}", providerDTO);

        Provider provider = providerMapper.toEntity(providerDTO);
        provider = providerRepository.save(provider);

        UsuarioDTO usuarioDTO = setUsuarioParams(provider);

        usuarioService.createUsuario(usuarioDTO);

        return providerMapper.toDto(provider);
    }

    public UsuarioDTO setUsuarioParams(Provider provider){

        Optional<Usuario> usuario = usuarioService.getUserByProviderId(provider.getId());

        UsuarioDTO usuarioDTO = new UsuarioDTO();
        UserDTO userDTO = new UserDTO();
        usuarioDTO.setUser(userDTO);

        if (usuario.isPresent()) {
            usuarioDTO.setId(usuario.get().getId());
            usuarioDTO.getUser().setId(usuario.get().getUser().getId());
        }

        usuarioDTO.setPhone(provider.getMobile());
        usuarioDTO.setDoubleFactorAuthentication(false);
        usuarioDTO.setProviderId(provider.getId());
        usuarioDTO.setImageContentType(provider.getImageContentType());
        usuarioDTO.setImage(provider.getImage());

        usuarioDTO.getUser().setActivated(true);
        usuarioDTO.getUser().setLogin(provider.getEmail());
        usuarioDTO.getUser().setFirstName(provider.getName());
        usuarioDTO.getUser().setLastName(" ");
        usuarioDTO.getUser().setEmail(provider.getEmail());
        usuarioDTO.getUser().setAuthorities(Collections.singleton(AuthoritiesConstants.PROVIDER));
        usuarioDTO.getUser().setLangKey("es");

        return usuarioDTO;
    }

    /**
     * Get all the providers.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<ProviderDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Providers");
        return providerRepository.findAll(pageable)
            .map(providerMapper::toDto);
    }


    /**
     * Get one provider by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<ProviderDTO> findOne(Long id) {
        log.debug("Request to get Provider : {}", id);
        return providerRepository.findById(id)
            .map(providerMapper::toDto);
    }

    /**
     * Delete the provider by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Provider : {}", id);
        Optional<Usuario> usuario = usuarioService.getUserByProviderId(id);
        usuario.ifPresent(value -> usuarioService.delete(value.getId()));
        providerRepository.deleteById(id);
    }
}

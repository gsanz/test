package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.RuleActionService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.RuleActionDTO;
import com.ute.smartcity.service.dto.RuleActionCriteria;
import com.ute.smartcity.service.RuleActionQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing RuleAction.
 */
@RestController
@RequestMapping("/api")
public class RuleActionResource {

    private final Logger log = LoggerFactory.getLogger(RuleActionResource.class);

    private static final String ENTITY_NAME = "ruleAction";

    private final RuleActionService ruleActionService;

    private final RuleActionQueryService ruleActionQueryService;

    public RuleActionResource(RuleActionService ruleActionService, RuleActionQueryService ruleActionQueryService) {
        this.ruleActionService = ruleActionService;
        this.ruleActionQueryService = ruleActionQueryService;
    }

    /**
     * POST  /rule-actions : Create a new ruleAction.
     *
     * @param ruleActionDTO the ruleActionDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new ruleActionDTO, or with status 400 (Bad Request) if the ruleAction has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/rule-actions")
    public ResponseEntity<RuleActionDTO> createRuleAction(@Valid @RequestBody RuleActionDTO ruleActionDTO) throws URISyntaxException {
        log.debug("REST request to save RuleAction : {}", ruleActionDTO);
        if (ruleActionDTO.getId() != null) {
            throw new BadRequestAlertException("A new ruleAction cannot already have an ID", ENTITY_NAME, "idexists");
        }
        RuleActionDTO result = ruleActionService.save(ruleActionDTO);
        return ResponseEntity.created(new URI("/api/rule-actions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /rule-actions : Updates an existing ruleAction.
     *
     * @param ruleActionDTO the ruleActionDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated ruleActionDTO,
     * or with status 400 (Bad Request) if the ruleActionDTO is not valid,
     * or with status 500 (Internal Server Error) if the ruleActionDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/rule-actions")
    public ResponseEntity<RuleActionDTO> updateRuleAction(@Valid @RequestBody RuleActionDTO ruleActionDTO) throws URISyntaxException {
        log.debug("REST request to update RuleAction : {}", ruleActionDTO);
        if (ruleActionDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        RuleActionDTO result = ruleActionService.save(ruleActionDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, ruleActionDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /rule-actions : get all the ruleActions.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of ruleActions in body
     */
    @GetMapping("/rule-actions")
    public ResponseEntity<List<RuleActionDTO>> getAllRuleActions(RuleActionCriteria criteria, Pageable pageable) {
        log.debug("REST request to get RuleActions by criteria: {}", criteria);
        Page<RuleActionDTO> page = ruleActionQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/rule-actions");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /rule-actions/count : count all the ruleActions.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/rule-actions/count")
    public ResponseEntity<Long> countRuleActions(RuleActionCriteria criteria) {
        log.debug("REST request to count RuleActions by criteria: {}", criteria);
        return ResponseEntity.ok().body(ruleActionQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /rule-actions/:id : get the "id" ruleAction.
     *
     * @param id the id of the ruleActionDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the ruleActionDTO, or with status 404 (Not Found)
     */
    @GetMapping("/rule-actions/{id}")
    public ResponseEntity<RuleActionDTO> getRuleAction(@PathVariable Long id) {
        log.debug("REST request to get RuleAction : {}", id);
        Optional<RuleActionDTO> ruleActionDTO = ruleActionService.findOne(id);
        return ResponseUtil.wrapOrNotFound(ruleActionDTO);
    }

    /**
     * DELETE  /rule-actions/:id : delete the "id" ruleAction.
     *
     * @param id the id of the ruleActionDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/rule-actions/{id}")
    public ResponseEntity<Void> deleteRuleAction(@PathVariable Long id) {
        log.debug("REST request to delete RuleAction : {}", id);
        ruleActionService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

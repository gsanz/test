package com.ute.smartcity.repository;

import com.ute.smartcity.domain.Device;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;


/**
 * Spring Data  repository for the Device entity.
 */
@SuppressWarnings("unused")
@Repository
public interface DeviceRepository extends JpaRepository<Device, Long>, JpaSpecificationExecutor<Device> {
    Optional<Device> findByReference(String reference);
    List<Device> findByZoneId(Long id);
    List<Device> findAllByProviderId(Long id);
    Optional<List<Device>> findAllByDeviceTypeId(Long id);
}

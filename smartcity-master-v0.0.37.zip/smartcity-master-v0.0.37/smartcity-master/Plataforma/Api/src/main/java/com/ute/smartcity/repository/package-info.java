/**
 * Spring Data JPA repositories.
 */
package com.ute.smartcity.repository;

package com.ute.smartcity.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

import com.ute.smartcity.domain.enumeration.CriticalityLevel;

import com.ute.smartcity.domain.enumeration.AlertState;

/**
 * A Alert.
 */
@Entity
@Table(name = "alert")
public class Alert implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "reference", nullable = false)
    private String reference;

    @Enumerated(EnumType.STRING)
    @Column(name = "criticality_level")
    private CriticalityLevel criticalityLevel;

    @Enumerated(EnumType.STRING)
    @Column(name = "state")
    private AlertState state;

    @Column(name = "description")
    private String description;

    @Column(name = "message")
    private String message;

    @Column(name = "create_at")
    private ZonedDateTime createAt;

    @ManyToOne
    @JsonIgnoreProperties("alerts")
    private Device device;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReference() {
        return reference;
    }

    public Alert reference(String reference) {
        this.reference = reference;
        return this;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public CriticalityLevel getCriticalityLevel() {
        return criticalityLevel;
    }

    public Alert criticalityLevel(CriticalityLevel criticalityLevel) {
        this.criticalityLevel = criticalityLevel;
        return this;
    }

    public void setCriticalityLevel(CriticalityLevel criticalityLevel) {
        this.criticalityLevel = criticalityLevel;
    }

    public AlertState getState() {
        return state;
    }

    public Alert state(AlertState state) {
        this.state = state;
        return this;
    }

    public void setState(AlertState state) {
        this.state = state;
    }

    public String getDescription() {
        return description;
    }

    public Alert description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMessage() {
        return message;
    }

    public Alert message(String message) {
        this.message = message;
        return this;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public Alert createAt(ZonedDateTime createAt) {
        this.createAt = createAt;
        return this;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public Device getDevice() {
        return device;
    }

    public Alert device(Device device) {
        this.device = device;
        return this;
    }

    public void setDevice(Device device) {
        this.device = device;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Alert alert = (Alert) o;
        if (alert.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), alert.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Alert{" +
            "id=" + getId() +
            ", reference='" + getReference() + "'" +
            ", criticalityLevel='" + getCriticalityLevel() + "'" +
            ", state='" + getState() + "'" +
            ", description='" + getDescription() + "'" +
            ", message='" + getMessage() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            "}";
    }
}

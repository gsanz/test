package com.ute.smartcity.service;

import java.util.List;

import javax.persistence.criteria.JoinType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.ute.smartcity.domain.RuleUpdateFields;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.RuleUpdateFieldsRepository;
import com.ute.smartcity.service.dto.RuleUpdateFieldsCriteria;
import com.ute.smartcity.service.dto.RuleUpdateFieldsDTO;
import com.ute.smartcity.service.mapper.RuleUpdateFieldsMapper;

/**
 * Service for executing complex queries for RuleUpdateFields entities in the database.
 * The main input is a {@link RuleUpdateFieldsCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link RuleUpdateFieldsDTO} or a {@link Page} of {@link RuleUpdateFieldsDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class RuleUpdateFieldsQueryService extends QueryService<RuleUpdateFields> {

    private final Logger log = LoggerFactory.getLogger(RuleUpdateFieldsQueryService.class);

    private final RuleUpdateFieldsRepository ruleUpdateFieldsRepository;

    private final RuleUpdateFieldsMapper ruleUpdateFieldsMapper;

    public RuleUpdateFieldsQueryService(RuleUpdateFieldsRepository ruleUpdateFieldsRepository, RuleUpdateFieldsMapper ruleUpdateFieldsMapper) {
        this.ruleUpdateFieldsRepository = ruleUpdateFieldsRepository;
        this.ruleUpdateFieldsMapper = ruleUpdateFieldsMapper;
    }

    /**
     * Return a {@link List} of {@link RuleUpdateFieldsDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<RuleUpdateFieldsDTO> findByCriteria(RuleUpdateFieldsCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<RuleUpdateFields> specification = createSpecification(criteria);
        return ruleUpdateFieldsMapper.toDto(ruleUpdateFieldsRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link RuleUpdateFieldsDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<RuleUpdateFieldsDTO> findByCriteria(RuleUpdateFieldsCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<RuleUpdateFields> specification = createSpecification(criteria);
        return ruleUpdateFieldsRepository.findAll(specification, page)
            .map(ruleUpdateFieldsMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(RuleUpdateFieldsCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<RuleUpdateFields> specification = createSpecification(criteria);
        return ruleUpdateFieldsRepository.count(specification);
    }

    /**
     * Function to convert RuleUpdateFieldsCriteria to a {@link Specification}
     */
    private Specification<RuleUpdateFields> createSpecification(RuleUpdateFieldsCriteria criteria) {
        Specification<RuleUpdateFields> specification = Specification.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildSpecification(criteria.getId(), RuleUpdateFields_.id));
            }
            if (criteria.getValue() != null) {
                specification = specification.and(buildStringSpecification(criteria.getValue(), RuleUpdateFields_.value));
            }
            if (criteria.getFieldName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getFieldName(), RuleUpdateFields_.fieldName));
            }
            if (criteria.getRuleActionId() != null) {
                specification = specification.and(buildSpecification(criteria.getRuleActionId(),
                    root -> root.join(RuleUpdateFields_.ruleAction, JoinType.LEFT).get(RuleAction_.id)));
            }
        }
        return specification;
    }
}

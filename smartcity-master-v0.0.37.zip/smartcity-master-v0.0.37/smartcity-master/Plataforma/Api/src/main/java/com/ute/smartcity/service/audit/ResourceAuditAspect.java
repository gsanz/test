package com.ute.smartcity.service.audit;

import com.ute.smartcity.domain.enumeration.TipoCambio;
import com.ute.smartcity.security.SecurityUtils;
import com.ute.smartcity.service.AuditoriaService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.AuditoriaDTO;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.time.Instant;
import java.util.Optional;

import static java.lang.Math.toIntExact;

@Aspect
public class ResourceAuditAspect {

    private final Logger log = LoggerFactory.getLogger(ResourceAuditAspect.class);

    private final Environment env;

    private final static String ANNOTATION_NAME = "com.ute.smartcity.service.audit.annotation.ResourceAudit";

    private final AuditoriaService auditoriaService;

    public ResourceAuditAspect(Environment env, AuditoriaService auditoriaService) {
        this.env = env;
        this.auditoriaService = auditoriaService;
    }

    @Pointcut("within(com.ute.smartcity.web.rest..*)")
    public void restServicePointcut() {
        // No necesita implementar. Sólo es para definir el enlace
    }

    @Pointcut("execution(@" + ANNOTATION_NAME + " * *(..))")
    public void annotatedMethodPointcut() {
        // No necesita implementar. Sólo es para definir el enlace
    }

    @Around("annotatedMethodPointcut() && restServicePointcut()")
    public Object auditCall(ProceedingJoinPoint joinPoint) throws Throwable {
        Object  ob = new Object();
        if(joinPoint!=null) {
            Long entidadIdOriginal = getEntityId(joinPoint);
            Object result = joinPoint.proceed();

            String usuarioLogin = getUsuarioLogin();
            String entidadNombre = getEntityName(joinPoint);
            TipoCambio tipoCambio = getTipoCambio(joinPoint);
            Long entidadId = Math.max(getEntityId(result), entidadIdOriginal);

            saveAuditInfo(usuarioLogin, entidadNombre, tipoCambio, entidadId);

            return result;
        }
        return ob;
    }

    private String getUsuarioLogin() {
        String usuarioLogin = null;
        try {
            Optional<String> optional = SecurityUtils.getCurrentUserLogin();
            usuarioLogin = ( optional.isPresent() ? optional.get() : null );


        } catch (Exception e) {
            log.error("Error obteniendo el usuario actual", e);
        }
        return usuarioLogin;
    }

    private void saveAuditInfo(String usuarioLogin, String entidadNombre, TipoCambio tipoCambio, Long entidadId) {
        try {
            AuditoriaDTO auditoriaDTO = new AuditoriaDTO();
            auditoriaDTO.setUsuarioLogin(usuarioLogin);
            auditoriaDTO.setEntityName(entidadNombre);
            auditoriaDTO.setTipoCambio(tipoCambio);
            auditoriaDTO.setEntityId(toIntExact(entidadId));
            auditoriaDTO.setDate(Instant.now());
            auditoriaService.save(auditoriaDTO);
        } catch (Exception e) {
            log.error("Error guardando información de Auditoría", e);
        }
    }

    private Annotation[] getAnnotationsMethod(ProceedingJoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        return method.getDeclaredAnnotations();
    }

    private TipoCambio getTipoCambio(ProceedingJoinPoint joinPoint) {
        try {
            for (Annotation annotation : getAnnotationsMethod(joinPoint)) {
                if (annotation instanceof PutMapping) {
                    return TipoCambio.MODIFICACION;
                } else if (annotation instanceof PostMapping) {
                    return TipoCambio.ALTA;
                } else if (annotation instanceof DeleteMapping) {
                    return TipoCambio.BAJA;
                } else if (annotation instanceof RequestMapping) {
                    return getTipoCambio((RequestMapping) annotation);
                }
            }
        } catch (Exception e) {
            log.error("Error al obtener el tipo de cambio", e);
            return null;
        }
        return null;
    }

    private TipoCambio getTipoCambio(RequestMapping annotation) {
        if (annotation.method().length > 0) {
            for (RequestMethod method :
                annotation.method()) {
                switch(method) {
                    case POST:
                        return TipoCambio.ALTA;
                    case PUT:
                    case PATCH:
                        return TipoCambio.MODIFICACION;
                    case DELETE:
                        return TipoCambio.BAJA;
                }
            }
        }
        return null;
    }

    private String getEntityName(ProceedingJoinPoint joinPoint) {
        try {
            Annotation[] annotations = getAnnotationsMethod(joinPoint);
            if (annotations != null && annotations.length > 0) {
                for (Annotation annotation : annotations) {
                    if (annotation instanceof ResourceAudit) {
                        return ((ResourceAudit) annotation).value();
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error obteniendo el nombre de la Entidad", e);
        }
        return null;
    }

    private Long getEntityId(ProceedingJoinPoint joinPoint) {
        Long result = -1L;
        try {
            if (joinPoint != null && joinPoint.getArgs().length > 0) {
                Object firstParameter = joinPoint.getArgs()[0];
                if (firstParameter instanceof Long) {
                    result = (Long) firstParameter;
                } else {
                    result = getEntityId(firstParameter);
                }
            }
        } catch (Exception e) {
            log.error("Error obteniendo el id original", e);
        }
        return result;
    }

    private Long getEntityId(Object object) {
        Object entity;
        Long result = null;

        if (object instanceof ResponseEntity) {
            entity = ((ResponseEntity) object).getBody();
        } else {
            entity = object;
        }

        try {
            if(entity != null && entity.getClass() != null ) {
                Method method = entity.getClass().getDeclaredMethod("getId", null);
                result = (Long) method.invoke(entity);
            }

        } catch (Exception e) {
            log.error("Error al obtener el Id de la entidad");
        }
        return (result == null ? -1L : result);
    }
}

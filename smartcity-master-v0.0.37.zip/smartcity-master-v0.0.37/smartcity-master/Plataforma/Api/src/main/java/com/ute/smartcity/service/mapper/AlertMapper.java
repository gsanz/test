package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.AlertDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Alert and its DTO AlertDTO.
 */
@Mapper(componentModel = "spring", uses = {DeviceMapper.class})
public interface AlertMapper extends EntityMapper<AlertDTO, Alert> {

    @Mapping(source = "device.id", target = "deviceId")
    @Mapping(source = "device.reference", target = "deviceReference")
    @Mapping(source = "device.name", target = "deviceName")
    AlertDTO toDto(Alert alert);

    @Mapping(source = "deviceId", target = "device")
    Alert toEntity(AlertDTO alertDTO);

    default Alert fromId(Long id) {
        if (id == null) {
            return null;
        }
        Alert alert = new Alert();
        alert.setId(id);
        return alert;
    }
}

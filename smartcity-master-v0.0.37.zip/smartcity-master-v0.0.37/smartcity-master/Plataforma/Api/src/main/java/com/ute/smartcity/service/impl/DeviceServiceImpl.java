package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.Fields;
import com.ute.smartcity.repository.FieldsRepository;
import com.ute.smartcity.service.DeviceService;
import com.ute.smartcity.domain.Device;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.mapper.DeviceMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing Device.
 */
@Service
@Transactional
public class DeviceServiceImpl implements DeviceService {

    private final Logger log = LoggerFactory.getLogger(DeviceServiceImpl.class);

    private final FieldsRepository fieldsRepository;

    private final DeviceRepository deviceRepository;

    private final DeviceMapper deviceMapper;

    public DeviceServiceImpl(FieldsRepository fieldsRepository, DeviceRepository deviceRepository, DeviceMapper deviceMapper) {
        this.fieldsRepository = fieldsRepository;
        this.deviceRepository = deviceRepository;
        this.deviceMapper = deviceMapper;
    }

    /**
     * Save a device.
     *
     * @param deviceDTO the entity to save
     * @return the persisted entity
     */
    @Override
    @Transactional
    public DeviceDTO save(DeviceDTO deviceDTO) {
        log.debug("Request to save Device : {}", deviceDTO);

        Device device = deviceMapper.toEntity(deviceDTO);

        device = deviceRepository.save(device);
        for (Fields field : device.getFields()) {
            if(field.getDevice() == null) {
                field.setId(null);
                field.setDeviceType(null);
                field.setDevice(device);
                fieldsRepository.save(field);
            }
        }

        return deviceMapper.toDto(device);
    }


    /**
     * Get all the devices.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<DeviceDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Devices");
        return deviceRepository.findAll(pageable)
            .map(deviceMapper::toDto);
    }


    /**
     * Get one device by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<DeviceDTO> findOne(Long id) {
        log.debug("Request to get Device : {}", id);
        return deviceRepository.findById(id)
            .map(deviceMapper::toDto);
    }

    /**
     * Delete the device by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Device : {}", id);
        deviceRepository.deleteById(id);
    }

    public Optional<Device> findByReference(String reference){
        return deviceRepository.findByReference(reference);
    }

    @Override
    public List<Device> findAllByProviderId(Long id){
        return deviceRepository.findAllByProviderId(id);
    }
}

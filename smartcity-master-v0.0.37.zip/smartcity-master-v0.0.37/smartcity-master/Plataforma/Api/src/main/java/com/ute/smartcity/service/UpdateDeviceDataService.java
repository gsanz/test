package com.ute.smartcity.service;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.service.exception.fiware.HttpOrionConnectionException;
import com.ute.smartcity.service.exception.IllegalTypeException;
import com.ute.smartcity.service.exception.fiware.OrionException;
import org.springframework.stereotype.Service;

@Service
public interface UpdateDeviceDataService {

    public void updateDeviceData(Device device, String data, String reference) throws HttpOrionConnectionException, OrionException, IllegalTypeException;
    public void syncDevices() throws HttpOrionConnectionException, OrionException, IllegalTypeException;
}

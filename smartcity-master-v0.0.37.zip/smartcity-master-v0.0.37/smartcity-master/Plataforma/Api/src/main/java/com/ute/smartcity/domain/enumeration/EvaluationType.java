package com.ute.smartcity.domain.enumeration;

/**
 * The EvaluationType enumeration.
 */
public enum EvaluationType {
    COMPARATIVE_VALUES, NO_AVAILABILITY
}

package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.ProviderQueryService;
import com.ute.smartcity.service.ProviderService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.ProviderCriteria;
import com.ute.smartcity.service.dto.ProviderDTO;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Provider.
 */
@RestController
@RequestMapping("/api")
public class ProviderResource {

    private final Logger log = LoggerFactory.getLogger(ProviderResource.class);

    private static final String ENTITY_NAME = "provider";

    private final ProviderService providerService;

    private final ProviderQueryService providerQueryService;

    public ProviderResource(ProviderService providerService, ProviderQueryService providerQueryService) {
        this.providerService = providerService;
        this.providerQueryService = providerQueryService;
    }

    /**
     * GET  /providers : get all the providers.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of providers in body
     */
    @GetMapping("/providers")
    public ResponseEntity<List<ProviderDTO>> getAllProviders(ProviderCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Providers by criteria: {}", criteria);
        Page<ProviderDTO> page = providerQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/providers");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /providers/count : count all the providers.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/providers/count")
    public ResponseEntity<Long> countProviders(ProviderCriteria criteria) {
        log.debug("REST request to count Providers by criteria: {}", criteria);
        return ResponseEntity.ok().body(providerQueryService.countByCriteria(criteria));
    }
}

package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.RuleUpdateFieldsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity RuleUpdateFields and its DTO RuleUpdateFieldsDTO.
 */
@Mapper(componentModel = "spring", uses = {RuleActionMapper.class})
public interface RuleUpdateFieldsMapper extends EntityMapper<RuleUpdateFieldsDTO, RuleUpdateFields> {

    @Mapping(source = "ruleAction.id", target = "ruleActionId")
    RuleUpdateFieldsDTO toDto(RuleUpdateFields ruleUpdateFields);

    @Mapping(source = "ruleActionId", target = "ruleAction")
    RuleUpdateFields toEntity(RuleUpdateFieldsDTO ruleUpdateFieldsDTO);

    default RuleUpdateFields fromId(Long id) {
        if (id == null) {
            return null;
        }
        RuleUpdateFields ruleUpdateFields = new RuleUpdateFields();
        ruleUpdateFields.setId(id);
        return ruleUpdateFields;
    }
}

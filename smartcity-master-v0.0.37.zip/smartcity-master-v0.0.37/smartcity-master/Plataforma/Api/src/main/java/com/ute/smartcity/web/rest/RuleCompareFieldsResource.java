package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.RuleCompareFieldsService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.RuleCompareFieldsDTO;
import com.ute.smartcity.service.dto.RuleCompareFieldsCriteria;
import com.ute.smartcity.service.RuleCompareFieldsQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing RuleCompareFields.
 */
@RestController
@RequestMapping("/api")
public class RuleCompareFieldsResource {

    private final Logger log = LoggerFactory.getLogger(RuleCompareFieldsResource.class);

    private static final String ENTITY_NAME = "ruleCompareFields";

    private final RuleCompareFieldsService ruleCompareFieldsService;

    private final RuleCompareFieldsQueryService ruleCompareFieldsQueryService;

    public RuleCompareFieldsResource(RuleCompareFieldsService ruleCompareFieldsService, RuleCompareFieldsQueryService ruleCompareFieldsQueryService) {
        this.ruleCompareFieldsService = ruleCompareFieldsService;
        this.ruleCompareFieldsQueryService = ruleCompareFieldsQueryService;
    }

    /**
     * POST  /rule-compare-fields : Create a new ruleCompareFields.
     *
     * @param ruleCompareFieldsDTO the ruleCompareFieldsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new ruleCompareFieldsDTO, or with status 400 (Bad Request) if the ruleCompareFields has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/rule-compare-fields")
    public ResponseEntity<RuleCompareFieldsDTO> createRuleCompareFields(@RequestBody RuleCompareFieldsDTO ruleCompareFieldsDTO) throws URISyntaxException {
        log.debug("REST request to save RuleCompareFields : {}", ruleCompareFieldsDTO);
        if (ruleCompareFieldsDTO.getId() != null) {
            throw new BadRequestAlertException("A new ruleCompareFields cannot already have an ID", ENTITY_NAME, "idexists");
        }
        RuleCompareFieldsDTO result = ruleCompareFieldsService.save(ruleCompareFieldsDTO);
        return ResponseEntity.created(new URI("/api/rule-compare-fields/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /rule-compare-fields : Updates an existing ruleCompareFields.
     *
     * @param ruleCompareFieldsDTO the ruleCompareFieldsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated ruleCompareFieldsDTO,
     * or with status 400 (Bad Request) if the ruleCompareFieldsDTO is not valid,
     * or with status 500 (Internal Server Error) if the ruleCompareFieldsDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/rule-compare-fields")
    public ResponseEntity<RuleCompareFieldsDTO> updateRuleCompareFields(@RequestBody RuleCompareFieldsDTO ruleCompareFieldsDTO) throws URISyntaxException {
        log.debug("REST request to update RuleCompareFields : {}", ruleCompareFieldsDTO);
        if (ruleCompareFieldsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        RuleCompareFieldsDTO result = ruleCompareFieldsService.save(ruleCompareFieldsDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, ruleCompareFieldsDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /rule-compare-fields : get all the ruleCompareFields.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of ruleCompareFields in body
     */
    @GetMapping("/rule-compare-fields")
    public ResponseEntity<List<RuleCompareFieldsDTO>> getAllRuleCompareFields(RuleCompareFieldsCriteria criteria, Pageable pageable) {
        log.debug("REST request to get RuleCompareFields by criteria: {}", criteria);
        Page<RuleCompareFieldsDTO> page = ruleCompareFieldsQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/rule-compare-fields");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /rule-compare-fields/count : count all the ruleCompareFields.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/rule-compare-fields/count")
    public ResponseEntity<Long> countRuleCompareFields(RuleCompareFieldsCriteria criteria) {
        log.debug("REST request to count RuleCompareFields by criteria: {}", criteria);
        return ResponseEntity.ok().body(ruleCompareFieldsQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /rule-compare-fields/:id : get the "id" ruleCompareFields.
     *
     * @param id the id of the ruleCompareFieldsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the ruleCompareFieldsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/rule-compare-fields/{id}")
    public ResponseEntity<RuleCompareFieldsDTO> getRuleCompareFields(@PathVariable Long id) {
        log.debug("REST request to get RuleCompareFields : {}", id);
        Optional<RuleCompareFieldsDTO> ruleCompareFieldsDTO = ruleCompareFieldsService.findOne(id);
        return ResponseUtil.wrapOrNotFound(ruleCompareFieldsDTO);
    }

    /**
     * DELETE  /rule-compare-fields/:id : delete the "id" ruleCompareFields.
     *
     * @param id the id of the ruleCompareFieldsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/rule-compare-fields/{id}")
    public ResponseEntity<Void> deleteRuleCompareFields(@PathVariable Long id) {
        log.debug("REST request to delete RuleCompareFields : {}", id);
        ruleCompareFieldsService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

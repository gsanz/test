package com.ute.smartcity.web.rest;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ute.smartcity.domain.enumeration.CompareType;
import com.ute.smartcity.domain.enumeration.RuleActionType;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.RuleCriteria;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.dto.RuleListDTO;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.service.util.EncodeSymbols;
import com.ute.smartcity.service.util.ValidatorUtil;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.regex.Pattern;

/**
 * REST controller for managing Rule.
 */
@RestController
@RequestMapping("/api")
public class RuleResourceExt {

    private final Logger log = LoggerFactory.getLogger(RuleResourceExt.class);

    private static final String ENTITY_NAME = "rule";

    private final RuleService ruleService;

    private final RuleActionService ruleActionService;

    private final RuleQueryService ruleQueryService;

    public static final Pattern REFERENCE_PATTERN =
        Pattern.compile("^[a-zA-Z0-9_]*$", Pattern.CASE_INSENSITIVE);

    public RuleResourceExt(RuleService ruleService, RuleActionService ruleActionService, RuleQueryService ruleQueryService) {
        this.ruleService = ruleService;
        this.ruleActionService = ruleActionService;
        this.ruleQueryService = ruleQueryService;
    }

    @Value("${application.fiware.notification-server}")
    public String notification_server;

    /**
     * POST  /rules : Create a new rule.
     *
     * @param ruleDTO the ruleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new ruleDTO, or with status 400 (Bad Request) if the rule has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/rules")
    public ResponseEntity<RuleDTO> createRule(@Valid @RequestBody RuleDTO ruleDTO) throws URISyntaxException, ParseException {
        log.debug("REST request to save Rule : {}", ruleDTO);
        if (ruleDTO.getId() != null) {
            throw new BadRequestAlertException("A new rule cannot already have an ID", ENTITY_NAME, "idexists");
        }
        String description = ruleDTO.getDescription().trim();
        if (ruleDTO.getDescription() == null || ruleDTO.getDescription().equals("") || description.length() <= 0) {
            throw new BadRequestAlertException("The field description is required", ENTITY_NAME, "nodescription");
        }
        String reference = ruleDTO.getReference().trim();
        if (ruleDTO.getReference() == null || ruleDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("The field description is required", ENTITY_NAME, "noreference");
        }
        validatePostParametersIsNotNull(ruleDTO);
        validateRuleCompareFieldsIsNotNull(ruleDTO);

        ValidatorUtil validator = new ValidatorUtil();

        if (!validator.validate(reference, REFERENCE_PATTERN)) {
            log.debug("Invalid reference: " + reference + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Bad reference characters", ENTITY_NAME, "referenceInvalid");
        }


        RuleDTO result;
        try {
            result = ruleService.save(ruleDTO);
        } catch (PlatformException e) {
            log.error("Error al guardar regla en plataforma {}",e.getMessage());
            throw new BadRequestAlertException("There was an error trying to save the rule to fiware", ENTITY_NAME, "fail-save-orion-rule");
        }

        return ResponseEntity.created(new URI("/api/rules/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    @GetMapping("/rules/list")
    public ResponseEntity<List<RuleListDTO>> getAllRulesList(RuleCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Rules by criteria: {}", criteria);
        Page<RuleListDTO> page = ruleQueryService.findListByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/rules");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    @GetMapping("/server")
    public ResponseEntity<String> getConfigurationServer() {
        log.debug("REST request to get Rule configuration server: {}", notification_server);
        return ResponseEntity.ok().body(notification_server);
    }

    /**
     * PUT  /rules : Updates an existing rule.
     *
     * @param ruleDTO the ruleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated ruleDTO,
     * or with status 400 (Bad Request) if the ruleDTO is not valid,
     * or with status 500 (Internal Server Error) if the ruleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/rules")
    public ResponseEntity<RuleDTO> updateRule(@Valid @RequestBody RuleDTO ruleDTO) throws URISyntaxException, ParseException {
        log.debug("REST request to update Rule : {}", ruleDTO);
        if (ruleDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String description = ruleDTO.getDescription().trim();
        if (ruleDTO.getDescription() == null || ruleDTO.getDescription().equals("") || description.length() <= 0) {
            throw new BadRequestAlertException("The field description is required", ENTITY_NAME, "nodescription");
        }
        String reference = ruleDTO.getReference().trim();
        if (ruleDTO.getReference() == null || ruleDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("The field description is required", ENTITY_NAME, "noreference");
        }

        validatePostParametersIsNotNull(ruleDTO);
        validateRuleCompareFieldsIsNotNull(ruleDTO);

        ValidatorUtil validator = new ValidatorUtil();

        if (!validator.validate(reference, REFERENCE_PATTERN)) {
            log.debug("Invalid reference: " + reference + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Bad reference characters", ENTITY_NAME, "referenceInvalid");
        }

        RuleDTO result = null;
        try {
            result = ruleService.save(ruleDTO);
        } catch (PlatformException e) {
            log.error("Error al actualizar regla en plataforma {}",e.getMessage());
            throw new BadRequestAlertException("There was an error trying to update the device to fiware", ENTITY_NAME, "fail-save-orion-rule");
        }
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, ruleDTO.getId().toString()))
            .body(result);
    }

    private void validatePostParametersIsNotNull(@RequestBody @Valid RuleDTO ruleDTO) {
        if (!ruleDTO.getRuleActions().isEmpty()) {
            ruleDTO.getRuleActions().forEach(ruleActionDTO -> {
                boolean postParametersIsNull = ruleActionDTO.getPostParameters() == null;
                if (ruleActionDTO.getRuleActionType().equals(RuleActionType.POST) && (ruleActionDTO.getPostParameters().isEmpty() || postParametersIsNull)) {
                    throw new BadRequestAlertException("Post parameters cant be null", ENTITY_NAME, "nopostparameters");
                }
                try {
                    JsonParser parser = new JsonParser();
                    JsonObject parameters = parser.parse(ruleActionDTO.getPostParameters()).getAsJsonObject();
                    JsonObject jsonParameters = parameters.getAsJsonObject("json");
                } catch (Exception ex) {
                    throw new BadRequestAlertException("Post parameters dont have a json structure", ENTITY_NAME, "nojsonstructure");
                }
            });
        }
    }

    private void validateRuleCompareFieldsIsNotNull(@RequestBody @Valid RuleDTO ruleDTO) {
        if (!ruleDTO.getRuleCompareFields().isEmpty()) {
            ruleDTO.getRuleCompareFields().forEach(ruleCompareFieldsDTO -> {

                boolean compareTypeIsNull = false;
                CompareType compareType = ruleCompareFieldsDTO.getCompareType();
                if (compareType == null || compareType.toString().length() <= 0) {
                    compareTypeIsNull = true;
                }

                boolean valueIsNull = false;
                String value = ruleCompareFieldsDTO.getValue();
                if (value == null || value.equals("") || value.length() <= 0 || value.trim().length() <= 0) {
                    valueIsNull = true;
                }

                boolean fieldNameIsNull = false;
                String fieldName = ruleCompareFieldsDTO.getFieldName();
                if (fieldName == null || fieldName.equals("") || fieldName.length() <= 0 || fieldName.trim().length() <= 0) {
                    fieldNameIsNull = true;
                }

                boolean fieldTypeIsNull = false;
                String fieldType = ruleCompareFieldsDTO.getFieldType();
                if (fieldType == null || fieldType.equals("") || fieldType.length() <= 0 || fieldType.trim().length() <= 0) {
                    fieldTypeIsNull = true;
                }

                if (compareTypeIsNull || valueIsNull || fieldNameIsNull || fieldTypeIsNull) {
                    throw new BadRequestAlertException("The compare fields are not correct", ENTITY_NAME, "nocomparefields");
                }

            });
        }
    }
}

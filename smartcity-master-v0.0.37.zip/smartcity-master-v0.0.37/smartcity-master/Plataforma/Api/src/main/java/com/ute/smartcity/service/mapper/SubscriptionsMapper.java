package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.DeviceTypeDTO;
import com.ute.smartcity.service.dto.SubscriptionTemplateDTO;
import com.ute.smartcity.service.dto.SubscriptionsDTO;

import org.mapstruct.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Mapper for the entity Subscriptions and its DTO SubscriptionsDTO.
 */
@Mapper(componentModel = "spring", uses = {DeviceTypeMapper.class})
public interface SubscriptionsMapper extends EntityMapper<SubscriptionsDTO, Subscriptions> {

    @Mapping(source = "deviceType.id", target = "deviceTypeId")
    @Mapping(source = "deviceType.name", target = "deviceTypeName")
    @Mapping(source = "deviceType.type", target = "deviceTypeType")
    @Mapping(source = "deviceType.reference", target = "deviceTypeReference")
    SubscriptionsDTO toDto(Subscriptions subscriptions);

    @Mapping(source = "deviceTypeId", target = "deviceType")
    Subscriptions toEntity(SubscriptionsDTO subscriptionsDTO);

    default Subscriptions fromId(Long id) {
        if (id == null) {
            return null;
        }
        Subscriptions subscriptions = new Subscriptions();
        subscriptions.setId(id);
        return subscriptions;
    }

    default List<SubscriptionsDTO> subscriptionTemplateDTOListToSubscriptionsDTOList(List<SubscriptionTemplateDTO> subscriptionTemplateList,
                                                                                     DeviceTypeDTO deviceTypeDTO) {
        List<SubscriptionsDTO> subscriptionsList = new ArrayList<>();
        for (SubscriptionTemplateDTO subTempDTO : subscriptionTemplateList) {
            SubscriptionsDTO subscriptions = new SubscriptionsDTO();
            subscriptions.setDescription(subTempDTO.getDescription());
            subscriptions.setEndpoint(subTempDTO.getEndpoint());
            subscriptions.setName(subTempDTO.getName());
            subscriptions.setDeviceTypeId(deviceTypeDTO.getId());
            subscriptions.setDeviceTypeName(deviceTypeDTO.getName());
            subscriptions.setDeviceTypeType(deviceTypeDTO.getType());
            subscriptions.setDeviceTypeReference(deviceTypeDTO.getReference());
            subscriptionsList.add(subscriptions);
        }
        return subscriptionsList;
    }

}

package com.ute.smartcity.service.dto;

import com.ute.smartcity.domain.Fields;

import javax.persistence.Lob;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A DTO for the DeviceType entity.
 */
public class DeviceTypeDTO implements Serializable {

    private Long id;

    @NotNull
    private String reference;

    @NotNull
    private String type;

    @NotNull
    private String name;

    @Lob
    private byte[] image;
    private String imageContentType;

    @Lob
    private byte[] imageMarker;
    private String imageMarkerContentType;

    private ZonedDateTime createAt;

    private ZonedDateTime deleteAt;

    private ZonedDateTime updateAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getImageContentType() {
        return imageContentType;
    }

    public void setImageContentType(String imageContentType) {
        this.imageContentType = imageContentType;
    }

    public byte[] getImageMarker() {
        return imageMarker;
    }

    public void setImageMarker(byte[] imageMarker) {
        this.imageMarker = imageMarker;
    }

    public String getImageMarkerContentType() {
        return imageMarkerContentType;
    }

    public void setImageMarkerContentType(String imageMarkerContentType) {
        this.imageMarkerContentType = imageMarkerContentType;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTime getDeleteAt() {
        return deleteAt;
    }

    public void setDeleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTime getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
    }


    private Set<FieldsDTO> fields = new HashSet<>();

    public Set<FieldsDTO> getFields() {
        return fields;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DeviceTypeDTO deviceTypeDTO = (DeviceTypeDTO) o;
        if (deviceTypeDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), deviceTypeDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "DeviceTypeDTO{" +
            "id=" + getId() +
            ", type='" + getType() + "'" +
            ", reference='" + getReference() + "'" +
            ", name='" + getName() + "'" +
            ", image='" + getImage() + "'" +
            ", imageMarker='" + getImageMarker() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", deleteAt='" + getDeleteAt() + "'" +
            ", updateAt='" + getUpdateAt() + "'" +
            "}";
    }
}

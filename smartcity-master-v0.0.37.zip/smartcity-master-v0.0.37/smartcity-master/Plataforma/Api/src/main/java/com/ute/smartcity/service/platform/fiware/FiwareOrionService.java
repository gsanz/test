package com.ute.smartcity.service.platform.fiware;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.ute.smartcity.service.AuditFiwarePlatformService;
import com.ute.smartcity.service.dto.*;
import com.ute.smartcity.service.exception.fiware.HttpIOTAgentConnectionException;
import com.ute.smartcity.service.exception.fiware.HttpOrionConnectionException;
import com.ute.smartcity.service.exception.fiware.IOTAgentException;
import com.ute.smartcity.service.exception.fiware.OrionException;
import com.ute.smartcity.service.exception.platform.PlatformException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

@Component
public class FiwareOrionService {
    private static final String ENTITY_NAME = "FiwareOrionService";

    private final Logger log = LoggerFactory.getLogger(FiwareOrionService.class);


    @Value("${application.fiware.orion.url}")
    public String orionURL;

    @Value("${application.fiware.iot.host}")
    public String iotHost;

    @Value("${application.fiware.iot.url}")
    public String iotURL;

    @Value("${application.fiware.iot.services}")
    public String iotServices;


    @Value("${application.fiware.service-path}")
    public String fiware_service;

    @Value("${application.fiware.orion.subscription}")
    public String subscription;


    private final AuditFiwarePlatformService auditFiwarePlatformService;

    public FiwareOrionService(AuditFiwarePlatformService auditFiwarePlatformService) {
        this.auditFiwarePlatformService = auditFiwarePlatformService;
    }

    private int resultStatusCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
    private String responseContent = "";

    public void addEntity(String entity, String servicepath) throws PlatformException {
        String url = orionURL + "v2/entities";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        HttpEntity<Object> request = new HttpEntity<>(entity, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;

        try
        {
            log.debug("Request" + request.toString());
            response = restTemplate.postForEntity( url, request , String.class );
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            log.debug("Entity added  servicepath: {}  entity: {}",servicepath,entity);
            if (response.getStatusCode().isError()){
                throw new PlatformException(response.getStatusCodeValue(),response.getBody()) ;
            }
        }catch (ResourceAccessException e) {
            log.error("No se ha podido conectar con ");
            throw new PlatformException(e);
        }
        catch (HttpClientErrorException e){
            log.error("No se ha podido crear el dispositivo: "+e.getMessage());
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
            throw new PlatformException(e);
        }catch (Exception e){
            log.error("No se ha podido crear el dispositivo: "+e.getMessage());
            throw new PlatformException(e);
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Add entity");
        }

    }


    public void updateEntity(String entity, String servicepath, String name) throws PlatformException {
        String url = orionURL + "v2/entities/"+name+"/attrs";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        HttpEntity<Object> request = new HttpEntity<>(entity, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.exchange(url, HttpMethod.PUT, request,String.class);
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            log.debug("Entity updated  servicepath: {}  reference: {}",servicepath,name);
            if (response.getStatusCode().isError()){
                throw new PlatformException(response.getStatusCode().value(),response.getBody()) ;
            }
        }

        catch (ResourceAccessException e){
            log.error("No se ha podido conectar con orion: "+e.getMessage());
            throw new PlatformException(e);
        }
        catch (HttpClientErrorException e){
            // handle the 40x
            log.error("No se ha podido actualizar el dispositivo: "+e.getMessage());
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
            throw new PlatformException(e.getRawStatusCode(),e.getResponseBodyAsString());
        }catch (Exception e){
            // handle the 50x
            log.error("No se ha podido actualizar el dispositivo: "+e.getMessage());
            throw new PlatformException(500,e.getMessage());
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Add entity");
        }
    }

    public void removeEntity(String reference, String servicepath) throws PlatformException {
        String url = orionURL + "v2/entities/"+reference;

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        RestTemplate restTemplate = new RestTemplate();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        restTemplate.setRequestFactory(requestFactory);
        HttpEntity<?> request = new HttpEntity<Object>(headers);
        ResponseEntity<String> response = null;
            log.debug("Entity removed  servicepath: {}  reference: {}",servicepath,reference);
        try {
            response = restTemplate.exchange(url, HttpMethod.DELETE, request, String.class);
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            if (response.getStatusCode().isError()){
                throw new PlatformException(response.getStatusCode().value(),response.getBody()) ;
            }
        }catch (HttpClientErrorException e){
            log.error("No se ha podido eliminar el dispositivo: "+e.getMessage());
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
            if(e.getStatusCode().value() != 404) {
                throw new PlatformException(e);
            }
        }catch (Exception e){
            log.error("No se ha podido eliminar el dispositivo: "+e.getMessage());
            throw new PlatformException(e);
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Remove entity");
        }

    }

    public void addDeviceIOT (JsonObject fiwareDevice, String servicepath) throws PlatformException {
        String url = iotHost + iotURL;
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        HttpEntity<Object> request = new HttpEntity<>(fiwareDevice.toString(), headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;

        try{
            response = restTemplate.postForEntity(url, request, String.class);
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            log.debug("Device added  servicepath: {}  device: {}",servicepath,fiwareDevice);
        }catch (ResourceAccessException e){
            log.error("No se ha podido conectar con orion: "+e.getMessage());
            throw new PlatformException(e);
        }
        catch (HttpClientErrorException e){
            // handle the 40x
            log.error("No se ha podido crear el dispositivo IoT: "+e.getMessage());
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
            throw new PlatformException(e.getRawStatusCode(),e.getResponseBodyAsString());
        }catch (Exception e){
            // handle the 50x
            log.error("No se ha podido crear el dispositivo IoT: "+e.getMessage());
            throw new PlatformException(500,e.getMessage());
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Add device Iot");
        }


    }

    public void putDeviceIOT (JsonObject fiwareDevice, String servicepath, String ref) throws HttpIOTAgentConnectionException, IOTAgentException {
        String url = iotHost + iotURL + "/" + ref;
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);
        JsonArray deviceArray = (JsonArray) fiwareDevice.get("devices");
        JsonObject device = (JsonObject) deviceArray.get(0);
        JsonArray attributes = (JsonArray) device.get("attributes");
        JsonObject attrs = new JsonObject();
        attrs.add("attributes", attributes);
        //TODO ahora mismo solo se están actualizando los atributos(fields), debería actualizarse por completo, pero no se como.


        HttpEntity<Object> request = new HttpEntity<>(attrs.toString(), headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;

        try{
            // restTemplate.put( url, request);
            response = restTemplate.exchange(url, HttpMethod.PUT, request,String.class);
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            log.debug("Device updated  {} ",fiwareDevice);
        }catch (ResourceAccessException e){
            throw new HttpIOTAgentConnectionException(e);
        }catch (HttpClientErrorException e){
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
        } catch (Exception ex){
            throw new IOTAgentException(ex);
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Put device Iot");
        }


    }

    public void addIOTGroup(IOTGroupDTO iotGroupDTO) throws HttpIOTAgentConnectionException, IOTAgentException {
        String url = iotHost + iotServices;
        Gson gson = new Gson();
        String iotGroupDTOJson = gson.toJson(iotGroupDTO);
        String servicepath = "airquality"; //TODO MOCK
        String entity = "{" +
            " \"services\": [" +
            iotGroupDTOJson +
            " ]" +
            "}";

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        HttpEntity<Object> request = new HttpEntity<>(entity, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;

        try {
           response = restTemplate.postForEntity(url, request, String.class);
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            log.debug("IoTGroup added entity_type:{} apikey: {}",iotGroupDTO.getEntity_type(),iotGroupDTO.getApikey());
        }catch (ResourceAccessException e){
            throw new HttpIOTAgentConnectionException(e);
        }catch (HttpClientErrorException e){
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
        }catch (Exception ex){
            throw new IOTAgentException(ex);
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Add Iot group");
        }
    }

    public void patchEntity(String json, String reference, String servicePathRef) throws HttpOrionConnectionException, OrionException {
        String url = orionURL + "/v2/entities/" + reference + "/attrs?options=keyValues";
        HttpHeaders headers = new HttpHeaders();
        RestTemplate restTemplate = new RestTemplate();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/" + servicePathRef);
        HttpEntity<Object> request = new HttpEntity<>(json, headers);
        ResponseEntity<String> response = null;

        restTemplate.setRequestFactory(requestFactory);

        try {
            response = restTemplate.exchange(url, HttpMethod.PATCH, request, String.class);
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            log.debug("Entity updated {}",reference);
        } catch (ResourceAccessException e) {
            throw new HttpOrionConnectionException(e);
        } catch (HttpClientErrorException e){
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
        } catch (Exception ex) {
            throw new OrionException(ex);
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Patch entity");
        }
    }

    public String getAllEntities() throws HttpOrionConnectionException, OrionException {
        String url = orionURL + "v2/entities/?options=keyValues";

        URL obj = null;
        try {
            obj = new URL(url);
        } catch (MalformedURLException e) {
            log.debug("Malformed URL: ",e);
        }
        HttpURLConnection con = null;
        try {
            if(obj != null) {
                con = (HttpURLConnection) obj.openConnection();
            }
        } catch (IOException e) {
            log.debug("IOException when trying to open a connection: ",e);
        }

        // optional default is GET
        try {
            if(con != null) {
                con.setRequestMethod("GET");
                //add request header
                con.setRequestProperty("fiware-service", fiware_service);
            }
        } catch (ProtocolException e) {
            log.debug("ProtocolException when trying to set properties: ",e);
        }


        if(con != null) {
            int responseCode = 0;
            try {
                responseCode = con.getResponseCode();
            } catch (IOException e) {
                log.debug("IOException when trying to connect: ", responseCode, e);
            }

            BufferedReader in = null;
            try {
                in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            } catch (IOException e) {
                log.debug("IOException when trying to get the InputStream from the connection ",e);
            }
            String inputLine = null;
            StringBuffer response = new StringBuffer();

            while (true) {
                try {
                    if (in != null && ((inputLine = in.readLine()) == null)) break;
                } catch (ResourceAccessException e) {
                    throw new HttpOrionConnectionException(e);
                } catch (Exception ex) {
                    throw new OrionException(ex);
                }
                response.append(inputLine);
            }
            try {
                in.close();
            } catch (IOException e) {
                log.debug("IOException when trying to close the BufferedReader ",e);
            }
            return response.toString();
        }
        return null;
    }

    public boolean entityExists(String entity, String servicepath, String reference) throws PlatformException {
        boolean exists;
        String url = orionURL + "v2/entities/"+reference;

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        RestTemplate restTemplate = new RestTemplate();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        restTemplate.setRequestFactory(requestFactory);

        try {
            HttpEntity<String> request = new HttpEntity<String>(headers);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
            exists = response.getStatusCode().is2xxSuccessful();
            return exists;

        }catch (ResourceAccessException e) {
            throw new PlatformException(e);
        }
        catch (HttpClientErrorException e){
            log.error("No se ha podido consultar el dispositivo: "+e.getMessage());
        }catch (Exception e){
            log.error("No se ha podido consultar el dispositivo: "+e.getMessage());
            throw new PlatformException(e);
        }
        return false;
    }

    public void removeIotDevice(String deviceId, String fiwareServicePath) throws PlatformException {

        String url = iotHost + iotURL+'/'+deviceId;

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+fiwareServicePath);

        RestTemplate restTemplate = new RestTemplate();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        restTemplate.setRequestFactory(requestFactory);
        HttpEntity<String> request = new HttpEntity<String>(headers);
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.exchange(url, HttpMethod.DELETE, request, String.class);
            resultStatusCode = response.getStatusCode().value();
            responseContent = response.toString();
            log.debug("Removed device {}",deviceId);
        }catch (ResourceAccessException e) {
            log.error("No se ha podido conectar con ");
            throw new PlatformException(e);
        }
        catch (HttpClientErrorException e){
            log.error("No se ha podido eliminar el dispositivo: "+e.getMessage());
            resultStatusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
        }catch (Exception e){
            log.error("No se ha podido eliminar el dispositivo: "+e.getMessage());
            throw new PlatformException(e);
        } finally {
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url, resultStatusCode,responseContent,"Remove iot device");
        }
    }

    public void setParameters(ResponseEntity<String> response) {
        if (response != null){
            resultStatusCode = response.getStatusCodeValue();
            if (response.getBody() != null) {
                responseContent = response.getBody();
            }
        }
    }
    public ResponseEntity<String> addSubscription(String subscriptionBody, String servicepath) throws PlatformException {
        String url = orionURL + subscription;

        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        HttpEntity<Object> request = new HttpEntity<>(subscriptionBody, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;
        HttpStatus resultStatusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        String responseContent = "";

        try
        {
            log.debug("Request" + request.toString());
            response = restTemplate.postForEntity( url, request , String.class );
            resultStatusCode = response.getStatusCode();
            responseContent = response.toString();
            if (response.getStatusCode().isError()){
                throw new PlatformException(response.getStatusCodeValue(), response.getBody()) ;
            }

            return response;

        }catch (HttpClientErrorException e){
            resultStatusCode = e.getStatusCode();
            responseContent = e.getMessage();
            log.error("No se ha podido crear la subscripción: "+e.getMessage());
            throw new PlatformException(e);
        }catch (ResourceAccessException e){
            responseContent = e.getMessage();
            log.error("No se ha podido conectar con orion: "+e.getMessage());
            throw new PlatformException(e);
        }
        catch (Exception e){
            responseContent = e.getMessage();
            log.error("No se ha podido crear la subscripción: "+e.getMessage());
            throw new PlatformException(e);
        }finally{
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url,resultStatusCode.value(),responseContent,"Add subscription");
        }
    }

    public void deleteSubscription(String platformId) throws PlatformException {
        String url = orionURL + subscription + "/" + platformId;

        HttpHeaders headers = new HttpHeaders();
        headers.set("fiware-service", fiware_service);

        HttpEntity<Object> request = new HttpEntity<>(headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;
        HttpStatus resultStatusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        String responseContent = "";

        try
        {
            log.debug("Request" + request.toString());
            response = restTemplate.exchange(url, HttpMethod.DELETE, request, String.class);
            resultStatusCode = response.getStatusCode();
            responseContent = response.toString();
            if (response.getStatusCode().isError()){
                throw new PlatformException(response.getStatusCodeValue(), response.getBody()) ;
            }
        }catch (HttpClientErrorException e){
            resultStatusCode = e.getStatusCode();
            responseContent = e.getMessage();
            log.error("No se ha podido eliminar la subscripción: "+e.getMessage());
            throw new PlatformException(e);
        }catch (ResourceAccessException e){
            responseContent = e.getMessage();
            log.error("No se ha podido conectar con orion: "+e.getMessage());
            throw new PlatformException(e);
        }
        catch (Exception e){
            responseContent = e.getMessage();
            log.error("No se ha podido eliminar la subscripción: "+e.getMessage());
            throw new PlatformException(e);
        }finally{
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url,resultStatusCode.value(),responseContent,"Delete subscription");
        }
    }
}

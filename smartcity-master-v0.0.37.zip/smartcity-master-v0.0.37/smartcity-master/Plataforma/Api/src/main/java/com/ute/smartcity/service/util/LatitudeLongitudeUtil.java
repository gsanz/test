package com.ute.smartcity.service.util;

public class LatitudeLongitudeUtil {
    protected static final String LATITUDE_PATTERN = "^(\\+|-)?(?:90(?:(?:\\.0{1,6})?)|(?:[0-9]|[1-8][0-9])(?:(?:\\.[0-9]{1,6})?))$";
    protected static final String LONGITUDE_PATTERN = "^(\\+|-)?(?:180(?:(?:\\.0{1,6})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\\.[0-9]{1,6})?))$";

    public static boolean isValidLatitude(String latitude) {
        return latitude.matches(LATITUDE_PATTERN);
    }

    public static boolean isValidLongitude(String longitude) {
        return longitude.matches(LONGITUDE_PATTERN);
    }
}

package com.ute.smartcity.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A Usuario.
 */
@Entity
@Table(name = "usuario")
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;

    public Usuario() {
        this.user = new User();
        this.doubleFactorAuthentication = false;
    }

    @Id
    private Long id;

    @NotNull
    @Size(min = 9, max = 50)
    @Column(name = "phone", nullable = false)
    private String phone = "";

    @NotNull
    @Column(name = "double_factor_authentication", nullable = false)
    private Boolean doubleFactorAuthentication;

    @Lob
    @Column(name = "image")
    private byte[] image;

    @Column(name = "image_content_type")
    private String imageContentType;

    @Column(name = "last_password_date")
    private ZonedDateTime lastPasswordDate;

    /**
     * Usuario (1) <---> (1) User
     */
    @ApiModelProperty(value = "Usuario (1) <---> (1) User")
    @OneToOne
    @JoinColumn(unique = true)
    @MapsId
    private User user;

    @ApiModelProperty(value = "Usuario (*) <---> (*) DeviceType")
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "usuario_devices_types",
        joinColumns = @JoinColumn(name = "usuarios_user_id", referencedColumnName = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "devices_types_id", referencedColumnName = "id"))
    private Set<DeviceType> devicesTypes = new HashSet<>();

    @Column(name = "double_auth_key")
    private String doubleAuthKey;

    @Column(name = "create_at_double_auth_key")
    private ZonedDateTime createAtDoubleAuthKey;

    @Column(name = "number_attempts_double_auth")
    private Integer numberAttemptsDoubleAuth;

    @ManyToOne
    @JsonIgnoreProperties("usuarios")
    private Provider provider;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public Usuario phone(String phone) {
        this.phone = phone;
        return this;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Boolean isDoubleFactorAuthentication() {
        return doubleFactorAuthentication;
    }

    public Usuario doubleFactorAuthentication(Boolean doubleFactorAuthentication) {
        this.doubleFactorAuthentication = doubleFactorAuthentication;
        return this;
    }

    public void setDoubleFactorAuthentication(Boolean doubleFactorAuthentication) {
        this.doubleFactorAuthentication = doubleFactorAuthentication;
    }

    public byte[] getImage() {
        return image;
    }

    public Usuario image(byte[] image) {
        this.image = image;
        return this;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getImageContentType() {
        return imageContentType;
    }

    public Usuario imageContentType(String imageContentType) {
        this.imageContentType = imageContentType;
        return this;
    }

    public void setImageContentType(String imageContentType) {
        this.imageContentType = imageContentType;
    }

    public User getUser() {
        return user;
    }

    public Usuario user(User user) {
        this.user = user;
        return this;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Set<DeviceType> getDevicesTypes() {
        return devicesTypes;
    }

    public Usuario devicesTypes(Set<DeviceType> deviceTypes) {
        this.devicesTypes = deviceTypes;
        return this;
    }

    public Usuario addDevicesTypes(DeviceType deviceType) {
        this.devicesTypes.add(deviceType);
        deviceType.getUsuarios().add(this);
        return this;
    }

    public Usuario removeDevicesTypes(DeviceType deviceType) {
        this.devicesTypes.remove(deviceType);
        deviceType.getUsuarios().remove(this);
        return this;
    }

    public void setDevicesTypes(Set<DeviceType> deviceTypes) {
        this.devicesTypes = deviceTypes;
    }

    public String getDoubleAuthKey() {
        return doubleAuthKey;
    }

    public Usuario doubleAuthKey(String doubleAuthKey) {
        this.doubleAuthKey = doubleAuthKey;
        return this;
    }

    public void setDoubleAuthKey(String doubleAuthKey) {
        this.doubleAuthKey = doubleAuthKey;
    }

    public ZonedDateTime getCreateAtDoubleAuthKey() {
        return createAtDoubleAuthKey;
    }

    public Usuario createAtDoubleAuthKey(ZonedDateTime createAtDoubleAuthKey) {
        this.createAtDoubleAuthKey = createAtDoubleAuthKey;
        return this;
    }

    public void setCreateAtDoubleAuthKey(ZonedDateTime createAtDoubleAuthKey) {
        this.createAtDoubleAuthKey = createAtDoubleAuthKey;
    }

    public Integer getNumberAttemptsDoubleAuth() {
        return numberAttemptsDoubleAuth;
    }

    public Usuario numberAttemptsDoubleAuth(Integer numberAttemptsDoubleAuth) {
        this.numberAttemptsDoubleAuth = numberAttemptsDoubleAuth;
        return this;
    }

    public Usuario lastPasswordDate(ZonedDateTime lastPasswordDate) {
        this.lastPasswordDate = lastPasswordDate;
        return this;
    }

    public void setNumberAttemptsDoubleAuth(Integer numberAttemptsDoubleAuth) {
        this.numberAttemptsDoubleAuth = numberAttemptsDoubleAuth;
    }

    public Provider getProvider() {
        return provider;
    }

    public Usuario provider(Provider provider) {
        this.provider = provider;
        return this;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Usuario usuario = (Usuario) o;
        if (usuario.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), usuario.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Usuario{" +
            "id=" + getId() +
            ", phone='" + getPhone() + "'" +
            ", doubleFactorAuthentication='" + isDoubleFactorAuthentication() + "'" +
            ", image='" + getImage() + "'" +
            ", imageContentType='" + getImageContentType() + "'" +
            ", doubleAuthKey='" + getDoubleAuthKey() + "'" +
            ", createAtDoubleAuthKey='" + getCreateAtDoubleAuthKey() + "'" +
            ", numberAttemptsDoubleAuth=" + getNumberAttemptsDoubleAuth() +
            ", lastPasswordDate='" + getLastPasswordDate() + "'" +
            "}";
    }

    public ZonedDateTime getLastPasswordDate() {
        return lastPasswordDate;
    }

    public void setLastPasswordDate(ZonedDateTime lastPasswordDate) {
        this.lastPasswordDate = lastPasswordDate;
    }
}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.service.AuditFiwarePlatformService;
import com.ute.smartcity.domain.AuditFiwarePlatform;
import com.ute.smartcity.repository.AuditFiwarePlatformRepository;
import com.ute.smartcity.service.dto.AuditFiwarePlatformDTO;
import com.ute.smartcity.service.mapper.AuditFiwarePlatformMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

/**
 * Service Implementation for managing AuditFiwarePlatform.
 */
@Service
@Transactional
public class AuditFiwarePlatformServiceImpl implements AuditFiwarePlatformService {

    private final Logger log = LoggerFactory.getLogger(AuditFiwarePlatformServiceImpl.class);

    private final AuditFiwarePlatformRepository auditFiwarePlatformRepository;

    private final AuditFiwarePlatformMapper auditFiwarePlatformMapper;

    public AuditFiwarePlatformServiceImpl(AuditFiwarePlatformRepository auditFiwarePlatformRepository, AuditFiwarePlatformMapper auditFiwarePlatformMapper) {
        this.auditFiwarePlatformRepository = auditFiwarePlatformRepository;
        this.auditFiwarePlatformMapper = auditFiwarePlatformMapper;
    }

    /**
     * Save a auditFiwarePlatform.
     *
     * @param auditFiwarePlatformDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public AuditFiwarePlatformDTO save(AuditFiwarePlatformDTO auditFiwarePlatformDTO) {
        log.debug("Request to save AuditFiwarePlatform : {}", auditFiwarePlatformDTO);
        AuditFiwarePlatform auditFiwarePlatform = auditFiwarePlatformMapper.toEntity(auditFiwarePlatformDTO);
        auditFiwarePlatform = auditFiwarePlatformRepository.save(auditFiwarePlatform);
        return auditFiwarePlatformMapper.toDto(auditFiwarePlatform);
    }

    /**
     * Get all the auditFiwarePlatforms.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<AuditFiwarePlatformDTO> findAll(Pageable pageable) {
        log.debug("Request to get all AuditFiwarePlatforms");
        return auditFiwarePlatformRepository.findAll(pageable)
            .map(auditFiwarePlatformMapper::toDto);
    }


    /**
     * Get one auditFiwarePlatform by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<AuditFiwarePlatformDTO> findOne(Long id) {
        log.debug("Request to get AuditFiwarePlatform : {}", id);
        return auditFiwarePlatformRepository.findById(id)
            .map(auditFiwarePlatformMapper::toDto);
    }

    /**
     * Delete the auditFiwarePlatform by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete AuditFiwarePlatform : {}", id);
        auditFiwarePlatformRepository.deleteById(id);
    }

    @Override
    public AuditFiwarePlatformDTO createFiwareAudit(String requestContent, String url, int responseCode, String responseContent, String type) {
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = new AuditFiwarePlatformDTO();

        auditFiwarePlatformDTO.setRequestContent(requestContent);
        auditFiwarePlatformDTO.setRequestUrl(url);
        auditFiwarePlatformDTO.setResponseCode(responseCode);
        auditFiwarePlatformDTO.setType(type);
        auditFiwarePlatformDTO.setResponseContent(responseContent);

        Instant dateNow = Instant.now().atZone(ZoneId.of("Europe/Madrid")).toInstant();
        dateNow = dateNow.plus(2, ChronoUnit.HOURS);
        auditFiwarePlatformDTO.setDate(dateNow);

        return save(auditFiwarePlatformDTO);
    }
}

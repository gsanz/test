package com.ute.smartcity.service.util;

import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.DeviceTypeDTO;

import static org.apache.commons.lang3.StringUtils.stripAccents;

public class EncodeSymbols {

    public DeviceDTO checkEncode(DeviceDTO deviceDTO){

        if(deviceDTO != null){
            String name = deviceDTO.getName();
            if (name != null && !name.isEmpty() ) {
                name = encodeString(name);
                deviceDTO.setName(name);
            }

            String reference = deviceDTO.getReference();
            if (reference != null && !reference.isEmpty()) {
                reference = encodeString(reference);
                deviceDTO.setReference(reference);
            }

            String observaciones = deviceDTO.getObservaciones();
            if(observaciones != null && !observaciones.isEmpty()) {
                observaciones = encodeString(observaciones);
                deviceDTO.setObservaciones(observaciones);
            }

            String direccion = deviceDTO.getLocation();
            if(direccion != null && !direccion.isEmpty()) {
                direccion = encodeString(direccion);
                deviceDTO.setLocation(direccion);
            }
        }

        return deviceDTO;
    }

    /**
     * Solo deja letras, numeros guión - y subrayado _
     * @param value
     * @return
     */
    public String encodeString(String value){

        String p = "";
        if (value!=null) {
            String s= "";
            s = stripAccents(value);
            p = s.replace("/", "");

            p = p.replaceAll("[^a-zA-Z0-9-_ ]", "");
        }
        return p;
    }

    public DeviceTypeDTO checkEncodeDeviceType(DeviceTypeDTO deviceTypeDTO) {

        if(deviceTypeDTO == null){
            return deviceTypeDTO;
        }

        String name = deviceTypeDTO.getName();
        if (name != null && !name.isEmpty() ) {
            name = encodeString(name);
            deviceTypeDTO.setName(name);
        }

        String reference = deviceTypeDTO.getReference();
        if (reference != null && !reference.isEmpty() ) {
            reference = encodeString(reference);
            deviceTypeDTO.setReference(reference);
        }

        String type = deviceTypeDTO.getType();
        if (type != null && !type.isEmpty() ) {
            type = encodeString(type);
            deviceTypeDTO.setType(type);
        }

        return deviceTypeDTO;
    }

    public String checkEncodeSingleString(String something) {
        something = encodeString(something);

        return something;
    }
}

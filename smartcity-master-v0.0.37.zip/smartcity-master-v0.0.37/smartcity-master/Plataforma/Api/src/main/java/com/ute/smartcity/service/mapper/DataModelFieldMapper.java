package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.DataModelField;
import com.ute.smartcity.domain.Fields;
import com.ute.smartcity.service.dto.DataModelFieldsDTO;
import com.ute.smartcity.service.dto.FieldsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * Mapper for the entity Fields and its DTO FieldsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface DataModelFieldMapper extends EntityMapper<DataModelFieldsDTO, DataModelField> {


    DataModelFieldsDTO toDto(DataModelField dataModelField);

    default DataModelField fromId(Long id) {
        if (id == null) {
            return null;
        }
        DataModelField dataModelField= new DataModelField();
        dataModelField.setId(id);
        return dataModelField;
    }
}

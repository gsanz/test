package com.ute.smartcity.repository;

import com.ute.smartcity.domain.Fields;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.util.List;


/**
 * Spring Data  repository for the Fields entity.
 */
@SuppressWarnings("unused")
@Repository
public interface FieldsRepository extends JpaRepository<Fields, Long>, JpaSpecificationExecutor<Fields> {
    List<Fields> findByDeviceTypeId(Long id);
}

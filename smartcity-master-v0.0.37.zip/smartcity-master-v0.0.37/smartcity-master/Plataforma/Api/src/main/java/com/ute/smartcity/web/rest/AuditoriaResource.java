package com.ute.smartcity.web.rest;

import com.ute.smartcity.service.AuditoriaService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.AuditoriaDTO;
import com.ute.smartcity.service.dto.AuditoriaCriteria;
import com.ute.smartcity.service.AuditoriaQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Auditoria.
 */
@RestController
@RequestMapping("/api")
public class AuditoriaResource {

    private final Logger log = LoggerFactory.getLogger(AuditoriaResource.class);

    private static final String ENTITY_NAME = "auditoria";

    private final AuditoriaService auditoriaService;

    private final AuditoriaQueryService auditoriaQueryService;

    public AuditoriaResource(AuditoriaService auditoriaService, AuditoriaQueryService auditoriaQueryService) {
        this.auditoriaService = auditoriaService;
        this.auditoriaQueryService = auditoriaQueryService;
    }

    /**
     * POST  /auditorias : Create a new auditoria.
     *
     * @param auditoriaDTO the auditoriaDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new auditoriaDTO, or with status 400 (Bad Request) if the auditoria has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/auditorias")
    public ResponseEntity<AuditoriaDTO> createAuditoria(@Valid @RequestBody AuditoriaDTO auditoriaDTO) throws URISyntaxException {
        log.debug("REST request to save Auditoria : {}", auditoriaDTO);
        if (auditoriaDTO.getId() != null) {
            throw new BadRequestAlertException("A new auditoria cannot already have an ID", ENTITY_NAME, "idexists");
        }
        AuditoriaDTO result = auditoriaService.save(auditoriaDTO);
        return ResponseEntity.created(new URI("/api/auditorias/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /auditorias : Updates an existing auditoria.
     *
     * @param auditoriaDTO the auditoriaDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated auditoriaDTO,
     * or with status 400 (Bad Request) if the auditoriaDTO is not valid,
     * or with status 500 (Internal Server Error) if the auditoriaDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/auditorias")
    public ResponseEntity<AuditoriaDTO> updateAuditoria(@Valid @RequestBody AuditoriaDTO auditoriaDTO) throws URISyntaxException {
        log.debug("REST request to update Auditoria : {}", auditoriaDTO);
        if (auditoriaDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        AuditoriaDTO result = auditoriaService.save(auditoriaDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, auditoriaDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /auditorias : get all the auditorias.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of auditorias in body
     */
    @GetMapping("/auditorias")
    public ResponseEntity<List<AuditoriaDTO>> getAllAuditorias(AuditoriaCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Auditorias by criteria: {}", criteria);
        Page<AuditoriaDTO> page = auditoriaQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/auditorias");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /auditorias/count : count all the auditorias.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/auditorias/count")
    public ResponseEntity<Long> countAuditorias(AuditoriaCriteria criteria) {
        log.debug("REST request to count Auditorias by criteria: {}", criteria);
        return ResponseEntity.ok().body(auditoriaQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /auditorias/:id : get the "id" auditoria.
     *
     * @param id the id of the auditoriaDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the auditoriaDTO, or with status 404 (Not Found)
     */
    @GetMapping("/auditorias/{id}")
    public ResponseEntity<AuditoriaDTO> getAuditoria(@PathVariable Long id) {
        log.debug("REST request to get Auditoria : {}", id);
        Optional<AuditoriaDTO> auditoriaDTO = auditoriaService.findOne(id);
        return ResponseUtil.wrapOrNotFound(auditoriaDTO);
    }

    /**
     * DELETE  /auditorias/:id : delete the "id" auditoria.
     *
     * @param id the id of the auditoriaDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/auditorias/{id}")
    public ResponseEntity<Void> deleteAuditoria(@PathVariable Long id) {
        log.debug("REST request to delete Auditoria : {}", id);
        auditoriaService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

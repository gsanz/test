package com.ute.smartcity.service.exception;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.web.rest.DeviceResourceExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NullDevicePropertyException extends Exception {
    private final Logger log = LoggerFactory.getLogger(DeviceResourceExt.class);
    public NullDevicePropertyException(NullPointerException e, DeviceDTO device) {
        log.error("Can't parse the device to a fiware device: " + device + " {" + e.getMessage() + "}");
    }
}

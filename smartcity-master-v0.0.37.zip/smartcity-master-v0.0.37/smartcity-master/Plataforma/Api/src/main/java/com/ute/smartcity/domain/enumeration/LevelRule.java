package com.ute.smartcity.domain.enumeration;

/**
 * The LevelRule enumeration.
 */
public enum LevelRule {
    LOW, NORMAL, HIGH, CRITICAL
}

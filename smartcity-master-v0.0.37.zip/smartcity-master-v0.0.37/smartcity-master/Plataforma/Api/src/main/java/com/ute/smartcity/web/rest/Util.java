package com.ute.smartcity.web.rest;

import com.ute.smartcity.service.*;
import com.ute.smartcity.service.platform.fiware.FiwareOrionService;
import com.ute.smartcity.service.dto.IOTGroupDTO;
import com.ute.smartcity.service.exception.*;
import com.ute.smartcity.service.exception.fiware.HttpIOTAgentConnectionException;
import com.ute.smartcity.service.exception.fiware.HttpOrionConnectionException;
import com.ute.smartcity.service.exception.fiware.IOTAgentException;
import com.ute.smartcity.service.exception.fiware.OrionException;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.EntityFiwareAdapter;
import com.ute.smartcity.service.platform.fiware.FiwareOrionService;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@Api(value="Util", description="Alert Resource",tags = "alert-resource")
public class Util {
    private final Logger log = LoggerFactory.getLogger(Util.class);

    private static final String ENTITY_NAME = "util";

    private final UpdateDeviceDataService updateDeviceDataService;

    private final DeviceMapper deviceMapper;

    private final FiwareOrionService fiwareOrionService;

    private final EntityFiwareAdapter entityFiwareAdapter;

    public Util(UpdateDeviceDataService updateDeviceDataService, DeviceMapper deviceMapper, FiwareOrionService fiwareOrionService, EntityFiwareAdapter entityFiwareAdapter) {
        this.updateDeviceDataService = updateDeviceDataService;
        this.deviceMapper = deviceMapper;
        this.fiwareOrionService = fiwareOrionService;
        this.entityFiwareAdapter = entityFiwareAdapter;
    }


    /**
     * GET  /alerts : change the state of alert to close
     *
     * @return the ResponseEntity with status 200 (OK) and with body the updated alert,
     * or with status 400 (Bad Request) if the alert is not valid,
     * or with status 500 (Internal Server Error) if the alert couldn't be updated
     */
    @GetMapping("/util/fiware/getDevices")
    @Timed
    public void getFiwareDevices() throws IllegalTypeException, HttpOrionConnectionException, OrionException {
        updateDeviceDataService.syncDevices();
    }


    @PostMapping("/util/fiware/registerIOTGroup")
    @Timed
    public void registerIOTGroup() throws HttpIOTAgentConnectionException, IOTAgentException {
        IOTGroupDTO iotGroupDTO = new IOTGroupDTO();
        iotGroupDTO.setApikey("4jggokgpepnvsb2uv4s40d5916");
        iotGroupDTO.setCbroker("http://orion:1026");
        iotGroupDTO.setEntity_type("AirQualityObserved");
        iotGroupDTO.setResource("/iot/d");
        fiwareOrionService.addIOTGroup(iotGroupDTO);
    }
}

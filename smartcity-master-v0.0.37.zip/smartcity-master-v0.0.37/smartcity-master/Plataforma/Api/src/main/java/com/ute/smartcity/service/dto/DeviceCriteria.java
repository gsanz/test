package com.ute.smartcity.service.dto;

import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;
import io.github.jhipster.service.filter.ZonedDateTimeFilter;

import java.io.Serializable;
import java.util.Objects;

/**
 * Criteria class for the Device entity. This class is used in DeviceResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /devices?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class DeviceCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter search;

    private StringFilter reference;

    private StringFilter state;

    private StringFilter name;

    private StringFilter location;

    private StringFilter longitude;

    private StringFilter latitude;

    private ZonedDateTimeFilter createAt;

    private ZonedDateTimeFilter deleteAt;

    private ZonedDateTimeFilter updateAt;

    private LongFilter alertId;

    private LongFilter fieldsId;

    private LongFilter deviceTypeId;

    private LongFilter zoneId;

    private LongFilter providerId;

    private LongFilter protocolId;

    private LongFilter ruleId;

    public DeviceCriteria() {
    }

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getReference() {
        return reference;
    }

    public void setReference(StringFilter reference) {
        this.reference = reference;
    }

    public StringFilter getState() {
        return state;
    }

    public void setState(StringFilter state) {
        this.state = state;
    }

    public StringFilter getName() {
        return name;
    }

    public void setName(StringFilter name) {
        this.name = name;
    }

    public StringFilter getLocation() {
        return location;
    }

    public void setLocation(StringFilter location) {
        this.location = location;
    }

    public StringFilter getLongitude() {
        return longitude;
    }

    public void setLongitude(StringFilter longitude) {
        this.longitude = longitude;
    }

    public StringFilter getLatitude() {
        return latitude;
    }

    public void setLatitude(StringFilter latitude) {
        this.latitude = latitude;
    }

    public ZonedDateTimeFilter getCreateAt() {
        return createAt;
    }

    public void setCreateAt(ZonedDateTimeFilter createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTimeFilter getDeleteAt() {
        return deleteAt;
    }

    public void setDeleteAt(ZonedDateTimeFilter deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTimeFilter getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(ZonedDateTimeFilter updateAt) {
        this.updateAt = updateAt;
    }

    public LongFilter getAlertId() {
        return alertId;
    }

    public void setAlertId(LongFilter alertId) {
        this.alertId = alertId;
    }

    public LongFilter getFieldsId() {
        return fieldsId;
    }

    public void setFieldsId(LongFilter fieldsId) {
        this.fieldsId = fieldsId;
    }

    public LongFilter getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(LongFilter deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    public LongFilter getZoneId() {
        return zoneId;
    }

    public void setZoneId(LongFilter zoneId) {
        this.zoneId = zoneId;
    }

    public LongFilter getProviderId() {
        return providerId;
    }

    public void setProviderId(LongFilter providerId) {
        this.providerId = providerId;
    }

    public LongFilter getProtocolId() {
        return protocolId;
    }

    public void setProtocolId(LongFilter protocolId) {
        this.protocolId = protocolId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final DeviceCriteria that = (DeviceCriteria) o;
        return
            Objects.equals(id, that.id) &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(state, that.state) &&
                Objects.equals(name, that.name) &&
                Objects.equals(location, that.location) &&
                Objects.equals(longitude, that.longitude) &&
                Objects.equals(latitude, that.latitude) &&
                Objects.equals(fieldsId, that.fieldsId) &&
                Objects.equals(deviceTypeId, that.deviceTypeId) &&
                Objects.equals(zoneId, that.zoneId) &&
                Objects.equals(providerId, that.providerId) &&
                Objects.equals(protocolId, that.protocolId) &&
                Objects.equals(ruleId, that.ruleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            id,
            reference,
            state,
            name,
            location,
            longitude,
            latitude,
            fieldsId,
            deviceTypeId,
            zoneId,
            providerId,
            protocolId,
            ruleId
        );
    }

    @Override
    public String toString() {
        return "DeviceCriteria{" +
            (id != null ? "id=" + id + ", " : "") +
            (reference != null ? "reference=" + reference + ", " : "") +
            (state != null ? "state=" + state + ", " : "") +
            (name != null ? "name=" + name + ", " : "") +
            (location != null ? "location=" + location + ", " : "") +
            (longitude != null ? "longitude=" + longitude + ", " : "") +
            (latitude != null ? "latitude=" + latitude + ", " : "") +
            (alertId != null ? "alertId=" + alertId + ", " : "") +
            (fieldsId != null ? "fieldsId=" + fieldsId + ", " : "") +
            (deviceTypeId != null ? "deviceTypeId=" + deviceTypeId + ", " : "") +
            (zoneId != null ? "zoneId=" + zoneId + ", " : "") +
            (providerId != null ? "providerId=" + providerId + ", " : "") +
            (protocolId != null ? "protocolId=" + protocolId + ", " : "") +
            (ruleId != null ? "ruleId=" + ruleId + ", " : "") +
            "}";
    }

    public StringFilter getSearch() {
        return search;
    }

    public void setSearch(StringFilter search) {
        this.search = search;
    }

    public LongFilter getRuleId() {
        return ruleId;
    }

    public void setRuleId(LongFilter ruleId) {
        this.ruleId = ruleId;
    }
}

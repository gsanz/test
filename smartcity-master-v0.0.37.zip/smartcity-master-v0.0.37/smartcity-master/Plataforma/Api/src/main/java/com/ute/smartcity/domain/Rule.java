package com.ute.smartcity.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ute.smartcity.domain.enumeration.EvaluationType;
import com.ute.smartcity.domain.enumeration.LevelRule;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A Rule.
 */
@Entity
@Table(name = "rule")
public class Rule implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "reference", nullable = false)
    private String reference;

    @NotNull
    @Size(max = 250)
    @Column(name = "description", length = 250, nullable = false)
    private String description;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "level_rule", nullable = false)
    private LevelRule levelRule;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "evaluation_type", nullable = false)
    private EvaluationType evaluationType;

    @Column(name = "inactivity_time", precision = 10, scale = 2)
    private BigDecimal inactivityTime;

    @Size(max = 3500)
    @Column(name = "text_epl", length = 3500)
    private String textEPL;

    @Column(name = "create_at")
    private ZonedDateTime createAt;

    @Column(name = "delete_at")
    private ZonedDateTime deleteAt;

    @Column(name = "update_at")
    private ZonedDateTime updateAt;

    @OneToMany(mappedBy = "rule", fetch=FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<RuleCompareFields> ruleCompareFields = new HashSet<>();

    @OneToMany(mappedBy = "rule",fetch=FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<RuleAction> ruleActions = new HashSet<>();

    @ManyToOne
    @JsonIgnoreProperties("rules")
    private DeviceType deviceType;

    @ManyToMany
    @JoinTable(name = "rule_device",
               joinColumns = @JoinColumn(name = "rule_id", referencedColumnName = "id"),
               inverseJoinColumns = @JoinColumn(name = "device_id", referencedColumnName = "id"))
    private Set<Device> devices = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReference() {
        return reference;
    }

    public Rule reference(String reference) {
        this.reference = reference;
        return this;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getDescription() {
        return description;
    }

    public Rule description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LevelRule getLevelRule() {
        return levelRule;
    }

    public Rule levelRule(LevelRule levelRule) {
        this.levelRule = levelRule;
        return this;
    }

    public void setLevelRule(LevelRule levelRule) {
        this.levelRule = levelRule;
    }

    public EvaluationType getEvaluationType() {
        return evaluationType;
    }

    public Rule evaluationType(EvaluationType evaluationType) {
        this.evaluationType = evaluationType;
        return this;
    }

    public void setEvaluationType(EvaluationType evaluationType) {
        this.evaluationType = evaluationType;
    }

    public BigDecimal getInactivityTime() {
        return inactivityTime;
    }

    public Rule inactivityTime(BigDecimal inactivityTime) {
        this.inactivityTime = inactivityTime;
        return this;
    }

    public void setInactivityTime(BigDecimal inactivityTime) {
        this.inactivityTime = inactivityTime;
    }

    public String getTextEPL() {
        return textEPL;
    }

    public Rule textEPL(String textEPL) {
        this.textEPL = textEPL;
        return this;
    }

    public void setTextEPL(String textEPL) {
        this.textEPL = textEPL;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public Rule createAt(ZonedDateTime createAt) {
        this.createAt = createAt;
        return this;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTime getDeleteAt() {
        return deleteAt;
    }

    public Rule deleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
        return this;
    }

    public void setDeleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTime getUpdateAt() {
        return updateAt;
    }

    public Rule updateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
        return this;
    }

    public void setUpdateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public Set<RuleCompareFields> getRuleCompareFields() {
        return ruleCompareFields;
    }

    public Rule ruleCompareFields(Set<RuleCompareFields> ruleCompareFields) {
        this.ruleCompareFields = ruleCompareFields;
        return this;
    }

    public Rule addRuleCompareFields(RuleCompareFields ruleCompareFields) {
        this.ruleCompareFields.add(ruleCompareFields);
        ruleCompareFields.setRule(this);
        return this;
    }

    public Rule removeRuleCompareFields(RuleCompareFields ruleCompareFields) {
        this.ruleCompareFields.remove(ruleCompareFields);
        ruleCompareFields.setRule(null);
        return this;
    }

    public void setRuleCompareFields(Set<RuleCompareFields> ruleCompareFields) {
        this.ruleCompareFields = ruleCompareFields;
    }

    public Set<RuleAction> getRuleActions() {
        return ruleActions;
    }

    public Rule ruleActions(Set<RuleAction> ruleActions) {
        this.ruleActions = ruleActions;
        return this;
    }

    public Rule addRuleAction(RuleAction ruleAction) {
        this.ruleActions.add(ruleAction);
        ruleAction.setRule(this);
        return this;
    }

    public Rule removeRuleAction(RuleAction ruleAction) {
        this.ruleActions.remove(ruleAction);
        ruleAction.setRule(null);
        return this;
    }

    public void setRuleActions(Set<RuleAction> ruleActions) {
        this.ruleActions = ruleActions;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public Rule deviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
        return this;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    public Set<Device> getDevices() {
        return devices;
    }

    public Rule devices(Set<Device> devices) {
        this.devices = devices;
        return this;
    }

    public Rule addDevice(Device device) {
        this.devices.add(device);
        device.getRules().add(this);
        return this;
    }

    public Rule removeDevice(Device device) {
        this.devices.remove(device);
        device.getRules().remove(this);
        return this;
    }

    public void setDevices(Set<Device> devices) {
        this.devices = devices;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Rule rule = (Rule) o;
        if (rule.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), rule.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Rule{" +
            "id=" + getId() +
            ", reference='" + getReference() + "'" +
            ", description='" + getDescription() + "'" +
            ", levelRule='" + getLevelRule() + "'" +
            ", evaluationType='" + getEvaluationType() + "'" +
            ", inactivityTime=" + getInactivityTime() +
            ", textEPL='" + getTextEPL() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", deleteAt='" + getDeleteAt() + "'" +
            ", updateAt='" + getUpdateAt() + "'" +
            "}";
    }
}

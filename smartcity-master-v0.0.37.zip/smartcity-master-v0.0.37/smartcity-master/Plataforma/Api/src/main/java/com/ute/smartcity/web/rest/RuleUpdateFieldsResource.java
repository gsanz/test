package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.RuleUpdateFieldsService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.RuleUpdateFieldsDTO;
import com.ute.smartcity.service.dto.RuleUpdateFieldsCriteria;
import com.ute.smartcity.service.RuleUpdateFieldsQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing RuleUpdateFields.
 */
@RestController
@RequestMapping("/api")
public class RuleUpdateFieldsResource {

    private final Logger log = LoggerFactory.getLogger(RuleUpdateFieldsResource.class);

    private static final String ENTITY_NAME = "ruleUpdateFields";

    private final RuleUpdateFieldsService ruleUpdateFieldsService;

    private final RuleUpdateFieldsQueryService ruleUpdateFieldsQueryService;

    public RuleUpdateFieldsResource(RuleUpdateFieldsService ruleUpdateFieldsService, RuleUpdateFieldsQueryService ruleUpdateFieldsQueryService) {
        this.ruleUpdateFieldsService = ruleUpdateFieldsService;
        this.ruleUpdateFieldsQueryService = ruleUpdateFieldsQueryService;
    }

    /**
     * POST  /rule-update-fields : Create a new ruleUpdateFields.
     *
     * @param ruleUpdateFieldsDTO the ruleUpdateFieldsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new ruleUpdateFieldsDTO, or with status 400 (Bad Request) if the ruleUpdateFields has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/rule-update-fields")
    public ResponseEntity<RuleUpdateFieldsDTO> createRuleUpdateFields(@RequestBody RuleUpdateFieldsDTO ruleUpdateFieldsDTO) throws URISyntaxException {
        log.debug("REST request to save RuleUpdateFields : {}", ruleUpdateFieldsDTO);
        if (ruleUpdateFieldsDTO.getId() != null) {
            throw new BadRequestAlertException("A new ruleUpdateFields cannot already have an ID", ENTITY_NAME, "idexists");
        }
        RuleUpdateFieldsDTO result = ruleUpdateFieldsService.save(ruleUpdateFieldsDTO);
        return ResponseEntity.created(new URI("/api/rule-update-fields/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /rule-update-fields : Updates an existing ruleUpdateFields.
     *
     * @param ruleUpdateFieldsDTO the ruleUpdateFieldsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated ruleUpdateFieldsDTO,
     * or with status 400 (Bad Request) if the ruleUpdateFieldsDTO is not valid,
     * or with status 500 (Internal Server Error) if the ruleUpdateFieldsDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/rule-update-fields")
    public ResponseEntity<RuleUpdateFieldsDTO> updateRuleUpdateFields(@RequestBody RuleUpdateFieldsDTO ruleUpdateFieldsDTO) throws URISyntaxException {
        log.debug("REST request to update RuleUpdateFields : {}", ruleUpdateFieldsDTO);
        if (ruleUpdateFieldsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        RuleUpdateFieldsDTO result = ruleUpdateFieldsService.save(ruleUpdateFieldsDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, ruleUpdateFieldsDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /rule-update-fields : get all the ruleUpdateFields.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of ruleUpdateFields in body
     */
    @GetMapping("/rule-update-fields")
    public ResponseEntity<List<RuleUpdateFieldsDTO>> getAllRuleUpdateFields(RuleUpdateFieldsCriteria criteria, Pageable pageable) {
        log.debug("REST request to get RuleUpdateFields by criteria: {}", criteria);
        Page<RuleUpdateFieldsDTO> page = ruleUpdateFieldsQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/rule-update-fields");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /rule-update-fields/count : count all the ruleUpdateFields.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/rule-update-fields/count")
    public ResponseEntity<Long> countRuleUpdateFields(RuleUpdateFieldsCriteria criteria) {
        log.debug("REST request to count RuleUpdateFields by criteria: {}", criteria);
        return ResponseEntity.ok().body(ruleUpdateFieldsQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /rule-update-fields/:id : get the "id" ruleUpdateFields.
     *
     * @param id the id of the ruleUpdateFieldsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the ruleUpdateFieldsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/rule-update-fields/{id}")
    public ResponseEntity<RuleUpdateFieldsDTO> getRuleUpdateFields(@PathVariable Long id) {
        log.debug("REST request to get RuleUpdateFields : {}", id);
        Optional<RuleUpdateFieldsDTO> ruleUpdateFieldsDTO = ruleUpdateFieldsService.findOne(id);
        return ResponseUtil.wrapOrNotFound(ruleUpdateFieldsDTO);
    }

    /**
     * DELETE  /rule-update-fields/:id : delete the "id" ruleUpdateFields.
     *
     * @param id the id of the ruleUpdateFieldsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/rule-update-fields/{id}")
    public ResponseEntity<Void> deleteRuleUpdateFields(@PathVariable Long id) {
        log.debug("REST request to delete RuleUpdateFields : {}", id);
        ruleUpdateFieldsService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

package com.ute.smartcity.service;

import java.util.List;

import javax.persistence.criteria.JoinType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.ute.smartcity.domain.Subscriptions;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.SubscriptionsRepository;
import com.ute.smartcity.service.dto.SubscriptionsCriteria;
import com.ute.smartcity.service.dto.SubscriptionsDTO;
import com.ute.smartcity.service.mapper.SubscriptionsMapper;

/**
 * Service for executing complex queries for Subscriptions entities in the database.
 * The main input is a {@link SubscriptionsCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link SubscriptionsDTO} or a {@link Page} of {@link SubscriptionsDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class SubscriptionsQueryService extends QueryService<Subscriptions> {

    private final Logger log = LoggerFactory.getLogger(SubscriptionsQueryService.class);

    private final SubscriptionsRepository subscriptionsRepository;

    private final SubscriptionsMapper subscriptionsMapper;

    public SubscriptionsQueryService(SubscriptionsRepository subscriptionsRepository, SubscriptionsMapper subscriptionsMapper) {
        this.subscriptionsRepository = subscriptionsRepository;
        this.subscriptionsMapper = subscriptionsMapper;
    }

    /**
     * Return a {@link List} of {@link SubscriptionsDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<SubscriptionsDTO> findByCriteria(SubscriptionsCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<Subscriptions> specification = createSpecification(criteria);
        return subscriptionsMapper.toDto(subscriptionsRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link SubscriptionsDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page     The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<SubscriptionsDTO> findByCriteria(SubscriptionsCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<Subscriptions> specification = createSpecification(criteria);
        return subscriptionsRepository.findAll(specification, page)
            .map(subscriptionsMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(SubscriptionsCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<Subscriptions> specification = createSpecification(criteria);
        return subscriptionsRepository.count(specification);
    }

    /**
     * Function to convert SubscriptionsCriteria to a {@link Specification}
     */
    private Specification<Subscriptions> createSpecification(SubscriptionsCriteria criteria) {
        Specification<Subscriptions> specification = Specification.where(null);
        if (criteria == null) {
            return specification;
        }
        if (criteria.getId() != null) {
            specification = specification.and(buildSpecification(criteria.getId(), Subscriptions_.id));
        }
        if (criteria.getName() != null) {
            specification = specification.and(buildStringSpecification(criteria.getName(), Subscriptions_.name));
        }
        if (criteria.getDescription() != null) {
            specification = specification.and(buildStringSpecification(criteria.getDescription(), Subscriptions_.description));
        }
        if (criteria.getEndpoint() != null) {
            specification = specification.and(buildStringSpecification(criteria.getEndpoint(), Subscriptions_.endpoint));
        }
        if (criteria.getPlatformId() != null) {
            specification = specification.and(buildStringSpecification(criteria.getPlatformId(), Subscriptions_.platformId));
        }
        if (criteria.getCreateAt() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getCreateAt(), Subscriptions_.createAt));
        }
        if (criteria.getState() != null) {
            specification = specification.and(buildStringSpecification(criteria.getState(), Subscriptions_.state));
        }
        if (criteria.getDeviceTypeId() != null) {
            specification = specification.and(buildSpecification(criteria.getDeviceTypeId(),
                root -> root.join(Subscriptions_.deviceType, JoinType.LEFT).get(DeviceType_.id)));
        }
        return specification;
    }
}

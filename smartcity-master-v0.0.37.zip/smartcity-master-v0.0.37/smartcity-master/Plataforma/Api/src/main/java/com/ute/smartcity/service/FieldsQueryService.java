package com.ute.smartcity.service;

import java.util.List;

import javax.persistence.criteria.JoinType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.ute.smartcity.domain.Fields;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.FieldsRepository;
import com.ute.smartcity.service.dto.FieldsCriteria;
import com.ute.smartcity.service.dto.FieldsDTO;
import com.ute.smartcity.service.mapper.FieldsMapper;

/**
 * Service for executing complex queries for Fields entities in the database.
 * The main input is a {@link FieldsCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link FieldsDTO} or a {@link Page} of {@link FieldsDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class FieldsQueryService extends QueryService<Fields> {

    private final Logger log = LoggerFactory.getLogger(FieldsQueryService.class);

    private final FieldsRepository fieldsRepository;

    private final FieldsMapper fieldsMapper;

    public FieldsQueryService(FieldsRepository fieldsRepository, FieldsMapper fieldsMapper) {
        this.fieldsRepository = fieldsRepository;
        this.fieldsMapper = fieldsMapper;
    }

    /**
     * Return a {@link List} of {@link FieldsDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<FieldsDTO> findByCriteria(FieldsCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<Fields> specification = createSpecification(criteria);
        return fieldsMapper.toDto(fieldsRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link FieldsDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page     The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<FieldsDTO> findByCriteria(FieldsCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<Fields> specification = createSpecification(criteria);
        return fieldsRepository.findAll(specification, page)
            .map(fieldsMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(FieldsCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<Fields> specification = createSpecification(criteria);
        return fieldsRepository.count(specification);
    }

    /**
     * Function to convert FieldsCriteria to a {@link Specification}
     */
    private Specification<Fields> createSpecification(FieldsCriteria criteria) {
        Specification<Fields> specification = Specification.where(null);
        if (criteria == null) {
            return specification;
        }
        if (criteria.getId() != null) {
            specification = specification.and(buildSpecification(criteria.getId(), Fields_.id));
        }
        if (criteria.getName() != null) {
            specification = specification.and(buildStringSpecification(criteria.getName(), Fields_.name));
        }
        if (criteria.getAbbreviation() != null) {
            specification = specification.and(buildStringSpecification(criteria.getAbbreviation(), Fields_.abbreviation));
        }
        if (criteria.getDescription() != null) {
            specification = specification.and(buildStringSpecification(criteria.getDescription(), Fields_.description));
        }
        if (criteria.getType() != null) {
            specification = specification.and(buildStringSpecification(criteria.getType(), Fields_.type));
        }
        if (criteria.getUnitOfmeasure() != null) {
            specification = specification.and(buildStringSpecification(criteria.getUnitOfmeasure(), Fields_.unitOfmeasure));
        }
        if (criteria.getValue() != null) {
            specification = specification.and(buildStringSpecification(criteria.getValue(), Fields_.value));
        }
        if (criteria.getDeviceId() != null) {
            specification = specification.and(buildSpecification(criteria.getDeviceId(),
                root -> root.join(Fields_.device, JoinType.LEFT).get(Device_.id)));
        }
        if (criteria.getDeviceTypeId() != null) {
            specification = specification.and(buildSpecification(criteria.getDeviceTypeId(),
                root -> root.join(Fields_.deviceType, JoinType.LEFT).get(DeviceType_.id)));
        }
        return specification;
    }
}

package com.ute.smartcity.service.dto;
import javax.persistence.Lob;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A DTO for the Device entity.
 */
public class DeviceDTO implements Serializable {

    private Long id;

    @NotNull
    private String reference;

    private String state;

    @NotNull
    private String name;

    private String location;

    @NotNull
    private String longitude;

    @NotNull
    private String latitude;

    @Lob
    private String observaciones;



    private ZonedDateTime createAt;

    private ZonedDateTime deleteAt;

    private ZonedDateTime updateAt;


    private Long deviceTypeId;

    private String deviceTypeName;

    private String deviceTypeReference;

    private String deviceTypeType;

    private Long zoneId;

    private String zoneName;

    private Long providerId;

    private String providerName;

    private Long protocolId;

    private String protocolName;

    private Set<FieldsDTO> Fields = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTime getDeleteAt() {
        return deleteAt;
    }

    public void setDeleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTime getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public Long getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(Long deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    public String getDeviceTypeName() {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    public Long getZoneId() {
        return zoneId;
    }

    public void setZoneId(Long zoneId) {
        this.zoneId = zoneId;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public Long getProviderId() {
        return providerId;
    }

    public void setProviderId(Long providerId) {
        this.providerId = providerId;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public Long getProtocolId() {
        return protocolId;
    }

    public void setProtocolId(Long protocolId) {
        this.protocolId = protocolId;
    }

    public String getProtocolName() {
        return protocolName;
    }

    public void setProtocolName(String protocolName) {
        this.protocolName = protocolName;
    }

    public Set<FieldsDTO> getFields() {
        return Fields;
    }

    public void setFields(Set<FieldsDTO> fields) {
        Fields = fields;
    }

    public String getDeviceTypeType() {
        return deviceTypeType;
    }

    public void setDeviceTypeType(String deviceTypeType) {
        this.deviceTypeType = deviceTypeType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DeviceDTO deviceDTO = (DeviceDTO) o;
        if (deviceDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), deviceDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "DeviceDTO{" +
            "id=" + getId() +
            ", reference='" + getReference() + "'" +
            ", state='" + getState() + "'" +
            ", name='" + getName() + "'" +
            ", location='" + getLocation() + "'" +
            ", longitude='" + getLongitude() + "'" +
            ", latitude='" + getLatitude() + "'" +
            ", observaciones='" + getObservaciones() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", deleteAt='" + getDeleteAt() + "'" +
            ", updateAt='" + getUpdateAt() + "'" +
            ", deviceType=" + getDeviceTypeId() +
            ", deviceType='" + getDeviceTypeName() + "'" +
            ", zone=" + getZoneId() +
            ", zone='" + getZoneName() + "'" +
            ", provider=" + getProviderId() +
            ", provider='" + getProviderName() + "'" +
            ", protocol=" + getProtocolId() +
            ", protocol='" + getProtocolName() + "'" +
            "}";
    }

    public String getDeviceTypeReference() {
        return deviceTypeReference;
    }

    public void setDeviceTypeReference(String deviceTypeReference) {
        this.deviceTypeReference = deviceTypeReference;
    }
}

package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.SubscriptionTemplateDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity SubscriptionTemplate and its DTO SubscriptionTemplateDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface SubscriptionTemplateMapper extends EntityMapper<SubscriptionTemplateDTO, SubscriptionTemplate> {



    default SubscriptionTemplate fromId(Long id) {
        if (id == null) {
            return null;
        }
        SubscriptionTemplate subscriptionTemplate = new SubscriptionTemplate();
        subscriptionTemplate.setId(id);
        return subscriptionTemplate;
    }
}

package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.ProtocolDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Protocol and its DTO ProtocolDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ProtocolMapper extends EntityMapper<ProtocolDTO, Protocol> {



    default Protocol fromId(Long id) {
        if (id == null) {
            return null;
        }
        Protocol protocol = new Protocol();
        protocol.setId(id);
        return protocol;
    }
}

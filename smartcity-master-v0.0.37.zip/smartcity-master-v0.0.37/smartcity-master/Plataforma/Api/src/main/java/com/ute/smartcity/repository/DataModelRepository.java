package com.ute.smartcity.repository;

import com.ute.smartcity.domain.DataModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the DeviceType entity.
 */
@SuppressWarnings("unused")
@Repository
public interface DataModelRepository extends JpaRepository<DataModel, Long>, JpaSpecificationExecutor<DataModel> {

}

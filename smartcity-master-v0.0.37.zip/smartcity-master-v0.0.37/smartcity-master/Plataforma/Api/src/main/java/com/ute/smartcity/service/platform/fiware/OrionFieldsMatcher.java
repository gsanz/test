package com.ute.smartcity.service.platform.fiware;


import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ute.smartcity.service.dto.FieldsDTO;
import com.ute.smartcity.service.exception.IllegalTypeException;
import com.ute.smartcity.service.util.LatitudeLongitudeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.stripAccents;

@Component
public class OrionFieldsMatcher {

    private final Logger log = LoggerFactory.getLogger(OrionFieldsMatcher.class);

    public String matchAll(JsonObject contentObj, Optional<List<FieldsDTO>> campos) throws IllegalTypeException {

        JsonObject messageJson = new JsonObject();

        if(campos.isPresent()){
        for (FieldsDTO field : campos.get()) {
            String fieldname = encodeString(field.getName());
            String type = field.getType();
            JsonElement element = contentObj.get(fieldname);
            boolean elementExists = (element!=null);
            if (elementExists){
            switch(type) {
                case "Int":
                    try {
                        Integer intValue = contentObj.get(fieldname).getAsInt();
                        messageJson.addProperty(fieldname,intValue);
                    } catch (IllegalArgumentException e) {
                        throw new IllegalTypeException(e, type, contentObj.get(fieldname));
                    }
                    break;
                case "Float":
                    try {
                        Float floatValue = contentObj.get(fieldname).getAsFloat();
                        messageJson.addProperty(fieldname,floatValue);
                    } catch (IllegalArgumentException e) {
                        throw new IllegalTypeException(e, type, contentObj.get(fieldname));
                    }
                    break;
                case "String":
                    try {
                        String stringValue = contentObj.get(fieldname).getAsString();
                        messageJson.addProperty(fieldname,stringValue);
                    } catch (IllegalArgumentException e) {
                        throw new IllegalTypeException(e, type, contentObj.get(fieldname));
                    }
                    break;
                case "DateTime":
                    try {
                        String dateValue = contentObj.get(fieldname).getAsString();
                        Instant instant = Instant.parse(dateValue);
                        messageJson.addProperty(fieldname, instant.toString());
                    } catch (IllegalArgumentException e) {
                        throw new IllegalTypeException(e, type, contentObj.get(fieldname));
                    }
                    break;
                case "Location":
                    try {
                        JsonObject location = contentObj.get(fieldname).getAsJsonObject();
                        Gson googleJson = new Gson();
                        ArrayList coordinates = googleJson.fromJson(location.get("coordinates").getAsJsonArray(),
                            ArrayList.class);
                        Object latitude = coordinates.get(0);
                        Object longitude = coordinates.get(1);

                        if (LatitudeLongitudeUtil.isValidLatitude(latitude.toString()) &&
                            LatitudeLongitudeUtil.isValidLongitude(longitude.toString())) {
                            messageJson.add("location", location);
                        }
                    } catch (IllegalArgumentException e) {
                        throw new IllegalTypeException(e, type, contentObj.get(fieldname));
                    }
                    break;
                case "Address":
                    JsonObject address = contentObj.get(fieldname).getAsJsonObject();
                    messageJson.add("address", address);
                    break;
                default:
                 //   throw new IllegalArgumentException("Something went wrong trying to transform: {"+ fieldname + " ,"+ type +"}");
            }
            }
        }
        }
        return messageJson.toString();
    }
    private String encodeString(String value){

        String p = "";
        if (value!=null) {
            String s= "";
            s = stripAccents(value);
            p = s.replace("/", "");
            p = p.replaceAll("[^a-zA-Z0-9-_ ]", "");
        }

        return p;

    }
}

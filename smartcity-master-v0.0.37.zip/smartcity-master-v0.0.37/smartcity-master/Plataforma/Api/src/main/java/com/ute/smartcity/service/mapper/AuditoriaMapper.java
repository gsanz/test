package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.AuditoriaDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Auditoria and its DTO AuditoriaDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface AuditoriaMapper extends EntityMapper<AuditoriaDTO, Auditoria> {



    default Auditoria fromId(Long id) {
        if (id == null) {
            return null;
        }
        Auditoria auditoria = new Auditoria();
        auditoria.setId(id);
        return auditoria;
    }
}

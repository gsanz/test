package com.ute.smartcity.service.exception;

import com.ute.smartcity.service.dto.RuleDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DeviceNotInRuleException extends Exception {
    private final Logger log = LoggerFactory.getLogger(DeviceNotInRuleException.class);

    private String message;
    public DeviceNotInRuleException(String message, RuleDTO ruleDTO) {
        this.message = message;
        log.error(message + " - " + ruleDTO);
    }

    @Override
    public String getMessage() {
        return message;
    }
}

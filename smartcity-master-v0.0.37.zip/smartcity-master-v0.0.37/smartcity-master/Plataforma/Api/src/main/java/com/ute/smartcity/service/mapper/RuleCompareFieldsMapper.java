package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.RuleCompareFieldsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity RuleCompareFields and its DTO RuleCompareFieldsDTO.
 */
@Mapper(componentModel = "spring", uses = {RuleMapper.class})
public interface RuleCompareFieldsMapper extends EntityMapper<RuleCompareFieldsDTO, RuleCompareFields> {

    @Mapping(source = "rule.id", target = "ruleId")
    RuleCompareFieldsDTO toDto(RuleCompareFields ruleCompareFields);

    @Mapping(source = "ruleId", target = "rule")
    RuleCompareFields toEntity(RuleCompareFieldsDTO ruleCompareFieldsDTO);

    default RuleCompareFields fromId(Long id) {
        if (id == null) {
            return null;
        }
        RuleCompareFields ruleCompareFields = new RuleCompareFields();
        ruleCompareFields.setId(id);
        return ruleCompareFields;
    }
}

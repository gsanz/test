package com.ute.smartcity.config;

import com.ute.smartcity.security.*;
import com.ute.smartcity.security.jwt.*;

import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.CorsFilter;
import org.zalando.problem.spring.web.advice.security.SecurityProblemSupport;

import javax.annotation.PostConstruct;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
@Import(SecurityProblemSupport.class)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    private final AuthenticationManagerBuilder authenticationManagerBuilder;

    private final UserDetailsService userDetailsService;

    private final TokenProvider tokenProvider;

    private final CorsFilter corsFilter;

    private final SecurityProblemSupport problemSupport;

    private static final String API_DEVICES = "/api/devices/**";

    private static final String API_PROVIDERS = "/api/providers/**";

    private static final String API_DEVICE_TYPES = "/api/device-types/**";

    private static final String API_ZONES = "/api/zones/**";

    private static final String API_ALERTS = "/api/alerts/**";

    private static final String API_APPLICATIONS = "/api/applications/**";

    private static final String API_RULES = "/api/rules/**";

    private static final String API_RULE_UPDATE_FIELDS = "/api/rule-update-fields/**";

    private static final String API_RULE_COMPARE_FIELDS = "/api/rule-compare-fields/**";

    private static final String API_PROTOCOLS = "/api/protocols/**";

    private static final String API_AUDIT_FIWARE_PLATFORMS = "/api/audit-fiware-platforms/**";

    public SecurityConfiguration(AuthenticationManagerBuilder authenticationManagerBuilder, UserDetailsService userDetailsService, TokenProvider tokenProvider, CorsFilter corsFilter, SecurityProblemSupport problemSupport) {
        this.authenticationManagerBuilder = authenticationManagerBuilder;
        this.userDetailsService = userDetailsService;
        this.tokenProvider = tokenProvider;
        this.corsFilter = corsFilter;
        this.problemSupport = problemSupport;
    }

    @PostConstruct
    public void init() {
        try {
            authenticationManagerBuilder
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());
        } catch (Exception e) {
            throw new BeanInitializationException("Security configuration failed", e);
        }
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
            .antMatchers(HttpMethod.OPTIONS, "/**")
            .antMatchers("/swagger-ui/index.html")
            .antMatchers("/test/**");
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        http
            .csrf()
            .disable()
            .addFilterBefore(corsFilter, UsernamePasswordAuthenticationFilter.class)
            .exceptionHandling()
            .authenticationEntryPoint(problemSupport)
            .accessDeniedHandler(problemSupport)
        .and()
            .headers()
            .frameOptions()
            .disable()
        .and()
            .sessionManagement()
            .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
            .authorizeRequests()
            .antMatchers("/api/register").permitAll()
            .antMatchers("/api/util/**").permitAll()
            .antMatchers("/api/activate").permitAll()
            .antMatchers("/api/authenticate/**").permitAll()
            .antMatchers("/api/account/reset-password/init").permitAll()
            .antMatchers("/api/account/reset-password/finish").permitAll()
            .antMatchers(HttpMethod.POST, API_DEVICES).hasAnyAuthority(AuthoritiesConstants.ADMIN,AuthoritiesConstants.PROVIDER)
            .antMatchers(HttpMethod.PUT, API_DEVICES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_DEVICES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_PROVIDERS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_PROVIDERS).hasAnyAuthority(AuthoritiesConstants.ADMIN,AuthoritiesConstants.PROVIDER)
            .antMatchers(HttpMethod.DELETE, API_PROVIDERS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_DEVICE_TYPES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.GET, API_DEVICE_TYPES).hasAnyAuthority(AuthoritiesConstants.ADMIN,AuthoritiesConstants.USER,AuthoritiesConstants.PROVIDER)
            .antMatchers(HttpMethod.PUT, API_DEVICE_TYPES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_DEVICE_TYPES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_ZONES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_ZONES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_ZONES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_ALERTS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_ALERTS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_ALERTS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_APPLICATIONS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_APPLICATIONS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_APPLICATIONS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_RULES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_RULES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_RULES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.GET, API_RULES).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_RULE_UPDATE_FIELDS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_RULE_UPDATE_FIELDS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_RULE_UPDATE_FIELDS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_RULE_COMPARE_FIELDS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_RULE_COMPARE_FIELDS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_RULE_COMPARE_FIELDS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_PROTOCOLS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_PROTOCOLS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_PROTOCOLS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.GET, API_AUDIT_FIWARE_PLATFORMS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST, API_AUDIT_FIWARE_PLATFORMS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.PUT, API_AUDIT_FIWARE_PLATFORMS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.DELETE, API_AUDIT_FIWARE_PLATFORMS).hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers(HttpMethod.POST,"/api/usuarios/**").permitAll()
            .antMatchers("/api/**").authenticated()
            .antMatchers("/websocket/tracker").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/websocket/**").permitAll()
            .antMatchers("/management/health").permitAll()
            .antMatchers("/management/info").permitAll()
            .antMatchers("/management/**").hasAnyAuthority(AuthoritiesConstants.ADMIN,AuthoritiesConstants.USER,AuthoritiesConstants.PROVIDER)
        .and()
            .apply(securityConfigurerAdapter());

    }

    private JWTConfigurer securityConfigurerAdapter() {
        return new JWTConfigurer(tokenProvider);
    }
}

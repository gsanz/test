package com.ute.smartcity.service;

import com.ute.smartcity.service.dto.AuditFiwarePlatformDTO;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

/**
 * Service Interface for managing AuditFiwarePlatform.
 */
public interface AuditFiwarePlatformService {

    /**
     * Save a auditFiwarePlatform.
     *
     * @param auditFiwarePlatformDTO the entity to save
     * @return the persisted entity
     */
    AuditFiwarePlatformDTO save(AuditFiwarePlatformDTO auditFiwarePlatformDTO);

    /**
     * Get all the auditFiwarePlatforms.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<AuditFiwarePlatformDTO> findAll(Pageable pageable);


    /**
     * Get the "id" auditFiwarePlatform.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<AuditFiwarePlatformDTO> findOne(Long id);

    /**
     * Delete the "id" auditFiwarePlatform.
     *
     * @param id the id of the entity
     */
    void delete(Long id);

    AuditFiwarePlatformDTO createFiwareAudit(String requestContent, String url, int responseCode, String responseContent, String type);
}

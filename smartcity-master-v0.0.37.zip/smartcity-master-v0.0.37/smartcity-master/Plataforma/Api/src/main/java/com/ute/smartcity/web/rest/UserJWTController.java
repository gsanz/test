package com.ute.smartcity.web.rest;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ute.smartcity.config.Constants;
import com.ute.smartcity.domain.PersistentAuditEvent;
import com.ute.smartcity.domain.User;
import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.security.jwt.JWTFilter;
import com.ute.smartcity.security.jwt.TokenProvider;
import com.ute.smartcity.service.AuditEventService;
import com.ute.smartcity.service.MailService;
import com.ute.smartcity.service.UserService;
import com.ute.smartcity.service.UsuarioService;
import com.ute.smartcity.service.dto.UsuarioDTO;
import com.ute.smartcity.service.mapper.UsuarioMapper;
import com.ute.smartcity.service.util.RandomUtil;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.vm.LoginVM;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Controller to authenticate users.
 */
@RestController
@RequestMapping("/api")
public class UserJWTController {

    private static final String ENTITY_NAME = "login";

    private final TokenProvider tokenProvider;

    private final UserService userService;

    private final UsuarioService usuarioService;

    private final MailService mailService;

    private final AuthenticationManager authenticationManager;

    private final UsuarioMapper usuarioMapper;

    private final AuditEventService auditEventService;

    @Value("${application.password_expiration_days}")
    public int password_expiration_days;

    public UserJWTController(TokenProvider tokenProvider, AuthenticationManager authenticationManager, UserService userService,
                             UsuarioService usuarioService, MailService mailService, UsuarioMapper usuarioMapper, AuditEventService auditEventService) {
        this.tokenProvider = tokenProvider;
        this.authenticationManager = authenticationManager;
        this.userService = userService;
        this.usuarioService = usuarioService;
        this.mailService = mailService;
        this.usuarioMapper = usuarioMapper;
        this.auditEventService = auditEventService;
    }

    @Transactional
    @PostMapping("/authenticate")
    public ResponseEntity<JWTToken> authorize(@Valid @RequestBody LoginVM loginVM, HttpServletRequest request) {

        UsernamePasswordAuthenticationToken authenticationToken =
            new UsernamePasswordAuthenticationToken(loginVM.getUsername(), loginVM.getPassword());

        Optional<User> user = userService.getUserByLogin(loginVM.getUsername());
        HttpHeaders httpHeaders = new HttpHeaders();

        try {
            Authentication authentication = this.authenticationManager.authenticate(authenticationToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            boolean rememberMe = (loginVM.isRememberMe() == null) ? false : loginVM.isRememberMe();
            String jwt = tokenProvider.createToken(authentication, rememberMe);

            if(user.isPresent()) {
                if (checkPasswordExpirationDate(user.get())) {
                    mailService.sendPasswordResetMail(user.get());
                    throw new BadRequestAlertException("The account password has expired", ENTITY_NAME, "expired");
                }
            }

            Usuario usuario = null;
                if(user.isPresent()) {
                    Long userId = user.get().getId();
                    usuario = usuarioService.getUserById(user.get().getId());
                }
            if(usuario != null) {
                if (usuario.isDoubleFactorAuthentication()) {
                    actualizarUsuario(usuario, user.get());
                    mailService.sendCodeDoubleAuthMail(usuario);
                    httpHeaders.add(JWTFilter.AUTHORIZATION_HEADER, "Double");
                } else {
                    usuarioService.resetAttempts(user.get().getId());
                    httpHeaders.add(JWTFilter.AUTHORIZATION_HEADER, "Bearer " + jwt);
                }
            }

                return new ResponseEntity<>(new JWTToken(jwt), httpHeaders, HttpStatus.OK);
        } catch (Exception e) {
            if (e instanceof InternalAuthenticationServiceException) {
                throw new BadRequestAlertException("This account has been disabled", ENTITY_NAME, "disabled");
            } else if (e instanceof BadCredentialsException) {
                if (user.isPresent()) {
                    createAuditEvent(user, request);
                    usuarioService.checkAttempts(user.get().getId());
                }
                return ResponseEntity.status(401).body(null);
            } else  if (e instanceof BadRequestAlertException) {
                throw new BadRequestAlertException("The account password has expired", ENTITY_NAME, "expired");
            } else {
                return ResponseEntity.badRequest().body(null);
            }
        }
    }

    @GetMapping("/authenticate/{login:" + Constants.LOGIN_REGEX + "}/lang")
    public String getUserLanguage(@PathVariable String login) {
        Optional<User> userByLogin = userService.getUserByLogin(login);
        if (userByLogin.isPresent()){
            String langKey = userByLogin.get().getLangKey();
            return langKey;
        }
        return null;
    }

    @GetMapping("/authenticate/{key}/key")
    public String getUserLanguageByKey(@PathVariable String key) {
        Optional<User> userByKey = userService.getUserByResetKey(key);
        if (userByKey.isPresent()){
            String langKey = userByKey.get().getLangKey();
            return langKey;
        }
        return null;
    }

    private void createAuditEvent(Optional<User> user, HttpServletRequest request) {

        PersistentAuditEvent auditEvent = new PersistentAuditEvent();
        auditEvent.setAuditEventDate(Instant.now());
        user.ifPresent(value -> auditEvent.setPrincipal(value.getLogin()));
        auditEvent.setAuditEventType("AUTHENTICATION_FAILURE");

        Map<String, String> data = new HashMap();
        data.put("message", "Credenciales Erróneas");
        data.put("remoteAddress", request.getRemoteAddr());
        data.put("type", "org.springframework.security.authentication.BadCredentialsException");

        auditEvent.setData(data);
        auditEventService.save(auditEvent);
    }

    private boolean checkPasswordExpirationDate(User user) {
        Usuario usuarioWithDate = usuarioService.firstTimeDate(user.getId());
        long days = ChronoUnit.DAYS.between(usuarioWithDate.getLastPasswordDate(), new Date().toInstant().atZone(ZoneId.of("UTC")));

        if (days > password_expiration_days) {
            return true;
        } else {
            return false;
        }
    }

    private void actualizarUsuario(Usuario usuario, User user1) {
        UsuarioDTO usuarioDTO;
        if (user1 != null) {
            Optional<User> user = Optional.of(user1);
            Optional<Usuario> usuarioDevices = usuarioService.getDevicesByUsuario(user.get().getId());
            if (usuarioDevices.isPresent()) {
                usuario.setDevicesTypes(usuarioDevices.get().getDevicesTypes());
            }


            Optional<User> userAuth = userService.getUserWithAuthorities(user.get().getId());
            if (userAuth.isPresent()) {
                usuario.getUser().setAuthorities(userAuth.get().getAuthorities());

                usuario.setDoubleAuthKey(RandomUtil.generateActivationKey());
                usuario.setCreateAtDoubleAuthKey(ZonedDateTime.now());

                usuarioDTO = usuarioMapper.toDto(usuario);

                usuarioService.updateUsuario(usuarioDTO);
            }
        }
    }


    /**
     * Object to return as body in JWT Authentication.
     */
    static class JWTToken {

        private String idToken;

        JWTToken(String idToken) {
            this.idToken = idToken;
        }

        @JsonProperty("id_token")
        String getIdToken() {
            return idToken;
        }

        void setIdToken(String idToken) {
            this.idToken = idToken;
        }
    }
}

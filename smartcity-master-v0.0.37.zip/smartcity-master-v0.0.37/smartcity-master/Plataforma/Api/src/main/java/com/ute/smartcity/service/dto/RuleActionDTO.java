package com.ute.smartcity.service.dto;

import com.ute.smartcity.domain.enumeration.RuleActionType;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A DTO for the RuleAction entity.
 */
public class RuleActionDTO implements Serializable {

    private Long id;

    @NotNull
    private RuleActionType ruleActionType;

    @Size(max = 250)
    private String subject;

    @Size(max = 3500)
    private String template;

    @Size(max = 100)
    private String from;

    @Size(max = 100)
    private String to;

    @Size(max = 3500)
    private String postParameters;


    private Long ruleId;

    private Set<RuleUpdateFieldsDTO> ruleUpdateFields = new HashSet<RuleUpdateFieldsDTO>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RuleActionType getRuleActionType() {
        return ruleActionType;
    }

    public void setRuleActionType(RuleActionType ruleActionType) {
        this.ruleActionType = ruleActionType;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getPostParameters() {
        return postParameters;
    }

    public void setPostParameters(String postParameters) {
        this.postParameters = postParameters;
    }

    public Long getRuleId() {
        return ruleId;
    }

    public void setRuleId(Long ruleId) {
        this.ruleId = ruleId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RuleActionDTO ruleActionDTO = (RuleActionDTO) o;
        if (ruleActionDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), ruleActionDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RuleActionDTO{" +
            "id=" + getId() +
            ", ruleActionType='" + getRuleActionType() + "'" +
            ", subject='" + getSubject() + "'" +
            ", template='" + getTemplate() + "'" +
            ", from='" + getFrom() + "'" +
            ", to='" + getTo() + "'" +
            ", postParameters='" + getPostParameters() + "'" +
            ", rule=" + getRuleId() +
            "}";
    }

    public Set<RuleUpdateFieldsDTO> getRuleUpdateFields() {
        return ruleUpdateFields;
    }

    public void setRuleUpdateFields(Set<RuleUpdateFieldsDTO> ruleUpdateFields) {
        this.ruleUpdateFields = ruleUpdateFields;
    }
}

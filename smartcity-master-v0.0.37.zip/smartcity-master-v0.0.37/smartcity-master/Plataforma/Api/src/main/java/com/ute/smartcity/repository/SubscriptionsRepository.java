package com.ute.smartcity.repository;

import com.ute.smartcity.domain.Subscriptions;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * Spring Data  repository for the Subscriptions entity.
 */
@SuppressWarnings("unused")
@Repository
public interface SubscriptionsRepository extends JpaRepository<Subscriptions, Long>, JpaSpecificationExecutor<Subscriptions> {
    List<Subscriptions> findByDeviceTypeId(Long id);
}

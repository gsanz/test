package com.ute.smartcity.service.exception.fiware;

import com.ute.smartcity.web.rest.DeviceResourceExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IOTAgentException extends Exception {
    private final Logger log = LoggerFactory.getLogger(DeviceResourceExt.class);
    public IOTAgentException(Exception ex) {
        log.error("Failed to process the request to IOTAgent: " + ex.getMessage());
    }
}

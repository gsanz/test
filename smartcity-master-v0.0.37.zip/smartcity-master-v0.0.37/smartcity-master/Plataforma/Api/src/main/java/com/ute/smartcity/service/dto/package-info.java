/**
 * Data Transfer Objects.
 */
package com.ute.smartcity.service.dto;

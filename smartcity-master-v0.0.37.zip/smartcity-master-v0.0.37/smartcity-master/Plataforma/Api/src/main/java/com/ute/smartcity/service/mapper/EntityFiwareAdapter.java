package com.ute.smartcity.service.mapper;

import com.google.gson.*;
import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.enumeration.DeviceAlert;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.*;
import com.ute.smartcity.service.exception.IllegalTypeException;
import com.ute.smartcity.service.exception.NullDevicePropertyException;
import com.ute.smartcity.service.platform.fiware.OrionFieldsMatcher;
import com.ute.smartcity.web.rest.DeviceResourceExt;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;

import java.time.Instant;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.stripAccents;


@Component
public class EntityFiwareAdapter {

    private final Logger log = LoggerFactory.getLogger(DeviceResourceExt.class);

    private final OrionFieldsMatcher orionFieldsMatcher;

    private final DeviceService deviceService;

    private final DeviceMapper deviceMapper;

    private final ProtocolService protocolService;

    private final String VALUE = "value";

    private final String FLOAT = "Float";

    private final String INT = "Int";

    private final String DATETIME = "DateTime";

    private final String LOCATION = "Location";

    private final String ADDRESS = "Address";

    private final String ADDRESS_COUNTRY = "addressCountry";

    private final String ADDRESS_LOCALITY = "addressLocality";

    private final String ADDRESS_STREET = "streetAddress";

    private final String FACILITIES = "facilities";

    private final String OPENING_HOURS = "openingHoursSpecification";

    private final String TYPE = "type";

    public String DeviceToEntity(DeviceDTO deviceDTO, Boolean update) {
        JSONObject entity = new JSONObject();

        if (!update){
            /**                             IMPORTANTE
             * La fecha si se guarda al principio, al hacer un put, se sobreescribe y no se muestra
             * se podria hacer un patch, pero entonces al eliminar un campo, no se actualizaria
             * */
            entity = setIdentificationProperties(deviceDTO, entity);
        } else {
            entity = setNormalProperties(deviceDTO, entity);
        }
        return entity.toString();
    }

    private JSONObject setNormalProperties(DeviceDTO deviceDTO, JSONObject entity) {

        entity = setProperty(entity, "name",deviceDTO.getName(),"Text");
        entity = setProperty(entity,  "description",deviceDTO.getObservaciones(),"Text");
        entity = setProperty(entity, "zone",deviceDTO.getZoneName(),"Text");
        entity = setProperty(entity,  "provider",deviceDTO.getProviderName(),"Text");

        entity = setLocation(deviceDTO, entity);

        entity = setAddress(deviceDTO, entity);

        entity = setFieldsValues(deviceDTO, entity);
        return entity;
    }

    public EntityFiwareAdapter(OrionFieldsMatcher orionFieldsMatcher, DeviceService deviceService, DeviceMapper deviceMapper,
                               ProtocolService protocolService) {
        this.orionFieldsMatcher = orionFieldsMatcher;
        this.deviceService = deviceService;
        this.deviceMapper = deviceMapper;
        this.protocolService = protocolService;
    }

    public String DeviceToEntityv2(DeviceDTO deviceDTO) {

        JSONObject entity = new JSONObject();

        entity = setIdentificationProperties(deviceDTO, entity);

        entity = setNormalProperties(deviceDTO, entity);


        return entity.toString();
    }

    private JSONObject setIdentificationProperties(DeviceDTO deviceDTO, JSONObject entity) {
        entity.put("id", deviceDTO.getReference());
        entity.put(TYPE, deviceDTO.getDeviceTypeType());
        return entity;
    }

    private JSONObject setFieldsValues(DeviceDTO deviceDTO, JSONObject entity) {
        Set<FieldsDTO> fields = deviceDTO.getFields();
        if (!fields.isEmpty()) { //PUT
            fields.forEach((field) -> {

                JSONObject jsonField = new JSONObject();
                jsonField.put(TYPE, getFieldType(field));
                if (field.getValue()!=null) {
                    jsonField.put(VALUE, getValue(field));
                } else {
                    //getDefaultValue
                    Object defaultValue = getDefaultValue(field);
                    jsonField.put(VALUE, defaultValue) ;
                }
                entity.put(field.getName(),jsonField);
            });
        }
        return entity;
    }

    private String getFieldType(FieldsDTO field) {
        String type = field.getType();
        String result ="Text";
        switch (type) {
            case INT:
                result="Number";
                break;
            case FLOAT:
                result="Number";
                break;
            case DATETIME:
                result=DATETIME;
                break;
            case LOCATION:
                result = "Text";
                break;
            case ADDRESS:
                result = "PostalAddress";
                break;
            default:
                break;
        }
        return  result;
    }

    private Object getValue(FieldsDTO field) {

        String type = field.getType();
        Object result ="";
        switch (type) {
            case INT:
                try {
                    result = Integer.parseInt(field.getValue());
                }catch (Exception e ){
                    result = 0;
                }
                break;
            case FLOAT:
                try {
                    result = Float.parseFloat(field.getValue());
                }catch (Exception e ){
                    result = 0.0;
                }
                break;
            case "String":
                result = encodeString(field.getValue());
                break;
            case DATETIME:
                try {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
                    result = simpleDateFormat.format(field.getValue());
                }catch (Exception e) {
                    Instant instant = Instant.now();
                    result = instant.toString();
                }

                break;
            case LOCATION:
                result = field.getValue();
                break;
            case ADDRESS:
                JSONObject address = new JSONObject();
                address.put(ADDRESS_COUNTRY, "ES");
                address.put(ADDRESS_LOCALITY, "Onda");
                address.put(ADDRESS_STREET, "");
                result = address;
                break;
            default:
                break;
        }
        return result;
    }

    private Object getDefaultValue(FieldsDTO field) {

        String type = field.getType();
        Object result ="";
        switch (type) {
            case INT:
                result = 0;
                break;
            case FLOAT:
                result = 0.0;
                break;
            case "String":
                result ="";
                break;
            case DATETIME:
                Instant instant = Instant.now();
                result = instant.toString();

                break;
            case LOCATION:
                result = "0,0";
                break;
            case ADDRESS:
                JSONObject address = new JSONObject();
                address.put(ADDRESS_COUNTRY, "ES");
                address.put(ADDRESS_LOCALITY, "Onda");
                address.put(ADDRESS_STREET, "");
                result = address;
                break;
            default:
                break;
        }
    return result;
    }

    private JSONObject setAddress(DeviceDTO deviceDTO, JSONObject entity) {
        JSONObject addressDir = new JSONObject();
        addressDir.put(ADDRESS_COUNTRY, "ES");
        addressDir.put(ADDRESS_LOCALITY, "Onda");
        addressDir.put(ADDRESS_STREET, encodeString(deviceDTO.getLocation()));


        JSONObject address = new JSONObject();
        address.put(TYPE, "PostalAddress");
        address.put(VALUE,addressDir);

        entity.put(ADDRESS.toLowerCase(), address);
        return entity;
    }

    public String DeviceToEntity(DeviceDTO device) {


        JSONObject entity = new JSONObject();

     //   NO SE DEBEN DE PONER CUANDO SE HACE UN UPDATE
        entity = setIdentificationProperties(device, entity);

        entity = setNormalProperties(device, entity);

        return entity.toString();
    }

    private JSONObject setProperty(JSONObject entity, String name, String value, String type) {

        if (value != null) {
            JSONObject valueObject = new JSONObject();
            valueObject.put(VALUE, value);
            String encodeFieldname =encodeString(name);
            JSONObject typeObject = new JSONObject();
            typeObject.put(TYPE, type);
            entity.put(encodeFieldname,valueObject);
        }
        return entity;
    }

    private JSONObject setLocation(DeviceDTO device, JSONObject entity) {

        JSONArray coordinates = new JSONArray();
        coordinates.add(device.getLatitude());
        coordinates.add(device.getLongitude());
        String locationS = String.format("%s,%s",device.getLatitude(),device.getLongitude());
        JSONObject valueObject = new JSONObject();
        valueObject.put(TYPE, "Text");
        valueObject.put(VALUE, locationS);
        entity.put(LOCATION.toLowerCase(), valueObject);

        return entity;
    }

    public String dataToEntityJson(String data, Optional<List<FieldsDTO>> campos) throws IllegalTypeException {

        JsonObject parsedData = new JsonParser().parse(data).getAsJsonObject();

        String matchedFieldsJSON = orionFieldsMatcher.matchAll(parsedData, campos);

        return matchedFieldsJSON;
    }

    public DeviceDTO entitiesToDevice(JsonElement entity) {

        JsonObject entityObj = entity.getAsJsonObject();
        String id = entityObj.get("id").getAsString();
        Optional<Device> device = deviceService.findByReference(id);

        if(!device.isPresent()) {
            return null;
        }

        for(Map.Entry<String, JsonElement> entry : entityObj.entrySet()) {
            //Update de la hora
            if(entry.getKey().contains("date")){
                String fechaUltimoUpdate = entry.getValue().getAsString();
                try{
                    ZonedDateTime zdtFechaUltimoUpdate = ZonedDateTime.parse(fechaUltimoUpdate);
                    ZonedDateTime zdt = ZonedDateTime.now(ZoneId.of("Europe/Madrid"));
                    zdt = zdt.plusHours(2);
                    Duration d = Duration.between( zdtFechaUltimoUpdate , zdt );
                    Long horasPasadas = d.toHours();

                    if(horasPasadas<2) {
                        device.get().setState(DeviceAlert.CORRECTO.toString());
                    } else if(horasPasadas>=2 && horasPasadas <4) {
                        device.get().setState(DeviceAlert.SIN_CONEXION.toString());
                    } else {
                        device.get().setState(DeviceAlert.ERROR.toString());
                    }
                    device.get().setUpdateAt(zdtFechaUltimoUpdate);
                }catch (Exception e) {
                    log.debug("Failed trying to parse the date. ", fechaUltimoUpdate);
                }
            }
        }

        try{
            //Nombre
            String name = entityObj.get("name").getAsString();
            if(name != null) {
                device.get().setName(name);
            }
        }catch (Exception e) {
            log.debug("This entity didn't have a name.", entityObj);
        }

        try{
            //Calle
            JsonObject address = entityObj.get(ADDRESS.toLowerCase()).getAsJsonObject();
            String street = address.get(ADDRESS_STREET).getAsString();
            device.get().setLocation(street);
        }catch (Exception e) {
            log.debug("This entity didn't have an address street.", entityObj);
        }

                try {

                    //Longitud y Latitud
                    JsonObject location = entityObj.get(LOCATION.toLowerCase()).getAsJsonObject();
                    Gson googleJson = new Gson();
                    ArrayList coordinates = googleJson.fromJson(location.get("coordinates").getAsJsonArray(),
                        ArrayList.class);
                    Object latitude = coordinates.get(0);
                    Object longitude = coordinates.get(1);
                    if (latitude != null) {
                        device.get().setLatitude(latitude.toString());
                    }
                    if (longitude != null) {
                        device.get().setLongitude(longitude.toString());
                    }
                } catch (Exception e) {
                    log.debug("This entity didn't have a location.", entityObj);
                }

        return deviceMapper.toDto(device.get());
    }

    public FieldsDTO fiwareFieldValueToDeviceFieldValue(Map.Entry<String, JsonElement> entry, FieldsDTO campo) {

        String key = entry.getKey();
        JsonElement value = entry.getValue();

        if(key.equals(ADDRESS.toLowerCase()) || key.equals(LOCATION.toLowerCase()) || value.isJsonNull() /*||
        key.toLowerCase().equals(FACILITIES.toLowerCase()) || key.toLowerCase().equals(OPENING_HOURS.toLowerCase())*/) {
            return campo;
        }
        String valueString = "";
        if(value.isJsonArray()){
            JsonArray prueba = value.getAsJsonArray();
            valueString = prueba.toString();
        } else {
            valueString = value.getAsString();
        }
        String comparadorVacio = "";
        if (key.equals("availableSpotNumber")){
            log.debug("prueba");
        }

        if (campo.getName().equals(key)) {
            if (valueString.equals(comparadorVacio)) {
                value = null;
            }

            if(value == null) {
                campo.setValue("");
            } else {
                String valueWithoutCommas = value.toString();
                valueWithoutCommas = valueWithoutCommas.replace("\"", "");
                campo.setValue(valueWithoutCommas);
            }
        }
        return campo;
    }

    public JsonObject dispositivoToFiwareDevice(DeviceDTO device) throws NullDevicePropertyException {
        JsonObject devices = new JsonObject();
        JsonObject deviceJsonObject = new JsonObject();

        try{
            //Optional<DeviceTypeDTO> deviceType = deviceTypeService.findOne(device.getDeviceTypeId());
            Optional<ProtocolDTO> protocol = protocolService.findOne(device.getProtocolId());

            deviceJsonObject.addProperty("device_id", device.getReference());
            deviceJsonObject.addProperty("entity_name", device.getReference());
            deviceJsonObject.addProperty("entity_type", device.getDeviceTypeType());
            deviceJsonObject.addProperty("protocol", "PDI-IoTA-UltraLight");
            protocol.ifPresent(protocolDTO -> deviceJsonObject.addProperty("transport", protocolDTO.getName()));
            JsonArray attributes = new JsonArray();

            for (FieldsDTO campo: device.getFields()) {
                boolean hasAbbreviation = (campo.getAbbreviation()!=null) && (!campo.getAbbreviation().isEmpty());
                if (hasAbbreviation) {
                    try {
                        JsonObject field = new JsonObject();
                        field.addProperty("object_id", campo.getAbbreviation());
                        field.addProperty("name", campo.getName());
                        field.addProperty(TYPE, campo.getType());
                        attributes.add(field);
                    }
                    catch(Exception e) {
                        log.error("Error accediendo a las propiedades del campo: ",campo.getName());
                    }
                }
            }

            deviceJsonObject.add("attributes", attributes);

            JsonArray devicesArray = new JsonArray();

            devicesArray.add(deviceJsonObject);

            devices.add("devices", devicesArray);

            return devices;
        }catch (NullPointerException e) {
            throw new NullDevicePropertyException(e, device);
        }
    }

    public List<FiwareSubscriptionDTO> subscriptionsDTOListtoFiwareSubscriptionsDTOList(List<SubscriptionsDTO> subscriptionsDTOList) {
        List<FiwareSubscriptionDTO> fiwareSubscriptionDTOList = new ArrayList<>();
        for (SubscriptionsDTO subsDTO : subscriptionsDTOList) {
            FiwareSubscriptionDTO fiwareSubscriptionDTO = subscriptionsDTOToFiwareSubscriptionDTO(subsDTO);
            fiwareSubscriptionDTOList.add(fiwareSubscriptionDTO);
        }
        return fiwareSubscriptionDTOList;
    }

    public FiwareSubscriptionDTO subscriptionsDTOToFiwareSubscriptionDTO(SubscriptionsDTO subscriptionsDTO) {
        FiwareSubscriptionDTO fiwareSubscriptionDTO = new FiwareSubscriptionDTO();
        fiwareSubscriptionDTO.setDescription(subscriptionsDTO.getDescription());
        fiwareSubscriptionDTO.setUrl(subscriptionsDTO.getEndpoint());
        fiwareSubscriptionDTO.setServicepath(subscriptionsDTO.getDeviceTypeReference());
        fiwareSubscriptionDTO.setType(subscriptionsDTO.getDeviceTypeType());

        return fiwareSubscriptionDTO;
    }
    private String encodeString(String value){

        String p = "";
        if (value!=null) {
                String s= "";
                s = stripAccents(value);
                p = s.replace("/", "");
                p = p.replaceAll("[^a-zA-Z0-9-_ ]", "");
            }

        return p;

    }
}




package com.ute.smartcity.domain.enumeration;

public enum DeviceAlert {
    CORRECTO, SIN_CONEXION, ERROR
}

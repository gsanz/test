package com.ute.smartcity.web.rest;

import com.ute.smartcity.domain.User;
import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.repository.UserRepository;
import com.ute.smartcity.repository.UsuarioRepository;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.security.SecurityUtils;
import com.ute.smartcity.security.jwt.JWTFilter;
import com.ute.smartcity.security.jwt.TokenProvider;
import com.ute.smartcity.service.MailService;
import com.ute.smartcity.service.UserService;
import com.ute.smartcity.service.UsuarioService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.UserDTO;
import com.ute.smartcity.service.dto.UsuarioDTO;
import com.ute.smartcity.service.mapper.UsuarioMapper;
import com.ute.smartcity.web.rest.errors.*;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.vm.LoginVM;
import io.github.jhipster.web.util.ResponseUtil;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Optional;

/**
 * REST controller for managing Usuario.
 */
@RestController
@RequestMapping("/api")
@Api(value = "usuario-resource", description = "Usuario Resource", tags = "usuario-resource")
public class UsuarioResourceExt {

    private final Logger log = LoggerFactory.getLogger(UsuarioResourceExt.class);

    private static final String ENTITY_NAME = "usuario";

    private static final String ENTITY_LOGIN = "login";

    private final UsuarioService usuarioService;

    private final UserRepository userRepository;

    private final UsuarioRepository usuarioRepository;

    private final UserService userService;

    private final TokenProvider tokenProvider;

    private final MailService mailService;

    private final AuthenticationManager authenticationManager;

    private final UsuarioMapper usuarioMapper;

    public UsuarioResourceExt(UsuarioService usuarioService, UserRepository userRepository, UsuarioRepository usuarioRepository, UserService userService,
                              MailService mailService, AuthenticationManager authenticationManager, TokenProvider tokenProvider,
                              UsuarioMapper usuarioMapper) {
        this.usuarioService = usuarioService;
        this.userRepository = userRepository;
        this.usuarioRepository = usuarioRepository;
        this.userService = userService;
        this.mailService = mailService;
        this.authenticationManager = authenticationManager;
        this.tokenProvider = tokenProvider;
        this.usuarioMapper = usuarioMapper;
    }

    /**
     * POST  /usuarios : Create a new usuario.
     *
     * @param usuarioDTO the usuarioDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new usuarioDTO, or with status 400 (Bad Request) if the usuario has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/usuarios")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<UsuarioDTO> createUsuario(@Valid @RequestBody UsuarioDTO usuarioDTO) throws URISyntaxException {
        log.debug("REST request to save Usuario : {}", usuarioDTO);

        if (usuarioDTO.getId() != null) {
            throw new BadRequestAlertException("A new usuario cannot already have an ID", ENTITY_NAME, "idexists");
        }
        if (usuarioDTO.getDevicesTypes().isEmpty()) {
            throw new BadRequestAlertException("A user needs to have a deviceType", ENTITY_NAME, "nodevicetype");
        }
        if (usuarioRepository.findOneByPhone(usuarioDTO.getPhone().toLowerCase()).isPresent()) {
            throw new BadRequestAlertException("User phone alredy exist", ENTITY_NAME, "phoneexist");
        }
        if (userRepository.findOneByLogin(usuarioDTO.getUser().getLogin().toLowerCase()).isPresent()) {
            throw new LoginAlreadyUsedException();
        }
        if (userRepository.findOneByEmailIgnoreCase(usuarioDTO.getUser().getEmail()).isPresent()) {
            throw new EmailAlreadyUsedException();
        }
        validateFieldsUserRequired(usuarioDTO);
        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        if (!isAdmin) {
            if (usuarioDTO.getDevicesTypes() == null || usuarioDTO.getDevicesTypes().size() == 0) {
                throw new CreateUsuarioDeviceTypeException();
            }
        }

        UsuarioDTO result = usuarioService.createUsuario(usuarioDTO);
        return ResponseEntity.created(new URI("/api/usuarios/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /usuarios : Updates an existing usuario.
     *
     * @param usuarioDTO the usuarioDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated usuarioDTO,
     * or with status 400 (Bad Request) if the usuarioDTO is not valid,
     * or with status 500 (Internal Server Error) if the usuarioDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/usuarios")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<UsuarioDTO> updateUsuario(@Valid @RequestBody UsuarioDTO usuarioDTO) throws URISyntaxException {
        log.debug("REST request to update Usuario : {}", usuarioDTO);

        if (usuarioDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (usuarioDTO.getDevicesTypes().isEmpty()) {
            throw new BadRequestAlertException("A user needs to have a deviceType", ENTITY_NAME, "nodevicetype");
        }
        Optional<User> existingUser = userRepository.findOneByEmailIgnoreCase(usuarioDTO.getUser().getEmail());
        if (existingUser.isPresent() && (!existingUser.get().getId().equals(usuarioDTO.getUser().getId()))) {
            throw new EmailAlreadyUsedException();
        }
        existingUser = userRepository.findOneByLogin(usuarioDTO.getUser().getLogin().toLowerCase());
        if (existingUser.isPresent() && (!existingUser.get().getId().equals(usuarioDTO.getUser().getId()))) {
            throw new LoginAlreadyUsedException();
        }
        Optional<Usuario> existingUsuario = usuarioRepository.findOneByPhone(usuarioDTO.getPhone().toLowerCase());
        if (existingUsuario.isPresent() && (!existingUsuario.get().getUser().getId().equals(usuarioDTO.getUser().getId()))) {
            throw new BadRequestAlertException("User phone alredy exist", ENTITY_NAME, "phoneexist");
        }

        validateFieldsUserRequired(usuarioDTO);
        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        if (!isAdmin) {

            if (usuarioDTO.getDevicesTypes() == null || usuarioDTO.getDevicesTypes().size() == 0) {
                throw new UpdateUsuarioDeviceTypeException();
            }
        }
        String OldEmail = null;
        Optional<User> usarioDtoId  = userRepository.findById(usuarioDTO.getId());
        if( usarioDtoId.isPresent()) {
            OldEmail = usarioDtoId.get().getEmail();
        }
        String newEmail = usuarioDTO.getUser().getEmail();

        UsuarioDTO result;

        if (OldEmail!=null && !OldEmail.equals(newEmail)) {
            result = usuarioService.updateUsuarioWithEmail(usuarioDTO);
        } else {
            result = usuarioService.updateUsuario(usuarioDTO);
        }

        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, usuarioDTO.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /usuarios : Updates an existing usuario.
     *
     * @param usuarioDTO the usuarioDTO to update the application language
     * @return the ResponseEntity with status 200 (OK) and with body the updated usuarioDTO,
     * or with status 400 (Bad Request) if the usuarioDTO is not valid,
     * or with status 500 (Internal Server Error) if the usuarioDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/usuarios/{id}/changeLanguage")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<UsuarioDTO> updateUsuarioChangeLanguage(@Valid @RequestBody UsuarioDTO usuarioDTO) throws URISyntaxException {
        log.debug("REST request to update Usuario : {}", usuarioDTO);
        UsuarioDTO result = null;
        if (usuarioDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Optional<UsuarioDTO> usuarioDTOOptional = usuarioService.findOne(usuarioDTO.getId());
        Boolean usernotexists =(!usuarioDTOOptional.isPresent());

        if(usernotexists){
            throw new BadRequestAlertException("User not exists", ENTITY_NAME, "usernotexists");
        }

        Optional<String> userLogin = SecurityUtils.getCurrentUserLogin();
        String currentUserLogin = null;
        if(userLogin.isPresent()) {
            currentUserLogin = userLogin.get();
        }
        UsuarioDTO actualUsuarioDTO = usuarioDTOOptional.get();
        UserDTO user = actualUsuarioDTO.getUser();
        if(currentUserLogin != null) {
            boolean updateNotAllowed = !(currentUserLogin.equals(user.getLogin()));
            if (updateNotAllowed) {

                throw new UnathorizedException("User doesn´t have rights to perform this action", ENTITY_NAME, "unauthorized");
            }
        }

        user.setLangKey(usuarioDTO.getUser().getLangKey());
        userService.updateUser(user);
        result = actualUsuarioDTO;



        return ResponseEntity.ok()
            .body(result);
    }

    @GetMapping("/usuarios/me")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<UsuarioDTO> getCurrentUsuario() {
        User loggedInUser = userService.getUserWithAuthorities()
            .orElseThrow(InvalidPasswordException::new);
        Optional<UsuarioDTO> usuarioDTO = usuarioService.findOne(loggedInUser.getId());
        return ResponseUtil.wrapOrNotFound(usuarioDTO);
    }

    private void validateFieldsUserRequired(UsuarioDTO usuarioDTO) {
        String login = usuarioDTO.getUser().getLogin().trim();
        String firstName = usuarioDTO.getUser().getFirstName().trim();
        String lastName = usuarioDTO.getUser().getLastName().trim();
        String email = usuarioDTO.getUser().getEmail().trim();
        String phone = usuarioDTO.getPhone().trim();

        if (usuarioDTO.getUser().getLogin() == null || usuarioDTO.getUser().getLogin().isEmpty() || login.length() <= 0 ||
            usuarioDTO.getUser().getFirstName() == null || usuarioDTO.getUser().getFirstName().isEmpty() || firstName.length() <= 0 ||
            usuarioDTO.getUser().getLastName() == null || usuarioDTO.getUser().getLastName().isEmpty() || lastName.length() <= 0 ||
            usuarioDTO.getPhone() == null || usuarioDTO.getPhone().isEmpty() || email.length() <= 0 ||
            usuarioDTO.getUser().getEmail() == null || usuarioDTO.getUser().getEmail().isEmpty() || phone.length() <= 0) {
            throw new BadRequestAlertException("unexpectedError", ENTITY_NAME, "userRequiredFieldsNotFound");
        }
    }

    @PostMapping("/usuarios/double-auth/{code}")
    public ResponseEntity<UserJWTController.JWTToken> loginDoubleAuthorization(@RequestBody LoginVM loginVM, @PathVariable String code) throws URISyntaxException {
        log.debug("REST request to login with doblefactor auth code : {}", loginVM);
        Usuario usuario = null;
        Optional<User> user = userService.getUserByLogin(loginVM.getUsername());

        if(user.isPresent() && !user.get().getActivated()) {
            return ResponseEntity.ok().headers(HeaderUtil.cuentaBloqueada(ENTITY_LOGIN)).build();
        }

        if(user.isPresent()) {
            Long userId = user.get().getId();
            usuario = usuarioService.getUserById(userId);
        }

        if (usuario == null) {
            return ResponseEntity.badRequest().body(null);
        }

        if (usuario.getDoubleAuthKey() == null && usuario.getCreateAtDoubleAuthKey() == null) {
            return ResponseEntity.badRequest().body(null);
        }

        if (code.equals(usuario.getDoubleAuthKey())) {
            ZonedDateTime now = ZonedDateTime.now();

            long minutes = ChronoUnit.MINUTES.between(usuario.getCreateAtDoubleAuthKey(), now);
            if (minutes >= 5) {
                throw new BadRequestAlertException("The code time has expired", ENTITY_NAME, "expired");
            }
            UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(loginVM.getUsername(), loginVM.getPassword());

            Authentication authentication = this.authenticationManager.authenticate(authenticationToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            boolean rememberMe = (loginVM.isRememberMe() == null) ? false : loginVM.isRememberMe();
            String jwt = tokenProvider.createToken(authentication, rememberMe);
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add(JWTFilter.AUTHORIZATION_HEADER, "Bearer " + jwt);

            usuario.numberAttemptsDoubleAuth(0);
            usuario.createAtDoubleAuthKey(null);
            usuario.doubleAuthKey(null);

            actualizarUsuario(usuario, user);

            return new ResponseEntity<>(new UserJWTController.JWTToken(jwt), httpHeaders, HttpStatus.OK);
        }

        Integer intentos = usuario.getNumberAttemptsDoubleAuth();
        usuario.setNumberAttemptsDoubleAuth(++intentos);

        actualizarUsuario(usuario, user);

        if(intentos >= 3) {
            //Se desactiva al usuario por exceso de intentos fallidos y se le envía un correo avisandole de ello.
            usuario.getUser().setActivated(false);
            actualizarUsuario(usuario, user);
            mailService.sendUserDisabledMail(usuario.getUser());
            throw new BadRequestAlertException("This account has been disabled", ENTITY_NAME, "disabled");
        }
        throw new BadRequestAlertException("Incorrect doble factor code", ENTITY_NAME, "incorrect");
    }


    public void actualizarUsuario(Usuario usuario, Optional<User> user) {
        UsuarioDTO usuarioDTO;
        if(user.isPresent()) {
            Optional<Usuario> usuarioDevices = usuarioService.getDevicesByUsuario(user.get().getId());
            if(usuarioDevices.isPresent()) {
                usuario.setDevicesTypes(usuarioDevices.get().getDevicesTypes());
                Optional<User> userAuth = userService.getUserWithAuthorities(user.get().getId());
                if(userAuth.isPresent()) {
                    usuario.getUser().setAuthorities(userAuth.get().getAuthorities());
                }
            }
        }
        usuarioDTO = usuarioMapper.toDto(usuario);

        usuarioService.updateUsuario(usuarioDTO);
    }
}

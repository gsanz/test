package com.ute.smartcity.service.dto;

import java.io.Serializable;

public class IOTGroupDTO implements Serializable {

    private String apikey;

    private String cbroker;

    private String entity_type;

    private String resource;

    public String getApikey() {
        return apikey;
    }

    public void setApikey(String apikey) {
        this.apikey = apikey;
    }

    public String getCbroker() {
        return cbroker;
    }

    public void setCbroker(String cbroker) {
        this.cbroker = cbroker;
    }

    public String getEntity_type() {
        return entity_type;
    }

    public void setEntity_type(String entity_type) {
        this.entity_type = entity_type;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }
}

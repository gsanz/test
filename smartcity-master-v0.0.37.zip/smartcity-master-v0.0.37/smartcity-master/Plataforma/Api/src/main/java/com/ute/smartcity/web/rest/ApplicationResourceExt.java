package com.ute.smartcity.web.rest;

import com.ute.smartcity.domain.Application;
import com.ute.smartcity.repository.ApplicationRepository;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.ApplicationQueryService;
import com.ute.smartcity.service.ApplicationService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.ApplicationDTO;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Application.
 */
@RestController
@RequestMapping("/api")
public class ApplicationResourceExt {

    private final Logger log = LoggerFactory.getLogger(ApplicationResourceExt.class);

    private static final String ENTITY_NAME = "application";

    private final ApplicationService applicationService;

    private final ApplicationRepository applicationRepository;

    private final ApplicationQueryService applicationQueryService;

    public ApplicationResourceExt(ApplicationService applicationService, ApplicationRepository applicationRepository, ApplicationQueryService applicationQueryService) {
        this.applicationService = applicationService;
        this.applicationRepository = applicationRepository;
        this.applicationQueryService = applicationQueryService;
    }

    /**
     * PUT  /applications : Updates an existing application.
     *
     * @param applicationDTO the applicationDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated applicationDTO,
     * or with status 400 (Bad Request) if the applicationDTO is not valid,
     * or with status 500 (Internal Server Error) if the applicationDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/applications")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<ApplicationDTO> updateApplication(@Valid @RequestBody ApplicationDTO applicationDTO) throws URISyntaxException {
        log.debug("REST request to update Application : {}", applicationDTO);
        if (applicationDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String name = applicationDTO.getName().trim();
        if(applicationDTO.getName() == null || applicationDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("A new application needs a name", ENTITY_NAME, "noname");
        }

        Optional<Application> applicationByName = applicationRepository.findByName(name);
        if(applicationByName.isPresent()) {
            throw new BadRequestAlertException("Another application is using that name", ENTITY_NAME, "duplicatedappname");
        }

        ApplicationDTO result = applicationService.save(applicationDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, applicationDTO.getId().toString()))
            .body(result);
    }

    /**
     * POST  /applications : Create a new application.
     *
     * @param applicationDTO the applicationDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new applicationDTO, or with status 400 (Bad Request) if the application has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/applications")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<ApplicationDTO> createApplication(@Valid @RequestBody ApplicationDTO applicationDTO) throws URISyntaxException {
        log.debug("REST request to save Application : {}", applicationDTO);
        if (applicationDTO.getId() != null) {
            throw new BadRequestAlertException("A new application cannot already have an ID", ENTITY_NAME, "idexists");
        }
        String name = applicationDTO.getName().trim();
        if(applicationDTO.getName() == null || applicationDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("A new application needs a name", ENTITY_NAME, "noname");
        }

        Optional<Application> applicationByName = applicationRepository.findByName(name);
        if(applicationByName.isPresent()) {
            throw new BadRequestAlertException("Another application is using that name", ENTITY_NAME, "duplicatedappname");
        }

        ApplicationDTO result = applicationService.save(applicationDTO);
        return ResponseEntity.created(new URI("/api/applications/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }



}

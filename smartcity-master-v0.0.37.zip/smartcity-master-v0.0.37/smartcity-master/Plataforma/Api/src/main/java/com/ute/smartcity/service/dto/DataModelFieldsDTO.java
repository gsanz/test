package com.ute.smartcity.service.dto;


import javax.persistence.Lob;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Fields entity.
 */
public class DataModelFieldsDTO implements Serializable {



    @NotNull
    private String name;

    @NotNull
    private String type;


    private String unitOfmeasure;

    @Lob
    private String metadata;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnitOfmeasure() {
        return unitOfmeasure;
    }

    public void setUnitOfmeasure(String unitOfmeasure) {
        this.unitOfmeasure = unitOfmeasure;
    }


    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DataModelFieldsDTO fieldsDTO = (DataModelFieldsDTO) o;
        if (fieldsDTO.getName() == null || getName() == null) {
            return false;
        }
        return Objects.equals(getName(), fieldsDTO.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getName());
    }

    @Override
    public String toString() {
        return "FieldsDTO{" +
            ", name='" + getName() + "'" +
            ", type='" + getType() + "'" +
            ", unitOfmeasure='" + getUnitOfmeasure() + "'" +
            ", metadata='" + getMetadata() + "'" +
            "}";
    }
}

/**
 * View Models used by Spring MVC REST controllers.
 */
package com.ute.smartcity.web.rest.vm;

package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.SubscriptionTemplateService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.SubscriptionTemplateDTO;
import com.ute.smartcity.service.dto.SubscriptionTemplateCriteria;
import com.ute.smartcity.service.SubscriptionTemplateQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing SubscriptionTemplate.
 */
@RestController
@RequestMapping("/api")
public class SubscriptionTemplateResource {

    private final Logger log = LoggerFactory.getLogger(SubscriptionTemplateResource.class);

    private static final String ENTITY_NAME = "subscriptionTemplate";

    private final SubscriptionTemplateService subscriptionTemplateService;

    private final SubscriptionTemplateQueryService subscriptionTemplateQueryService;

    public SubscriptionTemplateResource(SubscriptionTemplateService subscriptionTemplateService, SubscriptionTemplateQueryService subscriptionTemplateQueryService) {
        this.subscriptionTemplateService = subscriptionTemplateService;
        this.subscriptionTemplateQueryService = subscriptionTemplateQueryService;
    }

    /**
     * POST  /subscription-templates : Create a new subscriptionTemplate.
     *
     * @param subscriptionTemplateDTO the subscriptionTemplateDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new subscriptionTemplateDTO, or with status 400 (Bad Request) if the subscriptionTemplate has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/subscription-templates")
    public ResponseEntity<SubscriptionTemplateDTO> createSubscriptionTemplate(@Valid @RequestBody SubscriptionTemplateDTO subscriptionTemplateDTO) throws URISyntaxException {
        log.debug("REST request to save SubscriptionTemplate : {}", subscriptionTemplateDTO);
        if (subscriptionTemplateDTO.getId() != null) {
            throw new BadRequestAlertException("A new subscriptionTemplate cannot already have an ID", ENTITY_NAME, "idexists");
        }
        SubscriptionTemplateDTO result = subscriptionTemplateService.save(subscriptionTemplateDTO);
        return ResponseEntity.created(new URI("/api/subscription-templates/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /subscription-templates : Updates an existing subscriptionTemplate.
     *
     * @param subscriptionTemplateDTO the subscriptionTemplateDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated subscriptionTemplateDTO,
     * or with status 400 (Bad Request) if the subscriptionTemplateDTO is not valid,
     * or with status 500 (Internal Server Error) if the subscriptionTemplateDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/subscription-templates")
    public ResponseEntity<SubscriptionTemplateDTO> updateSubscriptionTemplate(@Valid @RequestBody SubscriptionTemplateDTO subscriptionTemplateDTO) throws URISyntaxException {
        log.debug("REST request to update SubscriptionTemplate : {}", subscriptionTemplateDTO);
        if (subscriptionTemplateDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        SubscriptionTemplateDTO result = subscriptionTemplateService.save(subscriptionTemplateDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, subscriptionTemplateDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /subscription-templates : get all the subscriptionTemplates.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of subscriptionTemplates in body
     */
    @GetMapping("/subscription-templates")
    public ResponseEntity<List<SubscriptionTemplateDTO>> getAllSubscriptionTemplates(SubscriptionTemplateCriteria criteria, Pageable pageable) {
        log.debug("REST request to get SubscriptionTemplates by criteria: {}", criteria);
        Page<SubscriptionTemplateDTO> page = subscriptionTemplateQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/subscription-templates");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /subscription-templates/count : count all the subscriptionTemplates.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/subscription-templates/count")
    public ResponseEntity<Long> countSubscriptionTemplates(SubscriptionTemplateCriteria criteria) {
        log.debug("REST request to count SubscriptionTemplates by criteria: {}", criteria);
        return ResponseEntity.ok().body(subscriptionTemplateQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /subscription-templates/:id : get the "id" subscriptionTemplate.
     *
     * @param id the id of the subscriptionTemplateDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the subscriptionTemplateDTO, or with status 404 (Not Found)
     */
    @GetMapping("/subscription-templates/{id}")
    public ResponseEntity<SubscriptionTemplateDTO> getSubscriptionTemplate(@PathVariable Long id) {
        log.debug("REST request to get SubscriptionTemplate : {}", id);
        Optional<SubscriptionTemplateDTO> subscriptionTemplateDTO = subscriptionTemplateService.findOne(id);
        return ResponseUtil.wrapOrNotFound(subscriptionTemplateDTO);
    }

    /**
     * DELETE  /subscription-templates/:id : delete the "id" subscriptionTemplate.
     *
     * @param id the id of the subscriptionTemplateDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/subscription-templates/{id}")
    public ResponseEntity<Void> deleteSubscriptionTemplate(@PathVariable Long id) {
        log.debug("REST request to delete SubscriptionTemplate : {}", id);
        subscriptionTemplateService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

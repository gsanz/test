package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.DeviceDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Device and its DTO DeviceDTO.
 */
@Mapper(componentModel = "spring", uses = {DeviceTypeMapper.class, ZoneMapper.class, ProviderMapper.class, ProtocolMapper.class, FieldsMapper.class})
public interface DeviceMapper extends EntityMapper<DeviceDTO, Device> {

    @Mapping(source = "deviceType.id", target = "deviceTypeId")
    @Mapping(source = "deviceType.name", target = "deviceTypeName")
    @Mapping(source = "deviceType.reference", target = "deviceTypeReference")
    @Mapping(source = "deviceType.type", target = "deviceTypeType")
    @Mapping(source = "zone.id", target = "zoneId")
    @Mapping(source = "zone.name", target = "zoneName")
    @Mapping(source = "provider.id", target = "providerId")
    @Mapping(source = "provider.name", target = "providerName")
    @Mapping(source = "protocol.id", target = "protocolId")
    @Mapping(source = "protocol.name", target = "protocolName")

    DeviceDTO toDto(Device device);

    @Mapping(target = "alerts", ignore = true)
    @Mapping(target = "fields", ignore = false)
    @Mapping(source = "deviceTypeId", target = "deviceType")
    @Mapping(source = "zoneId", target = "zone")
    @Mapping(source = "providerId", target = "provider")
    @Mapping(source = "protocolId", target = "protocol")
    @Mapping(target = "rules", ignore = true)
    Device toEntity(DeviceDTO deviceDTO);

    default Device fromId(Long id) {
        if (id == null) {
            return null;
        }
        Device device = new Device();
        device.setId(id);
        return device;
    }
}

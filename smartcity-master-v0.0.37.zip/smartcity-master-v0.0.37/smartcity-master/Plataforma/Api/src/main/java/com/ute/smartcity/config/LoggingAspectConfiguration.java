package com.ute.smartcity.config;

import com.ute.smartcity.aop.logging.LoggingAspect;

import com.ute.smartcity.service.AuditoriaService;
import com.ute.smartcity.service.audit.ResourceAuditAspect;
import io.github.jhipster.config.JHipsterConstants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.core.env.Environment;

@Configuration
@EnableAspectJAutoProxy
public class LoggingAspectConfiguration {

    @Bean
    @Profile(JHipsterConstants.SPRING_PROFILE_DEVELOPMENT)
    public LoggingAspect loggingAspect(Environment env) {
        return new LoggingAspect(env);
    }

    @Bean
    @Profile(JHipsterConstants.SPRING_PROFILE_DEVELOPMENT)
    public ResourceAuditAspect resurceAuditAspect(Environment env, @Autowired AuditoriaService auditoriaService) {
        return new ResourceAuditAspect(env, auditoriaService);
    }
}

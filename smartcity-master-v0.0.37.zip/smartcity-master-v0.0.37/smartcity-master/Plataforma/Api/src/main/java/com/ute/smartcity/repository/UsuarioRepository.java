package com.ute.smartcity.repository;

import com.ute.smartcity.domain.Usuario;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data  repository for the Usuario entity.
 */
@SuppressWarnings("unused")
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long>, JpaSpecificationExecutor<Usuario> {

    @Query(value = "select distinct usuario from Usuario usuario left join fetch usuario.devicesTypes",
        countQuery = "select count(distinct usuario) from Usuario usuario")
    Page<Usuario> findAllWithEagerRelationships(Pageable pageable);

    @Query(value = "select distinct usuario from Usuario usuario left join fetch usuario.devicesTypes")
    List<Usuario> findAllWithEagerRelationships();

    @Query("select usuario from Usuario usuario left join fetch usuario.devicesTypes where usuario.id =:id")
    Optional<Usuario> findOneWithEagerRelationships(@Param("id") Long id);

    Usuario findOneById(Long id);

    Optional<Usuario> findOneByPhone(String phone);

    Optional<Usuario> findOneByProviderId(Long providerId);



}

package com.ute.smartcity.repository;

import com.ute.smartcity.domain.SubscriptionTemplate;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the SubscriptionTemplate entity.
 */
@SuppressWarnings("unused")
@Repository
public interface SubscriptionTemplateRepository extends JpaRepository<SubscriptionTemplate, Long>, JpaSpecificationExecutor<SubscriptionTemplate> {

}

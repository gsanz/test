package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.RuleQueryService;
import com.ute.smartcity.service.RuleService;
import com.ute.smartcity.service.dto.RuleCriteria;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Rule.
 */
@RestController
@RequestMapping("/api")
public class RuleResource {

    private final Logger log = LoggerFactory.getLogger(RuleResource.class);

    private static final String ENTITY_NAME = "rule";

    private final RuleService ruleService;

    private final RuleQueryService ruleQueryService;

    public RuleResource(RuleService ruleService, RuleQueryService ruleQueryService) {
        this.ruleService = ruleService;
        this.ruleQueryService = ruleQueryService;
    }

    /**
     * GET  /rules : get all the rules.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of rules in body
     */

    @GetMapping("/rules")
    public ResponseEntity<List<RuleDTO>> getAllRules(RuleCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Rules by criteria: {}", criteria);
        Page<RuleDTO> page = ruleQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/rules");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /rules/count : count all the rules.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/rules/count")
    public ResponseEntity<Long> countRules(RuleCriteria criteria) {
        log.debug("REST request to count Rules by criteria: {}", criteria);
        return ResponseEntity.ok().body(ruleQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /rules/:id : get the "id" rule.
     *
     * @param id the id of the ruleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the ruleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/rules/{id}")
    public ResponseEntity<RuleDTO> getRule(@PathVariable Long id) {
        log.debug("REST request to get Rule : {}", id);
        Optional<RuleDTO> ruleDTO = ruleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(ruleDTO);
    }

    /**
     * DELETE  /rules/:id : delete the "id" rule.
     *
     * @param id the id of the ruleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/rules/{id}")
    public ResponseEntity<Void> deleteRule(@PathVariable Long id) {
        log.debug("REST request to delete Rule : {}", id);
        try {
            ruleService.delete(id);
        } catch (PlatformException e) {
            log.error("error al eliminar regla de un dispositivo", e.getMessage());
            throw new BadRequestAlertException("There was an error trying to save the device to fiware", ENTITY_NAME, "fail-delete-orion-rule");
        }
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

package com.ute.smartcity.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * A Fields.
 */
@Entity
@Table(name = "fields")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataModelField implements Serializable {

    private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "jhi_type", nullable = false)
    private String type;

    @Column(name = "unit_ofmeasure", nullable = false)
    private String unitOfmeasure;


    @Lob
    @Column(name = "metadata")
    private String metadata;

    @Column(name = "jhi_value")
    private String defaultValue;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @JsonIgnore
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnitOfmeasure() {
        return unitOfmeasure;
    }

    public void setUnitOfmeasure(String unitOfmeasure) {
        this.unitOfmeasure = unitOfmeasure;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
}

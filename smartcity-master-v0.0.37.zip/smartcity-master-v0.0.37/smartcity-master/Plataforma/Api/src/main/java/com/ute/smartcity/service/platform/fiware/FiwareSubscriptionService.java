package com.ute.smartcity.service.platform.fiware;

import com.ute.smartcity.service.AuditFiwarePlatformService;
import com.ute.smartcity.service.dto.SubscriptionsDTO;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformSubscriptionService;
import com.ute.smartcity.service.dto.FiwareSubscriptionDTO;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.web.rest.FieldsResource;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class FiwareSubscriptionService implements SmartCityPlatformSubscriptionService {
    private static final String ENTITY_NAME = "FiwareSubscriptionService";

    private final Logger log = LoggerFactory.getLogger(FieldsResource.class);


    @Value("${application.fiware.orion.url}")
    public String orionURL;

    @Value("${application.fiware.service-path}")
    public String fiware_service;

    @Value("${application.fiware.orion.subscription}")
    public String subscription;

    @Autowired
    ResourceLoader resourceLoader;

    private final FiwareOrionService fiwareOrionService;

    public FiwareSubscriptionService(FiwareOrionService fiwareOrionService) {
        this.fiwareOrionService = fiwareOrionService;

    }

    private String loadSubcriptionTemplate() {//cambiada la devolución Template por String
        String result ="";
        try {
            Resource resource = resourceLoader
                .getResource("classpath:templates/fiware/subscription_template.txt");
            InputStream inputStream = resource.getInputStream(); //

            result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

            return result;
        } catch (IOException e) {

            log.debug("IOException when trying to parse the subscription_template.txt to a string ",e);
        }

        return null;
    }

    @Override
    public List<FiwareSubscriptionDTO> addSubscriptions(List<FiwareSubscriptionDTO> subscriptionDTOList) throws PlatformException {
        List<FiwareSubscriptionDTO> fiwareSubscriptionDTOListWithID = new ArrayList<>();
        for (FiwareSubscriptionDTO fiwareSubs : subscriptionDTOList) {
            String servicepath = fiwareSubs.getServicepath();
            String name = fiwareSubs.getDescription();
            String endpoint = fiwareSubs.getUrl();
            String type = fiwareSubs.getType();
            String subscription = loadSubcriptionTemplate();

            if(subscription != null) {
                subscription = subscription.replace("${descripcion}", name);
                subscription = subscription.replace("${type}", type);
                subscription = subscription.replace("${endpoint_subscription}", endpoint);
            }

            ResponseEntity<String> respuesta = null;

            try {
                respuesta = fiwareOrionService.addSubscription(subscription, servicepath);
                for (Map.Entry<String, List<String>> entry : respuesta.getHeaders().entrySet()){
                    if(entry.getKey().toLowerCase().equals("location")) {
                        String id = entry.getValue().get(0).replace("/"+this.subscription+"/","");
                        fiwareSubs.setIdPattern(id);
                    }
                }
            } catch (PlatformException e) {
                throw new  PlatformException(e);
            }
            fiwareSubscriptionDTOListWithID.add(fiwareSubs);
        }
        return fiwareSubscriptionDTOListWithID;
    }

    @Override
    public ResponseEntity<String> addSubscription(FiwareSubscriptionDTO fiwareSubscriptionDTO) throws Exception {

        String servicepath = fiwareSubscriptionDTO.getServicepath();
        String name = fiwareSubscriptionDTO.getDescription();
        String endpoint = fiwareSubscriptionDTO.getUrl();
        String type = fiwareSubscriptionDTO.getType();

        String subscription = loadSubcriptionTemplate();
        if(subscription != null) {
            subscription = subscription.replace("${descripcion}", name);
            subscription = subscription.replace("${type}", type);
            subscription = subscription.replace("${endpoint_subscription}", endpoint);
        }

        ResponseEntity<String> respuesta = null;

        try {
             respuesta = fiwareOrionService.addSubscription(subscription, servicepath);
        } catch (PlatformException e) {
            throw new Exception(e.getMessage());
        }
        return respuesta;
    }

    public void deleteSubscription(SubscriptionsDTO subscriptionDTO) throws PlatformException {
        String platformId = subscriptionDTO.getPlatformId();
        fiwareOrionService.deleteSubscription(platformId);
    }
}

package com.ute.smartcity.web.rest;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.DeviceTypeService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for managing DeviceType.
 */
@RestController
@RequestMapping("/api")
@Api(value="deviceType-resource" , description = "DeviceType Resource", tags = "deviceType-resource")
public class DeviceTypeResource {

    private final Logger log = LoggerFactory.getLogger(DeviceTypeResource.class);

    private static final String ENTITY_NAME = "deviceType";

    private final DeviceTypeService deviceTypeService;

    public DeviceTypeResource(DeviceTypeService deviceTypeService) {
        this.deviceTypeService = deviceTypeService;
    }

}

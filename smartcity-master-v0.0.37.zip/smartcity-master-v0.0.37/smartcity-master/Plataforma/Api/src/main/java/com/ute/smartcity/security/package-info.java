/**
 * Spring Security configuration.
 */
package com.ute.smartcity.security;

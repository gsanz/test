package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.Rule;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.dto.RuleListDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * Mapper for the entity Rule and its DTO RuleDTO.
 */
@Mapper(componentModel = "spring", uses = {DeviceTypeMapper.class, DeviceMapper.class})
public interface RuleListMapper extends EntityMapper<RuleListDTO, Rule> {

    @Mapping(source = "deviceType.id", target = "deviceTypeId")
    @Mapping(source = "deviceType.name", target = "deviceTypeName")
    RuleListDTO toDto(Rule rule);

    @Mapping(target = "ruleCompareFields", ignore = true)
    @Mapping(target = "ruleActions", ignore = true)
    @Mapping(target = "devices", ignore = true)
    @Mapping(source = "deviceTypeId", target = "deviceType")
    Rule toEntity(RuleDTO ruleDTO);

    default Rule fromId(Long id) {
        if (id == null) {
            return null;
        }
        Rule rule = new Rule();
        rule.setId(id);
        return rule;
    }
}

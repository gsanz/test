package com.ute.smartcity.service;

import com.ute.smartcity.domain.Alert;
import com.ute.smartcity.domain.User;

import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.service.dto.UserDTO;
import io.github.jhipster.config.JHipsterProperties;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.time.Month;
import java.time.ZonedDateTime;
import java.util.Locale;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

/**
 * Service for sending emails.
 * <p>
 * We use the @Async annotation to send emails asynchronously.
 */
@Service
public class MailService {

    private final Logger log = LoggerFactory.getLogger(MailService.class);

    @Value("${application.notification_mail}")
    private String notification_mail;

    private static final String USER = "user";

    private static final String USUARIO = "usuario";

    private static final String ALERT = "alert";

    private static final String DATE = "date";

    private static final String BASE_URL = "baseUrl";

    private final JHipsterProperties jHipsterProperties;

    private final JavaMailSender javaMailSender;

    private final MessageSource messageSource;

    private final SpringTemplateEngine templateEngine;

    public MailService(JHipsterProperties jHipsterProperties, JavaMailSender javaMailSender,
                       MessageSource messageSource, SpringTemplateEngine templateEngine) {

        this.jHipsterProperties = jHipsterProperties;
        this.javaMailSender = javaMailSender;
        this.messageSource = messageSource;
        this.templateEngine = templateEngine;
    }

    @Async
    public void sendEmail(String to, String subject, String content, boolean isMultipart, boolean isHtml) {
        log.debug("Send email[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}",
            isMultipart, isHtml, to, subject, content);

        // Prepare message using a Spring helper
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
            message.addAttachment("pieEmail.jpg", new ClassPathResource("templates/mail/pieEmail.jpg"));
            message.setTo(to);
            message.setFrom(jHipsterProperties.getMail().getFrom());
            message.setSubject(subject);
            message.setText(content, isHtml);
            javaMailSender.send(mimeMessage);
            log.debug("Sent email to User '{}'", to);
        } catch (Exception e) {
            if (log.isDebugEnabled()) {
                log.warn("Email could not be sent to user '{}'", to, e);
            } else {
                log.warn("Email could not be sent to user '{}': {}", to, e.getMessage());
            }
        }
    }

    @Async
    public void sendEmailFromTemplate(User user, String templateName, String titleKey) {
        Locale locale = Locale.forLanguageTag(user.getLangKey());
        Context context = new Context(locale);
        context.setVariable(USER, user);
        context.setVariable(BASE_URL, jHipsterProperties.getMail().getBaseUrl());
        String content = templateEngine.process(templateName, context);
        String subject = messageSource.getMessage(titleKey, null, locale);
        sendEmail(user.getEmail(), subject, content, false, true);
    }

    @Async
    public void sendAlertEmailFromTemplate(Alert alert, String templateName, String titleKey) {
        Locale locale = Locale.forLanguageTag(/*user.getLangKey() ¿COMO LO ARREGLO?*/ "es");
        String beautifiedDate = beautifyDate(alert.getCreateAt());
        Context context = new Context(locale);
        context.setVariable(DATE, beautifiedDate);
        context.setVariable(ALERT, alert);
        context.setVariable(BASE_URL, jHipsterProperties.getMail().getBaseUrl());
        String content = templateEngine.process(templateName, context);
        String subject = messageSource.getMessage(titleKey, null, locale);
        sendEmail(notification_mail, subject, content, false, true);

    }

    private String beautifyDate(ZonedDateTime date) {
        int day = date.getDayOfMonth();
        int month = date.getMonthValue();
        int year = date.getYear();
        int hour = date.getHour();
        int minute = date.getMinute();
        int second = date.getSecond();

        return day + "-" + month + "-" + year + "  " + hour + ":" + minute + ":" + second;
    }

    @Async
    public void sendEmailFromTemplateUsuario(Usuario usuario, String templateName, String titleKey) {
        Locale locale = Locale.forLanguageTag(usuario.getUser().getLangKey());
        Context context = new Context(locale);
        context.setVariable(USUARIO, usuario);
        context.setVariable(BASE_URL, jHipsterProperties.getMail().getBaseUrl());
        String content = templateEngine.process(templateName, context);
        String subject = messageSource.getMessage(titleKey, null, locale);
        sendEmail(usuario.getUser().getEmail(), subject, content, false, true);
    }

    @Async
    public void sendEmailFromTemplateOptional(UserDTO user, String templateName, String titleKey) {
        Locale locale = Locale.forLanguageTag(user.getLangKey());
        Context context = new Context(locale);
        context.setVariable(USER, user);
        context.setVariable(BASE_URL, jHipsterProperties.getMail().getBaseUrl());
        String content = templateEngine.process(templateName, context);
        String subject = messageSource.getMessage(titleKey, null, locale);
        sendEmail(user.getEmail(), subject, content, false, true);
    }

    @Async
    public void sendActivationEmail(User user) {
        log.debug("Sending activation email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/activationEmail", "email.activation.title");
    }

    @Async
    public void sendChangemailEmail(User user) {
        log.debug("Sending change mail email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/changeEmail", "email.update.title");
    }


    @Async
    public void sendCreationEmail(User user) {
        log.debug("Sending creation email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/creationEmail", "email.activation.title");
    }

    @Async
    public void sendPasswordResetMail(User user) {
        log.debug("Sending password reset email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/passwordResetEmail", "email.reset.title");
    }

    @Async
    public void sendCodeDoubleAuthMail(Usuario usuario) {
        log.debug("Sending double auth code email to '{}'", usuario.getUser().getEmail());
        sendEmailFromTemplateUsuario(usuario, "mail/codeEmail", "email.code.title");
    }

    @Async
    public void sendUserDisabledMail(User user) {
        log.debug("Sending password reset email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/disableEmail", "email.disabled.title");
    }

    @Async
    public void sendAlertMail(Alert alert) {
        log.debug("Sending alert email to '{}'", notification_mail);
        sendAlertEmailFromTemplate(alert, "mail/alertEmail", "email.alert.title");
    }
}

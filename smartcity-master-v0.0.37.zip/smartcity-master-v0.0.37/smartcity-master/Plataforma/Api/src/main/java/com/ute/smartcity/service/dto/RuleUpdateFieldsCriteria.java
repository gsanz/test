package com.ute.smartcity.service.dto;

import java.io.Serializable;
import java.util.Objects;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;

/**
 * Criteria class for the RuleUpdateFields entity. This class is used in RuleUpdateFieldsResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /rule-update-fields?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class RuleUpdateFieldsCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter value;

    private StringFilter fieldName;

    private LongFilter ruleActionId;

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getValue() {
        return value;
    }

    public void setValue(StringFilter value) {
        this.value = value;
    }

    public StringFilter getFieldName() {
        return fieldName;
    }

    public void setFieldName(StringFilter fieldName) {
        this.fieldName = fieldName;
    }

    public LongFilter getRuleActionId() {
        return ruleActionId;
    }

    public void setRuleActionId(LongFilter ruleActionId) {
        this.ruleActionId = ruleActionId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final RuleUpdateFieldsCriteria that = (RuleUpdateFieldsCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(value, that.value) &&
            Objects.equals(fieldName, that.fieldName) &&
            Objects.equals(ruleActionId, that.ruleActionId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        value,
        fieldName,
        ruleActionId
        );
    }

    @Override
    public String toString() {
        return "RuleUpdateFieldsCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (value != null ? "value=" + value + ", " : "") +
                (fieldName != null ? "fieldName=" + fieldName + ", " : "") +
                (ruleActionId != null ? "ruleActionId=" + ruleActionId + ", " : "") +
            "}";
    }

}

package com.ute.smartcity.service.dto;

import java.io.Serializable;
import java.util.Objects;
import com.ute.smartcity.domain.enumeration.RuleActionType;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;

/**
 * Criteria class for the RuleAction entity. This class is used in RuleActionResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /rule-actions?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class RuleActionCriteria implements Serializable {
    /**
     * Class for filtering RuleActionType
     */
    public static class RuleActionTypeFilter extends Filter<RuleActionType> {
    }

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private RuleActionTypeFilter ruleActionType;

    private StringFilter subject;

    private StringFilter template;

    private StringFilter from;

    private StringFilter to;

    private StringFilter postParameters;

    private LongFilter ruleId;

    private LongFilter ruleUpdateFieldsId;

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public RuleActionTypeFilter getRuleActionType() {
        return ruleActionType;
    }

    public void setRuleActionType(RuleActionTypeFilter ruleActionType) {
        this.ruleActionType = ruleActionType;
    }

    public StringFilter getSubject() {
        return subject;
    }

    public void setSubject(StringFilter subject) {
        this.subject = subject;
    }

    public StringFilter getTemplate() {
        return template;
    }

    public void setTemplate(StringFilter template) {
        this.template = template;
    }

    public StringFilter getFrom() {
        return from;
    }

    public void setFrom(StringFilter from) {
        this.from = from;
    }

    public StringFilter getTo() {
        return to;
    }

    public void setTo(StringFilter to) {
        this.to = to;
    }

    public StringFilter getPostParameters() {
        return postParameters;
    }

    public void setPostParameters(StringFilter postParameters) {
        this.postParameters = postParameters;
    }

    public LongFilter getRuleId() {
        return ruleId;
    }

    public void setRuleId(LongFilter ruleId) {
        this.ruleId = ruleId;
    }

    public LongFilter getRuleUpdateFieldsId() {
        return ruleUpdateFieldsId;
    }

    public void setRuleUpdateFieldsId(LongFilter ruleUpdateFieldsId) {
        this.ruleUpdateFieldsId = ruleUpdateFieldsId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final RuleActionCriteria that = (RuleActionCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(ruleActionType, that.ruleActionType) &&
            Objects.equals(subject, that.subject) &&
            Objects.equals(template, that.template) &&
            Objects.equals(from, that.from) &&
            Objects.equals(to, that.to) &&
            Objects.equals(postParameters, that.postParameters) &&
            Objects.equals(ruleId, that.ruleId) &&
            Objects.equals(ruleUpdateFieldsId, that.ruleUpdateFieldsId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        ruleActionType,
        subject,
        template,
        from,
        to,
        postParameters,
        ruleId,
        ruleUpdateFieldsId
        );
    }

    @Override
    public String toString() {
        return "RuleActionCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (ruleActionType != null ? "ruleActionType=" + ruleActionType + ", " : "") +
                (subject != null ? "subject=" + subject + ", " : "") +
                (template != null ? "template=" + template + ", " : "") +
                (from != null ? "from=" + from + ", " : "") +
                (to != null ? "to=" + to + ", " : "") +
                (postParameters != null ? "postParameters=" + postParameters + ", " : "") +
                (ruleId != null ? "ruleId=" + ruleId + ", " : "") +
                (ruleUpdateFieldsId != null ? "ruleUpdateFieldsId=" + ruleUpdateFieldsId + ", " : "") +
            "}";
    }

}

package com.ute.smartcity.service.dto;

import java.io.Serializable;
import java.util.Objects;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;

/**
 * Criteria class for the Fields entity. This class is used in FieldsResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /fields?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class FieldsCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter name;

    private StringFilter abbreviation;

    private StringFilter description;

    private StringFilter type;

    private StringFilter unitOfmeasure;

    private StringFilter value;

    private LongFilter deviceId;

    private LongFilter deviceTypeId;

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getName() {
        return name;
    }

    public void setName(StringFilter name) {
        this.name = name;
    }

    public StringFilter getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(StringFilter abbreviation) {
        this.abbreviation = abbreviation;
    }

    public StringFilter getDescription() {
        return description;
    }

    public void setDescription(StringFilter description) {
        this.description = description;
    }

    public StringFilter getType() {
        return type;
    }

    public void setType(StringFilter type) {
        this.type = type;
    }

    public StringFilter getUnitOfmeasure() {
        return unitOfmeasure;
    }

    public void setUnitOfmeasure(StringFilter unitOfmeasure) {
        this.unitOfmeasure = unitOfmeasure;
    }

    public StringFilter getValue() {
        return value;
    }

    public void setValue(StringFilter value) {
        this.value = value;
    }

    public LongFilter getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(LongFilter deviceId) {
        this.deviceId = deviceId;
    }

    public LongFilter getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(LongFilter deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final FieldsCriteria that = (FieldsCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(name, that.name) &&
            Objects.equals(abbreviation, that.abbreviation) &&
            Objects.equals(description, that.description) &&
            Objects.equals(type, that.type) &&
            Objects.equals(unitOfmeasure, that.unitOfmeasure) &&
            Objects.equals(value, that.value) &&
            Objects.equals(deviceId, that.deviceId) &&
            Objects.equals(deviceTypeId, that.deviceTypeId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        name,
        abbreviation,
        description,
        type,
        unitOfmeasure,
        value,
        deviceId,
        deviceTypeId
        );
    }

    @Override
    public String toString() {
        return "FieldsCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (name != null ? "name=" + name + ", " : "") +
                (abbreviation != null ? "abbreviation=" + abbreviation + ", " : "") +
                (description != null ? "description=" + description + ", " : "") +
                (type != null ? "type=" + type + ", " : "") +
                (unitOfmeasure != null ? "unitOfmeasure=" + unitOfmeasure + ", " : "") +
                (value != null ? "value=" + value + ", " : "") +
                (deviceId != null ? "deviceId=" + deviceId + ", " : "") +
                (deviceTypeId != null ? "deviceTypeId=" + deviceTypeId + ", " : "") +
            "}";
    }

}

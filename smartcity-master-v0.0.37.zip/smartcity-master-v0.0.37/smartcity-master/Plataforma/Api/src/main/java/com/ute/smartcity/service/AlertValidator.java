package com.ute.smartcity.service;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.enumeration.CriticalityLevel;
import com.ute.smartcity.service.dto.AlertDTO;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.exception.DeviceNotInRuleException;
import com.ute.smartcity.service.exception.DeviceNotPresentException;
import com.ute.smartcity.service.exception.NullDeviceReferenceInAlert;

import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Optional;

@Component
public class AlertValidator {

    private final DeviceService deviceService;

    private final RuleService ruleService;

    public AlertValidator(DeviceService deviceService, RuleService ruleService) {
        this.deviceService = deviceService;
        this.ruleService = ruleService;
    }


    public AlertDTO validate(AlertDTO alertDTO) throws NullDeviceReferenceInAlert, DeviceNotPresentException,
        DeviceNotInRuleException {

        if (alertDTO.getDeviceId()==null){

            deviceReferenceInAlertDTO(alertDTO);

            Optional<Device> device = this.deviceService.findByReference(alertDTO.getDeviceReference());

            deviceIsPresent(device);

            if (alertDTO.getDeviceId()==null) {
                if (device.isPresent()) alertDTO.setDeviceId(device.get().getId());
                else alertDTO.setDeviceId(null);
            }

            Optional<RuleDTO> rule = this.ruleService.findByReference(alertDTO.getRule());
            if (!rule.isPresent()) {

                alertDTO.setDescription("Rule not found");
            } else {
                alertDTO.setDescription(rule.get().getDescription());
                devicesInRuleByReference(rule, alertDTO.getDeviceReference());
            }
        }
        ZonedDateTime dateTime = Instant.now().atZone(ZoneId.of("Europe/Madrid"));
        alertDTO.setCreateAt(dateTime);
        if (alertDTO.getCriticalityLevel() == null){
            alertDTO.setCriticalityLevel(CriticalityLevel.CRITICAL);
        }
        return alertDTO;
    }

    public void deviceReferenceInAlertDTO(AlertDTO alertDTO) throws NullDeviceReferenceInAlert {
        if (alertDTO.getDeviceReference() == null){
            throw new NullDeviceReferenceInAlert("A new alert should have a device reference", alertDTO);
        }
    }

    public void deviceIsPresent(Optional<Device> device) throws DeviceNotPresentException {
        if (!device.isPresent()) {
            throw new DeviceNotPresentException("Device does not exist", device);
        }
    }

    public void devicesInRuleByReference(Optional<RuleDTO> rule, String deviceReference) throws DeviceNotInRuleException {
        RuleDTO ruleDTO = null;
        if(rule.isPresent()) {
            ruleDTO = rule.get();
        }
        if(ruleDTO != null ) {
            if(ruleDTO.getDevices() != null ) {
                boolean checkDeviceInRule = !ruleDTO.getDevices().isEmpty();
                if (checkDeviceInRule) {
                    long numDevicesFound = ruleDTO.getDevices()
                        .stream()
                        .filter(c -> c.getReference().contains(deviceReference))
                        .count();
                    boolean ruleNotApply = (numDevicesFound == 0);

                    if (ruleNotApply) {
                        throw new DeviceNotInRuleException("The device is not included in the rule", ruleDTO);
                    }
                }
            }
        }
    }
}

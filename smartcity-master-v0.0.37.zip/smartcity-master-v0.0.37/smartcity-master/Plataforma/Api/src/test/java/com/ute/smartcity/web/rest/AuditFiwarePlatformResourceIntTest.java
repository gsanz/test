package com.ute.smartcity.web.rest;

import com.ute.smartcity.SmartcityApp;

import com.ute.smartcity.domain.AuditFiwarePlatform;
import com.ute.smartcity.repository.AuditFiwarePlatformRepository;
import com.ute.smartcity.service.AuditFiwarePlatformService;
import com.ute.smartcity.service.dto.AuditFiwarePlatformDTO;
import com.ute.smartcity.service.mapper.AuditFiwarePlatformMapper;
import com.ute.smartcity.web.rest.errors.ExceptionTranslator;
import com.ute.smartcity.service.dto.AuditFiwarePlatformCriteria;
import com.ute.smartcity.service.AuditFiwarePlatformQueryService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;


import static com.ute.smartcity.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the AuditFiwarePlatformResource REST controller.
 *
 * @see AuditFiwarePlatformResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmartcityApp.class)
public class AuditFiwarePlatformResourceIntTest {

    private static final Instant DEFAULT_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final String DEFAULT_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_TYPE = "BBBBBBBBBB";

    private static final String DEFAULT_REQUEST_URL = "AAAAAAAAAA";
    private static final String UPDATED_REQUEST_URL = "BBBBBBBBBB";

    private static final String DEFAULT_REQUEST_CONTENT = "AAAAAAAAAA";
    private static final String UPDATED_REQUEST_CONTENT = "BBBBBBBBBB";

    private static final String DEFAULT_RESPONSE_CONTENT = "AAAAAAAAAA";
    private static final String UPDATED_RESPONSE_CONTENT = "BBBBBBBBBB";

    private static final Integer DEFAULT_RESPONSE_CODE = 1;
    private static final Integer UPDATED_RESPONSE_CODE = 2;

    @Autowired
    private AuditFiwarePlatformRepository auditFiwarePlatformRepository;

    @Autowired
    private AuditFiwarePlatformMapper auditFiwarePlatformMapper;

    @Autowired
    private AuditFiwarePlatformService auditFiwarePlatformService;

    @Autowired
    private AuditFiwarePlatformQueryService auditFiwarePlatformQueryService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restAuditFiwarePlatformMockMvc;

    private AuditFiwarePlatform auditFiwarePlatform;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final AuditFiwarePlatformResource auditFiwarePlatformResource = new AuditFiwarePlatformResource(auditFiwarePlatformService, auditFiwarePlatformQueryService);
        this.restAuditFiwarePlatformMockMvc = MockMvcBuilders.standaloneSetup(auditFiwarePlatformResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AuditFiwarePlatform createEntity(EntityManager em) {
        AuditFiwarePlatform auditFiwarePlatform = new AuditFiwarePlatform()
            .date(DEFAULT_DATE)
            .type(DEFAULT_TYPE)
            .requestUrl(DEFAULT_REQUEST_URL)
            .requestContent(DEFAULT_REQUEST_CONTENT)
            .responseContent(DEFAULT_RESPONSE_CONTENT)
            .responseCode(DEFAULT_RESPONSE_CODE);
        return auditFiwarePlatform;
    }

    @Before
    public void initTest() {
        auditFiwarePlatform = createEntity(em);
    }

    @Test
    @Transactional
    public void createAuditFiwarePlatform() throws Exception {
        int databaseSizeBeforeCreate = auditFiwarePlatformRepository.findAll().size();

        // Create the AuditFiwarePlatform
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);
        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isCreated());

        // Validate the AuditFiwarePlatform in the database
        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeCreate + 1);
        AuditFiwarePlatform testAuditFiwarePlatform = auditFiwarePlatformList.get(auditFiwarePlatformList.size() - 1);
        assertThat(testAuditFiwarePlatform.getDate()).isEqualTo(DEFAULT_DATE);
        assertThat(testAuditFiwarePlatform.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testAuditFiwarePlatform.getRequestUrl()).isEqualTo(DEFAULT_REQUEST_URL);
        assertThat(testAuditFiwarePlatform.getRequestContent()).isEqualTo(DEFAULT_REQUEST_CONTENT);
        assertThat(testAuditFiwarePlatform.getResponseContent()).isEqualTo(DEFAULT_RESPONSE_CONTENT);
        assertThat(testAuditFiwarePlatform.getResponseCode()).isEqualTo(DEFAULT_RESPONSE_CODE);
    }

    @Test
    @Transactional
    public void createAuditFiwarePlatformWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = auditFiwarePlatformRepository.findAll().size();

        // Create the AuditFiwarePlatform with an existing ID
        auditFiwarePlatform.setId(1L);
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        // An entity with an existing ID cannot be created, so this API call must fail
        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        // Validate the AuditFiwarePlatform in the database
        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditFiwarePlatformRepository.findAll().size();
        // set the field null
        auditFiwarePlatform.setDate(null);

        // Create the AuditFiwarePlatform, which fails.
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditFiwarePlatformRepository.findAll().size();
        // set the field null
        auditFiwarePlatform.setType(null);

        // Create the AuditFiwarePlatform, which fails.
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkRequestUrlIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditFiwarePlatformRepository.findAll().size();
        // set the field null
        auditFiwarePlatform.setRequestUrl(null);

        // Create the AuditFiwarePlatform, which fails.
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkRequestContentIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditFiwarePlatformRepository.findAll().size();
        // set the field null
        auditFiwarePlatform.setRequestContent(null);

        // Create the AuditFiwarePlatform, which fails.
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkResponseContentIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditFiwarePlatformRepository.findAll().size();
        // set the field null
        auditFiwarePlatform.setResponseContent(null);

        // Create the AuditFiwarePlatform, which fails.
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkResponseCodeIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditFiwarePlatformRepository.findAll().size();
        // set the field null
        auditFiwarePlatform.setResponseCode(null);

        // Create the AuditFiwarePlatform, which fails.
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        restAuditFiwarePlatformMockMvc.perform(post("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatforms() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList
        restAuditFiwarePlatformMockMvc.perform(get("/api/audit-fiware-platforms?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(auditFiwarePlatform.getId().intValue())))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].requestUrl").value(hasItem(DEFAULT_REQUEST_URL.toString())))
            .andExpect(jsonPath("$.[*].requestContent").value(hasItem(DEFAULT_REQUEST_CONTENT.toString())))
            .andExpect(jsonPath("$.[*].responseContent").value(hasItem(DEFAULT_RESPONSE_CONTENT.toString())))
            .andExpect(jsonPath("$.[*].responseCode").value(hasItem(DEFAULT_RESPONSE_CODE)));
    }
    
    @Test
    @Transactional
    public void getAuditFiwarePlatform() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get the auditFiwarePlatform
        restAuditFiwarePlatformMockMvc.perform(get("/api/audit-fiware-platforms/{id}", auditFiwarePlatform.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(auditFiwarePlatform.getId().intValue()))
            .andExpect(jsonPath("$.date").value(DEFAULT_DATE.toString()))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.requestUrl").value(DEFAULT_REQUEST_URL.toString()))
            .andExpect(jsonPath("$.requestContent").value(DEFAULT_REQUEST_CONTENT.toString()))
            .andExpect(jsonPath("$.responseContent").value(DEFAULT_RESPONSE_CONTENT.toString()))
            .andExpect(jsonPath("$.responseCode").value(DEFAULT_RESPONSE_CODE));
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByDateIsEqualToSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where date equals to DEFAULT_DATE
        defaultAuditFiwarePlatformShouldBeFound("date.equals=" + DEFAULT_DATE);

        // Get all the auditFiwarePlatformList where date equals to UPDATED_DATE
        defaultAuditFiwarePlatformShouldNotBeFound("date.equals=" + UPDATED_DATE);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByDateIsInShouldWork() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where date in DEFAULT_DATE or UPDATED_DATE
        defaultAuditFiwarePlatformShouldBeFound("date.in=" + DEFAULT_DATE + "," + UPDATED_DATE);

        // Get all the auditFiwarePlatformList where date equals to UPDATED_DATE
        defaultAuditFiwarePlatformShouldNotBeFound("date.in=" + UPDATED_DATE);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByDateIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where date is not null
        defaultAuditFiwarePlatformShouldBeFound("date.specified=true");

        // Get all the auditFiwarePlatformList where date is null
        defaultAuditFiwarePlatformShouldNotBeFound("date.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByTypeIsEqualToSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where type equals to DEFAULT_TYPE
        defaultAuditFiwarePlatformShouldBeFound("type.equals=" + DEFAULT_TYPE);

        // Get all the auditFiwarePlatformList where type equals to UPDATED_TYPE
        defaultAuditFiwarePlatformShouldNotBeFound("type.equals=" + UPDATED_TYPE);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByTypeIsInShouldWork() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where type in DEFAULT_TYPE or UPDATED_TYPE
        defaultAuditFiwarePlatformShouldBeFound("type.in=" + DEFAULT_TYPE + "," + UPDATED_TYPE);

        // Get all the auditFiwarePlatformList where type equals to UPDATED_TYPE
        defaultAuditFiwarePlatformShouldNotBeFound("type.in=" + UPDATED_TYPE);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByTypeIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where type is not null
        defaultAuditFiwarePlatformShouldBeFound("type.specified=true");

        // Get all the auditFiwarePlatformList where type is null
        defaultAuditFiwarePlatformShouldNotBeFound("type.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByRequestUrlIsEqualToSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where requestUrl equals to DEFAULT_REQUEST_URL
        defaultAuditFiwarePlatformShouldBeFound("requestUrl.equals=" + DEFAULT_REQUEST_URL);

        // Get all the auditFiwarePlatformList where requestUrl equals to UPDATED_REQUEST_URL
        defaultAuditFiwarePlatformShouldNotBeFound("requestUrl.equals=" + UPDATED_REQUEST_URL);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByRequestUrlIsInShouldWork() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where requestUrl in DEFAULT_REQUEST_URL or UPDATED_REQUEST_URL
        defaultAuditFiwarePlatformShouldBeFound("requestUrl.in=" + DEFAULT_REQUEST_URL + "," + UPDATED_REQUEST_URL);

        // Get all the auditFiwarePlatformList where requestUrl equals to UPDATED_REQUEST_URL
        defaultAuditFiwarePlatformShouldNotBeFound("requestUrl.in=" + UPDATED_REQUEST_URL);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByRequestUrlIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where requestUrl is not null
        defaultAuditFiwarePlatformShouldBeFound("requestUrl.specified=true");

        // Get all the auditFiwarePlatformList where requestUrl is null
        defaultAuditFiwarePlatformShouldNotBeFound("requestUrl.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByRequestContentIsEqualToSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where requestContent equals to DEFAULT_REQUEST_CONTENT
        defaultAuditFiwarePlatformShouldBeFound("requestContent.equals=" + DEFAULT_REQUEST_CONTENT);

        // Get all the auditFiwarePlatformList where requestContent equals to UPDATED_REQUEST_CONTENT
        defaultAuditFiwarePlatformShouldNotBeFound("requestContent.equals=" + UPDATED_REQUEST_CONTENT);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByRequestContentIsInShouldWork() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where requestContent in DEFAULT_REQUEST_CONTENT or UPDATED_REQUEST_CONTENT
        defaultAuditFiwarePlatformShouldBeFound("requestContent.in=" + DEFAULT_REQUEST_CONTENT + "," + UPDATED_REQUEST_CONTENT);

        // Get all the auditFiwarePlatformList where requestContent equals to UPDATED_REQUEST_CONTENT
        defaultAuditFiwarePlatformShouldNotBeFound("requestContent.in=" + UPDATED_REQUEST_CONTENT);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByRequestContentIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where requestContent is not null
        defaultAuditFiwarePlatformShouldBeFound("requestContent.specified=true");

        // Get all the auditFiwarePlatformList where requestContent is null
        defaultAuditFiwarePlatformShouldNotBeFound("requestContent.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseContentIsEqualToSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseContent equals to DEFAULT_RESPONSE_CONTENT
        defaultAuditFiwarePlatformShouldBeFound("responseContent.equals=" + DEFAULT_RESPONSE_CONTENT);

        // Get all the auditFiwarePlatformList where responseContent equals to UPDATED_RESPONSE_CONTENT
        defaultAuditFiwarePlatformShouldNotBeFound("responseContent.equals=" + UPDATED_RESPONSE_CONTENT);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseContentIsInShouldWork() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseContent in DEFAULT_RESPONSE_CONTENT or UPDATED_RESPONSE_CONTENT
        defaultAuditFiwarePlatformShouldBeFound("responseContent.in=" + DEFAULT_RESPONSE_CONTENT + "," + UPDATED_RESPONSE_CONTENT);

        // Get all the auditFiwarePlatformList where responseContent equals to UPDATED_RESPONSE_CONTENT
        defaultAuditFiwarePlatformShouldNotBeFound("responseContent.in=" + UPDATED_RESPONSE_CONTENT);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseContentIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseContent is not null
        defaultAuditFiwarePlatformShouldBeFound("responseContent.specified=true");

        // Get all the auditFiwarePlatformList where responseContent is null
        defaultAuditFiwarePlatformShouldNotBeFound("responseContent.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseCodeIsEqualToSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseCode equals to DEFAULT_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldBeFound("responseCode.equals=" + DEFAULT_RESPONSE_CODE);

        // Get all the auditFiwarePlatformList where responseCode equals to UPDATED_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldNotBeFound("responseCode.equals=" + UPDATED_RESPONSE_CODE);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseCodeIsInShouldWork() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseCode in DEFAULT_RESPONSE_CODE or UPDATED_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldBeFound("responseCode.in=" + DEFAULT_RESPONSE_CODE + "," + UPDATED_RESPONSE_CODE);

        // Get all the auditFiwarePlatformList where responseCode equals to UPDATED_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldNotBeFound("responseCode.in=" + UPDATED_RESPONSE_CODE);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseCodeIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseCode is not null
        defaultAuditFiwarePlatformShouldBeFound("responseCode.specified=true");

        // Get all the auditFiwarePlatformList where responseCode is null
        defaultAuditFiwarePlatformShouldNotBeFound("responseCode.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseCodeIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseCode greater than or equals to DEFAULT_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldBeFound("responseCode.greaterOrEqualThan=" + DEFAULT_RESPONSE_CODE);

        // Get all the auditFiwarePlatformList where responseCode greater than or equals to UPDATED_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldNotBeFound("responseCode.greaterOrEqualThan=" + UPDATED_RESPONSE_CODE);
    }

    @Test
    @Transactional
    public void getAllAuditFiwarePlatformsByResponseCodeIsLessThanSomething() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        // Get all the auditFiwarePlatformList where responseCode less than or equals to DEFAULT_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldNotBeFound("responseCode.lessThan=" + DEFAULT_RESPONSE_CODE);

        // Get all the auditFiwarePlatformList where responseCode less than or equals to UPDATED_RESPONSE_CODE
        defaultAuditFiwarePlatformShouldBeFound("responseCode.lessThan=" + UPDATED_RESPONSE_CODE);
    }

    /**
     * Executes the search, and checks that the default entity is returned
     */
    private void defaultAuditFiwarePlatformShouldBeFound(String filter) throws Exception {
        restAuditFiwarePlatformMockMvc.perform(get("/api/audit-fiware-platforms?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(auditFiwarePlatform.getId().intValue())))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE)))
            .andExpect(jsonPath("$.[*].requestUrl").value(hasItem(DEFAULT_REQUEST_URL)))
            .andExpect(jsonPath("$.[*].requestContent").value(hasItem(DEFAULT_REQUEST_CONTENT)))
            .andExpect(jsonPath("$.[*].responseContent").value(hasItem(DEFAULT_RESPONSE_CONTENT)))
            .andExpect(jsonPath("$.[*].responseCode").value(hasItem(DEFAULT_RESPONSE_CODE)));

        // Check, that the count call also returns 1
        restAuditFiwarePlatformMockMvc.perform(get("/api/audit-fiware-platforms/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(content().string("1"));
    }

    /**
     * Executes the search, and checks that the default entity is not returned
     */
    private void defaultAuditFiwarePlatformShouldNotBeFound(String filter) throws Exception {
        restAuditFiwarePlatformMockMvc.perform(get("/api/audit-fiware-platforms?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());

        // Check, that the count call also returns 0
        restAuditFiwarePlatformMockMvc.perform(get("/api/audit-fiware-platforms/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(content().string("0"));
    }


    @Test
    @Transactional
    public void getNonExistingAuditFiwarePlatform() throws Exception {
        // Get the auditFiwarePlatform
        restAuditFiwarePlatformMockMvc.perform(get("/api/audit-fiware-platforms/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateAuditFiwarePlatform() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        int databaseSizeBeforeUpdate = auditFiwarePlatformRepository.findAll().size();

        // Update the auditFiwarePlatform
        AuditFiwarePlatform updatedAuditFiwarePlatform = auditFiwarePlatformRepository.findById(auditFiwarePlatform.getId()).get();
        // Disconnect from session so that the updates on updatedAuditFiwarePlatform are not directly saved in db
        em.detach(updatedAuditFiwarePlatform);
        updatedAuditFiwarePlatform
            .date(UPDATED_DATE)
            .type(UPDATED_TYPE)
            .requestUrl(UPDATED_REQUEST_URL)
            .requestContent(UPDATED_REQUEST_CONTENT)
            .responseContent(UPDATED_RESPONSE_CONTENT)
            .responseCode(UPDATED_RESPONSE_CODE);
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(updatedAuditFiwarePlatform);

        restAuditFiwarePlatformMockMvc.perform(put("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isOk());

        // Validate the AuditFiwarePlatform in the database
        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeUpdate);
        AuditFiwarePlatform testAuditFiwarePlatform = auditFiwarePlatformList.get(auditFiwarePlatformList.size() - 1);
        assertThat(testAuditFiwarePlatform.getDate()).isEqualTo(UPDATED_DATE);
        assertThat(testAuditFiwarePlatform.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testAuditFiwarePlatform.getRequestUrl()).isEqualTo(UPDATED_REQUEST_URL);
        assertThat(testAuditFiwarePlatform.getRequestContent()).isEqualTo(UPDATED_REQUEST_CONTENT);
        assertThat(testAuditFiwarePlatform.getResponseContent()).isEqualTo(UPDATED_RESPONSE_CONTENT);
        assertThat(testAuditFiwarePlatform.getResponseCode()).isEqualTo(UPDATED_RESPONSE_CODE);
    }

    @Test
    @Transactional
    public void updateNonExistingAuditFiwarePlatform() throws Exception {
        int databaseSizeBeforeUpdate = auditFiwarePlatformRepository.findAll().size();

        // Create the AuditFiwarePlatform
        AuditFiwarePlatformDTO auditFiwarePlatformDTO = auditFiwarePlatformMapper.toDto(auditFiwarePlatform);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAuditFiwarePlatformMockMvc.perform(put("/api/audit-fiware-platforms")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditFiwarePlatformDTO)))
            .andExpect(status().isBadRequest());

        // Validate the AuditFiwarePlatform in the database
        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteAuditFiwarePlatform() throws Exception {
        // Initialize the database
        auditFiwarePlatformRepository.saveAndFlush(auditFiwarePlatform);

        int databaseSizeBeforeDelete = auditFiwarePlatformRepository.findAll().size();

        // Delete the auditFiwarePlatform
        restAuditFiwarePlatformMockMvc.perform(delete("/api/audit-fiware-platforms/{id}", auditFiwarePlatform.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<AuditFiwarePlatform> auditFiwarePlatformList = auditFiwarePlatformRepository.findAll();
        assertThat(auditFiwarePlatformList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(AuditFiwarePlatform.class);
        AuditFiwarePlatform auditFiwarePlatform1 = new AuditFiwarePlatform();
        auditFiwarePlatform1.setId(1L);
        AuditFiwarePlatform auditFiwarePlatform2 = new AuditFiwarePlatform();
        auditFiwarePlatform2.setId(auditFiwarePlatform1.getId());
        assertThat(auditFiwarePlatform1).isEqualTo(auditFiwarePlatform2);
        auditFiwarePlatform2.setId(2L);
        assertThat(auditFiwarePlatform1).isNotEqualTo(auditFiwarePlatform2);
        auditFiwarePlatform1.setId(null);
        assertThat(auditFiwarePlatform1).isNotEqualTo(auditFiwarePlatform2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(AuditFiwarePlatformDTO.class);
        AuditFiwarePlatformDTO auditFiwarePlatformDTO1 = new AuditFiwarePlatformDTO();
        auditFiwarePlatformDTO1.setId(1L);
        AuditFiwarePlatformDTO auditFiwarePlatformDTO2 = new AuditFiwarePlatformDTO();
        assertThat(auditFiwarePlatformDTO1).isNotEqualTo(auditFiwarePlatformDTO2);
        auditFiwarePlatformDTO2.setId(auditFiwarePlatformDTO1.getId());
        assertThat(auditFiwarePlatformDTO1).isEqualTo(auditFiwarePlatformDTO2);
        auditFiwarePlatformDTO2.setId(2L);
        assertThat(auditFiwarePlatformDTO1).isNotEqualTo(auditFiwarePlatformDTO2);
        auditFiwarePlatformDTO1.setId(null);
        assertThat(auditFiwarePlatformDTO1).isNotEqualTo(auditFiwarePlatformDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(auditFiwarePlatformMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(auditFiwarePlatformMapper.fromId(null)).isNull();
    }
}

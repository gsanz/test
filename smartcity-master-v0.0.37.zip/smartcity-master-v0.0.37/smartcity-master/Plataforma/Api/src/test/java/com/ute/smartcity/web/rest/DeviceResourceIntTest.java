package com.ute.smartcity.web.rest;

import com.ute.smartcity.SmartcityApp;
import com.ute.smartcity.domain.*;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.repository.FieldsRepository;
import com.ute.smartcity.repository.ProviderRepository;
import com.ute.smartcity.repository.UsuarioRepository;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.DeviceTypeMapper;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.web.rest.errors.ExceptionTranslator;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.*;

import static com.ute.smartcity.web.rest.TestUtil.createFormattingConversionService;
import static com.ute.smartcity.web.rest.TestUtil.sameInstant;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the DeviceResource REST controller.
 *
 * @see DeviceResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmartcityApp.class)
public class DeviceResourceIntTest {

    private static final String DEFAULT_REFERENCE = "AAAAAAAAAA";
    private static final String UPDATED_REFERENCE = "BBBBBBBBBB";

    private static final String DEFAULT_STATE = "AAAAAAAAAA";
    private static final String UPDATED_STATE = "BBBBBBBBBB";

    private static final String DEFAULT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_LOCATION = "AAAAAAAAAA";
    private static final String UPDATED_LOCATION = "BBBBBBBBBB";

    private static final String DEFAULT_LONGITUDE = "-0.261155";
    private static final String UPDATED_LONGITUDE = "-1.257179";

    private static final String DEFAULT_LATITUDE = "89.263011";
    private static final String UPDATED_LATITUDE = "39.967018";

    private static final String DEFAULT_OBSERVACIONES = "AAAAAAAAAA";
    private static final String UPDATED_OBSERVACIONES = "BBBBBBBBBB";

    private static final byte[] DEFAULT_IMAGE = TestUtil.createByteArray(1, "0");
    private static final byte[] UPDATED_IMAGE = TestUtil.createByteArray(1, "1");

    private static final String DEFAULT_IMAGE_CONTENT_TYPE = "image/jpg";
    private static final String UPDATED_IMAGE_CONTENT_TYPE = "image/png";

    private static final String DEFAULT_EMAIL = "admin@test.com";
    private static final String UPDATED_EMAIL = "user@test.com";

    private static final ZonedDateTime DEFAULT_CREATE_AT = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_CREATE_AT = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_DELETE_AT = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_DELETE_AT = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_UPDATE_AT = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_UPDATE_AT = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_TYPE ="TYPE" ;

    @Autowired
    private DeviceRepository deviceRepository;

    @Autowired
    private DeviceMapper deviceMapper;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private DeviceQueryService deviceQueryService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    @Autowired
    private FieldsRepository fieldsRepository;

    @Autowired
    private DeviceObservationsService deviceObservationsService;

    @Autowired
    private FieldsService fieldsService;

    @Autowired
    private HistoricalDeviceDataService historicalDeviceDataService;

    @Autowired
    private UserService userService;

    @Autowired
    private UpdateDeviceDataService updateDeviceDataService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private DeviceTypeService deviceTypeService;

    @Autowired
    private ProviderService providerService;

    @Autowired
    private ProviderRepository providerRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    private DeviceTypeMapper deviceTypeMapper;

    @Mock
    private SmartCityPlatformService smartCityPlatformService;

    private MockMvc restDeviceMockMvc;

    private Device device;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);

        //crear mock de smartCityPlatformService
  //      when(smartCityPlatformService.updateDevice(any(DeviceDTO.class))).thenReturn(null);
    //    doNothing().when(smartCityPlatformService).updateDevice(any(DeviceDTO.class));
        final DeviceResource deviceResource = new DeviceResource(deviceService, deviceMapper, deviceTypeService, deviceTypeMapper, smartCityPlatformService);
        final DeviceResourceExt deviceResourceExt = new DeviceResourceExt(deviceService, deviceQueryService, deviceObservationsService, fieldsService, historicalDeviceDataService, userService, usuarioService, updateDeviceDataService, smartCityPlatformService, deviceMapper, deviceTypeService, providerService);

        this.restDeviceMockMvc = MockMvcBuilders.standaloneSetup(deviceResource, deviceResourceExt)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Device createEntity(EntityManager em) {
        // Add required entity
        DeviceType type = new DeviceType();
        type.setName("default");
        type.setReference("name");
        type.setType("type");
        em.flush();
        em.persist(type);
        Device device = new Device()
            .reference(DEFAULT_REFERENCE)
            .state(DEFAULT_STATE)
            .name(DEFAULT_NAME)
            .location(DEFAULT_LOCATION)
            .longitude(DEFAULT_LONGITUDE)
            .latitude(DEFAULT_LATITUDE)
            .observaciones(DEFAULT_OBSERVACIONES)
            .createAt(DEFAULT_CREATE_AT)
            .deleteAt(DEFAULT_DELETE_AT)
            .updateAt(DEFAULT_UPDATE_AT)
            .deviceType(type);
        return device;
    }
    public Provider createProvider(String name) {
        Provider provider = new Provider()
            .name(name)
            .address("BABABBAA")
            .mobile("657588846")
            .email("fake@fakeprovider1.com")
            .image(TestUtil.createByteArray(1, "0"))
            .imageContentType("image/jpg")
            .createAt(DEFAULT_CREATE_AT)
            .deleteAt(DEFAULT_DELETE_AT)
            .updateAt(DEFAULT_UPDATE_AT);
        return provider;
    }

    public Usuario createUsuarioProvider(Provider provider) {
        User user = new User();
        user.setLogin(provider.getName());
        user.setPassword(RandomStringUtils.random(60));
        user.setActivated(true);
        user.setEmail(RandomStringUtils.randomAlphabetic(5) + DEFAULT_EMAIL);
        user.setFirstName(provider.getName());
        user.setLastName("");
        user.setImageUrl("http://placehold.it/50x50");
        user.setLangKey("en");
        Set<Authority> authorities = new HashSet<>();
        Authority authority = new Authority();
        authority.setName(AuthoritiesConstants.PROVIDER);
        authorities.add(authority);
        user.setAuthorities(authorities);

        Usuario usuario = new Usuario();
        usuario.setUser(user);
        usuario.setPhone("675867654");
        usuario.setDoubleFactorAuthentication(false);
        usuario.setProvider(provider);
        usuario.setImage(DEFAULT_IMAGE);
        usuario.setImageContentType(DEFAULT_IMAGE_CONTENT_TYPE);
        usuario.lastPasswordDate(ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC));

        return usuario;
    }

    @Before
    public void initTest() {
        fieldsRepository.deleteAll();
        deviceRepository.deleteAll();
        device = createEntity(em);
    }

    @Test
    @Transactional
    public void createDevice() throws Exception {
        int databaseSizeBeforeCreate = deviceRepository.findAll().size();

        // Create the Device
        DeviceDTO deviceDTO = deviceMapper.toDto(device);
        restDeviceMockMvc.perform(post("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isCreated());

        // Validate the Device in the database
        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeCreate + 1);
        Device testDevice = deviceList.get(0);
        assertThat(testDevice.getReference()).isEqualTo(DEFAULT_REFERENCE);
        assertThat(testDevice.getState()).isEqualTo(DEFAULT_STATE);
        assertThat(testDevice.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testDevice.getLocation()).isEqualTo(DEFAULT_LOCATION);
        assertThat(testDevice.getLongitude()).isEqualTo(DEFAULT_LONGITUDE);
        assertThat(testDevice.getLatitude()).isEqualTo(DEFAULT_LATITUDE);
        assertThat(testDevice.getObservaciones()).isEqualTo(DEFAULT_OBSERVACIONES);
        assertThat(testDevice.getCreateAt()).isEqualTo(DEFAULT_CREATE_AT);
        assertThat(testDevice.getDeleteAt()).isEqualTo(DEFAULT_DELETE_AT);
        assertThat(testDevice.getUpdateAt()).isEqualTo(DEFAULT_UPDATE_AT);
    }

    @Test
    @Transactional
    public void createDeviceWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = deviceRepository.findAll().size();

        // Create the Device with an existing ID
        device.setId(1L);
        DeviceDTO deviceDTO = deviceMapper.toDto(device);

        // An entity with an existing ID cannot be created, so this API call must fail
        restDeviceMockMvc.perform(post("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Device in the database
        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkReferenceIsRequired() throws Exception {
        int databaseSizeBeforeTest = deviceRepository.findAll().size();
        // set the field null
        device.setReference(null);

        // Create the Device, which fails.
        DeviceDTO deviceDTO = deviceMapper.toDto(device);

        restDeviceMockMvc.perform(post("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isBadRequest());

        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = deviceRepository.findAll().size();
        // set the field null
        device.setName(null);

        // Create the Device, which fails.
        DeviceDTO deviceDTO = deviceMapper.toDto(device);

        restDeviceMockMvc.perform(post("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isBadRequest());

        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkLongitudeIsRequired() throws Exception {
        int databaseSizeBeforeTest = deviceRepository.findAll().size();
        // set the field null
        device.setLongitude(null);

        // Create the Device, which fails.
        DeviceDTO deviceDTO = deviceMapper.toDto(device);

        restDeviceMockMvc.perform(post("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isBadRequest());

        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkLatitudeIsRequired() throws Exception {
        int databaseSizeBeforeTest = deviceRepository.findAll().size();
        // set the field null
        device.setLatitude(null);

        // Create the Device, which fails.
        DeviceDTO deviceDTO = deviceMapper.toDto(device);

        restDeviceMockMvc.perform(post("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isBadRequest());

        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeTest);
    }

    private void setLoginToAdmin() {
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.ADMIN));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "token",authorities));
        SecurityContextHolder.setContext(securityContext);
    }

    @Test
    @Transactional
    public void getAllDevices() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();
        // Get all the deviceList
        restDeviceMockMvc.perform(get("/api/devices?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(device.getId().intValue())))
            .andExpect(jsonPath("$.[*].reference").value(hasItem(DEFAULT_REFERENCE.toString())))
            .andExpect(jsonPath("$.[*].state").value(hasItem(DEFAULT_STATE.toString())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].location").value(hasItem(DEFAULT_LOCATION.toString())))
            .andExpect(jsonPath("$.[*].longitude").value(hasItem(DEFAULT_LONGITUDE.toString())))
            .andExpect(jsonPath("$.[*].latitude").value(hasItem(DEFAULT_LATITUDE.toString())))
            .andExpect(jsonPath("$.[*].observaciones").value(hasItem(DEFAULT_OBSERVACIONES.toString())))
            .andExpect(jsonPath("$.[*].createAt").value(hasItem(sameInstant(DEFAULT_CREATE_AT))))
            .andExpect(jsonPath("$.[*].deleteAt").value(hasItem(sameInstant(DEFAULT_DELETE_AT))))
            .andExpect(jsonPath("$.[*].updateAt").value(hasItem(sameInstant(DEFAULT_UPDATE_AT))));
    }

    @Test
    @Transactional
    public void getDevice() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();
        // Get the device
        restDeviceMockMvc.perform(get("/api/devices/{id}", device.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(device.getId().intValue()))
            .andExpect(jsonPath("$.reference").value(DEFAULT_REFERENCE.toString()))
            .andExpect(jsonPath("$.state").value(DEFAULT_STATE.toString()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.location").value(DEFAULT_LOCATION.toString()))
            .andExpect(jsonPath("$.longitude").value(DEFAULT_LONGITUDE.toString()))
            .andExpect(jsonPath("$.latitude").value(DEFAULT_LATITUDE.toString()))
            .andExpect(jsonPath("$.observaciones").value(DEFAULT_OBSERVACIONES.toString()))
            .andExpect(jsonPath("$.createAt").value(sameInstant(DEFAULT_CREATE_AT)))
            .andExpect(jsonPath("$.deleteAt").value(sameInstant(DEFAULT_DELETE_AT)))
            .andExpect(jsonPath("$.updateAt").value(sameInstant(DEFAULT_UPDATE_AT)));
    }

    @Test
    @Transactional
    public void getAllDevicesByReferenceIsEqualToSomething() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where reference equals to DEFAULT_REFERENCE
        defaultDeviceShouldBeFound("reference.equals=" + DEFAULT_REFERENCE);

        // Get all the deviceList where reference equals to UPDATED_REFERENCE
        defaultDeviceShouldNotBeFound("reference.equals=" + UPDATED_REFERENCE);
    }

    @Test
    @Transactional
    public void getAllDevicesByReferenceIsInShouldWork() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where reference in DEFAULT_REFERENCE or UPDATED_REFERENCE
        defaultDeviceShouldBeFound("reference.in=" + DEFAULT_REFERENCE + "," + UPDATED_REFERENCE);

        // Get all the deviceList where reference equals to UPDATED_REFERENCE
        defaultDeviceShouldNotBeFound("reference.in=" + UPDATED_REFERENCE);
    }

    @Test
    @Transactional
    public void getAllDevicesByReferenceIsNullOrNotNull() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where reference is not null
        defaultDeviceShouldBeFound("reference.specified=true");

        // Get all the deviceList where reference is null
        defaultDeviceShouldNotBeFound("reference.specified=false");
    }

    @Test
    @Transactional
    public void getAllDevicesByStateIsEqualToSomething() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where state equals to DEFAULT_STATE
        defaultDeviceShouldBeFound("state.equals=" + DEFAULT_STATE);

        // Get all the deviceList where state equals to UPDATED_STATE
        defaultDeviceShouldNotBeFound("state.equals=" + UPDATED_STATE);
    }

    @Test
    @Transactional
    public void getAllDevicesByStateIsInShouldWork() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where state in DEFAULT_STATE or UPDATED_STATE
        defaultDeviceShouldBeFound("state.in=" + DEFAULT_STATE + "," + UPDATED_STATE);

        // Get all the deviceList where state equals to UPDATED_STATE
        defaultDeviceShouldNotBeFound("state.in=" + UPDATED_STATE);
    }

    @Test
    @Transactional
    public void getAllDevicesByStateIsNullOrNotNull() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where state is not null
        defaultDeviceShouldBeFound("state.specified=true");

        // Get all the deviceList where state is null
        defaultDeviceShouldNotBeFound("state.specified=false");
    }

    @Test
    @Transactional
    public void getAllDevicesByNameIsEqualToSomething() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where name equals to DEFAULT_NAME
        defaultDeviceShouldBeFound("name.equals=" + DEFAULT_NAME);

        // Get all the deviceList where name equals to UPDATED_NAME
        defaultDeviceShouldNotBeFound("name.equals=" + UPDATED_NAME);
    }

    @Test
    @Transactional
    public void getAllDevicesByNameIsInShouldWork() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where name in DEFAULT_NAME or UPDATED_NAME
        defaultDeviceShouldBeFound("name.in=" + DEFAULT_NAME + "," + UPDATED_NAME);

        // Get all the deviceList where name equals to UPDATED_NAME
        defaultDeviceShouldNotBeFound("name.in=" + UPDATED_NAME);
    }

    @Test
    @Transactional
    public void getAllDevicesByNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where name is not null
        defaultDeviceShouldBeFound("name.specified=true");

        // Get all the deviceList where name is null
        defaultDeviceShouldNotBeFound("name.specified=false");
    }

    @Test
    @Transactional
    public void getAllDevicesByLocationIsEqualToSomething() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where location equals to DEFAULT_LOCATION
        defaultDeviceShouldBeFound("location.equals=" + DEFAULT_LOCATION);

        // Get all the deviceList where location equals to UPDATED_LOCATION
        defaultDeviceShouldNotBeFound("location.equals=" + UPDATED_LOCATION);
    }

    @Test
    @Transactional
    public void getAllDevicesByLocationIsInShouldWork() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where location in DEFAULT_LOCATION or UPDATED_LOCATION
        defaultDeviceShouldBeFound("location.in=" + DEFAULT_LOCATION + "," + UPDATED_LOCATION);

        // Get all the deviceList where location equals to UPDATED_LOCATION
        defaultDeviceShouldNotBeFound("location.in=" + UPDATED_LOCATION);
    }

    @Test
    @Transactional
    public void getAllDevicesByLocationIsNullOrNotNull() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where location is not null
        defaultDeviceShouldBeFound("location.specified=true");

        // Get all the deviceList where location is null
        defaultDeviceShouldNotBeFound("location.specified=false");
    }

    @Test
    @Transactional
    public void getAllDevicesByLongitudeIsEqualToSomething() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where longitude equals to DEFAULT_LONGITUDE
        defaultDeviceShouldBeFound("longitude.equals=" + DEFAULT_LONGITUDE);

        // Get all the deviceList where longitude equals to UPDATED_LONGITUDE
        defaultDeviceShouldNotBeFound("longitude.equals=" + UPDATED_LONGITUDE);
    }

    @Test
    @Transactional
    public void getAllDevicesByLongitudeIsInShouldWork() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where longitude in DEFAULT_LONGITUDE or UPDATED_LONGITUDE
        defaultDeviceShouldBeFound("longitude.in=" + DEFAULT_LONGITUDE + "," + UPDATED_LONGITUDE);

        // Get all the deviceList where longitude equals to UPDATED_LONGITUDE
        defaultDeviceShouldNotBeFound("longitude.in=" + UPDATED_LONGITUDE);
    }

    @Test
    @Transactional
    public void getAllDevicesByLongitudeIsNullOrNotNull() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where longitude is not null
        defaultDeviceShouldBeFound("longitude.specified=true");

        // Get all the deviceList where longitude is null
        defaultDeviceShouldNotBeFound("longitude.specified=false");
    }

    @Test
    @Transactional
    public void getAllDevicesByLatitudeIsEqualToSomething() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where latitude equals to DEFAULT_LATITUDE
        defaultDeviceShouldBeFound("latitude.equals=" + DEFAULT_LATITUDE);

        // Get all the deviceList where latitude equals to UPDATED_LATITUDE
        defaultDeviceShouldNotBeFound("latitude.equals=" + UPDATED_LATITUDE);
    }

    @Test
    @Transactional
    public void getAllDevicesByLatitudeIsInShouldWork() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where latitude in DEFAULT_LATITUDE or UPDATED_LATITUDE
        defaultDeviceShouldBeFound("latitude.in=" + DEFAULT_LATITUDE + "," + UPDATED_LATITUDE);

        // Get all the deviceList where latitude equals to UPDATED_LATITUDE
        defaultDeviceShouldNotBeFound("latitude.in=" + UPDATED_LATITUDE);
    }

    @Test
    @Transactional
    public void getAllDevicesByLatitudeIsNullOrNotNull() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        setLoginToAdmin();

        // Get all the deviceList where latitude is not null
        defaultDeviceShouldBeFound("latitude.specified=true");

        // Get all the deviceList where latitude is null
        defaultDeviceShouldNotBeFound("latitude.specified=false");
    }

    @Test
    @Transactional
    public void getAllDevicesByAlertIsEqualToSomething() throws Exception {
        // Initialize the database
        Alert alert = AlertResourceIntTest.createEntity(em);
        em.persist(alert);
        em.flush();
        device.addAlert(alert);
        deviceRepository.saveAndFlush(device);
        Long alertId = alert.getId();

        setLoginToAdmin();

        // Get all the deviceList where alert equals to alertId
        defaultDeviceShouldBeFound("alertId.equals=" + alertId);

        // Get all the deviceList where alert equals to alertId + 1
        defaultDeviceShouldNotBeFound("alertId.equals=" + (alertId + 1));
    }

    @Test
    @Transactional
    public void getAllDevicesByFieldsIsEqualToSomething() throws Exception {
        // Initialize the database
        Fields fields = FieldsResourceIntTest.createEntity(em);
        em.persist(fields);
        em.flush();
        fieldsRepository.saveAndFlush(fields);
        device.addFields(fields);
        deviceRepository.saveAndFlush(device);
        Long fieldsId = fields.getId();

        setLoginToAdmin();

        // Get all the deviceList where fields equals to fieldsId
        defaultDeviceShouldBeFound("fieldsId.equals=" + fieldsId);

        // Get all the deviceList where fields equals to fieldsId + 1
        defaultDeviceShouldNotBeFound("fieldsId.equals=" + (fieldsId + 1));
    }

    @Test
    @Transactional
    public void getAllDevicesByDeviceTypeIsEqualToSomething() throws Exception {
        // Initialize the database
        DeviceType deviceType = DeviceTypeResourceIntTest.createEntity(em);
        em.persist(deviceType);
        em.flush();
        device.setDeviceType(deviceType);
        deviceRepository.saveAndFlush(device);
        Long deviceTypeId = deviceType.getId();

        setLoginToAdmin();

        // Get all the deviceList where deviceType equals to deviceTypeId
        defaultDeviceShouldBeFound("deviceTypeId.equals=" + deviceTypeId);

        // Get all the deviceList where deviceType equals to deviceTypeId + 1
        defaultDeviceShouldNotBeFound("deviceTypeId.equals=" + (deviceTypeId + 1));
    }


    @Test
    @Transactional
    public void getAllDevicesByZoneIsEqualToSomething() throws Exception {
        // Initialize the database
        Zone zone = ZoneResourceIntTest.createEntity(em);
        em.persist(zone);
        em.flush();
        device.setZone(zone);
        deviceRepository.saveAndFlush(device);
        Long zoneId = zone.getId();

        setLoginToAdmin();

        // Get all the deviceList where zone equals to zoneId
        defaultDeviceShouldBeFound("zoneId.equals=" + zoneId);

        // Get all the deviceList where zone equals to zoneId + 1
        defaultDeviceShouldNotBeFound("zoneId.equals=" + (zoneId + 1));
    }


    @Test
    @Transactional
    public void getAllDevicesByProviderIsEqualToSomething() throws Exception {
        // Initialize the database
        Provider provider = ProviderResourceIntTest.createEntity(em);
        em.persist(provider);
        em.flush();
        device.setProvider(provider);
        deviceRepository.saveAndFlush(device);
        Long providerId = provider.getId();

        setLoginToAdmin();

        // Get all the deviceList where provider equals to providerId
        defaultDeviceShouldBeFound("providerId.equals=" + providerId);

        // Get all the deviceList where provider equals to providerId + 1
        defaultDeviceShouldNotBeFound("providerId.equals=" + (providerId + 1));
    }


    @Test
    @Transactional
    public void getAllDevicesByProtocolIsEqualToSomething() throws Exception {
        // Initialize the database
        Protocol protocol = ProtocolResourceIntTest.createEntity(em);
        em.persist(protocol);
        em.flush();
        device.setProtocol(protocol);
        deviceRepository.saveAndFlush(device);
        Long protocolId = protocol.getId();

        setLoginToAdmin();

        // Get all the deviceList where protocol equals to protocolId
        defaultDeviceShouldBeFound("protocolId.equals=" + protocolId);

        // Get all the deviceList where protocol equals to protocolId + 1
        defaultDeviceShouldNotBeFound("protocolId.equals=" + (protocolId + 1));
    }

    @Test
    @Transactional
    public void getAllDevicesByRuleIsEqualToSomething() throws Exception {
        // Initialize the database
        Rule rule = RuleResourceIntTest.createEntity(em);
        em.persist(rule);
        em.flush();
        device.addRule(rule);
        deviceRepository.saveAndFlush(device);
        Long ruleId = rule.getId();

        setLoginToAdmin();

        // Get all the deviceList where rule equals to ruleId
        defaultDeviceShouldBeFound("ruleId.equals=" + ruleId);

        // Get all the deviceList where rule equals to ruleId + 1
        defaultDeviceShouldNotBeFound("ruleId.equals=" + (ruleId + 1));
    }

    /**
     * Executes the search, and checks that the default entity is returned
     */
    private void defaultDeviceShouldBeFound(String filter) throws Exception {
        restDeviceMockMvc.perform(get("/api/devices?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            //.andExpect(jsonPath("$.[*].id").value(hasItem(device.getId().intValue())))
            .andExpect(jsonPath("$.[*].reference").value(hasItem(DEFAULT_REFERENCE)))
            .andExpect(jsonPath("$.[*].state").value(hasItem(DEFAULT_STATE)))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME)))
            .andExpect(jsonPath("$.[*].location").value(hasItem(DEFAULT_LOCATION)))
            .andExpect(jsonPath("$.[*].longitude").value(hasItem(DEFAULT_LONGITUDE)))
            .andExpect(jsonPath("$.[*].latitude").value(hasItem(DEFAULT_LATITUDE)))
            .andExpect(jsonPath("$.[*].observaciones").value(hasItem(DEFAULT_OBSERVACIONES.toString())))
            .andExpect(jsonPath("$.[*].createAt").value(hasItem(sameInstant(DEFAULT_CREATE_AT))))
            .andExpect(jsonPath("$.[*].deleteAt").value(hasItem(sameInstant(DEFAULT_DELETE_AT))))
            .andExpect(jsonPath("$.[*].updateAt").value(hasItem(sameInstant(DEFAULT_UPDATE_AT))));

        // Check, that the count call also returns 1
        restDeviceMockMvc.perform(get("/api/devices/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(content().string("1"));
    }

    /**
     * Executes the search, and checks that the default entity is not returned
     */
    private void defaultDeviceShouldNotBeFound(String filter) throws Exception {
        restDeviceMockMvc.perform(get("/api/devices?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());

        // Check, that the count call also returns 0
        restDeviceMockMvc.perform(get("/api/devices/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(content().string("0"));
    }


    @Test
    @Transactional
    public void getNonExistingDevice() throws Exception {
        setLoginToAdmin();
        // Get the device
        restDeviceMockMvc.perform(get("/api/devices/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void Should_return_bad_request_when_update_forbidden_fields_in_updateDevice() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        int databaseSizeBeforeUpdate = deviceRepository.findAll().size();

        // Update the device
        Device updatedDevice = deviceRepository.findById(device.getId()).get();
        // Disconnect from session so that the updates on updatedDevice are not directly saved in db
        em.detach(updatedDevice);
        updatedDevice
            .reference(UPDATED_REFERENCE);
        DeviceDTO deviceDTO = deviceMapper.toDto(updatedDevice);

        restDeviceMockMvc.perform(put("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isBadRequest());

    }

    @Test
    @Transactional
    public void updateDevice() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        int databaseSizeBeforeUpdate = deviceRepository.findAll().size();

        // Update the device
        Device updatedDevice = deviceRepository.findById(device.getId()).get();
        // Disconnect from session so that the updates on updatedDevice are not directly saved in db
        em.detach(updatedDevice);
        updatedDevice
            .state(UPDATED_STATE)
            .name(UPDATED_NAME)
            .location(UPDATED_LOCATION)
            .longitude(UPDATED_LONGITUDE)
            .latitude(UPDATED_LATITUDE)
            .observaciones(UPDATED_OBSERVACIONES)
            .createAt(UPDATED_CREATE_AT)
            .deleteAt(UPDATED_DELETE_AT)
            .updateAt(UPDATED_UPDATE_AT);
        DeviceDTO deviceDTO = deviceMapper.toDto(updatedDevice);

        restDeviceMockMvc.perform(put("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isOk());

        // Validate the Device in the database
        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeUpdate);
        Device testDevice = deviceList.get(deviceList.size() - 1);
        assertThat(testDevice.getReference()).isEqualTo(DEFAULT_REFERENCE);
        assertThat(testDevice.getState()).isEqualTo(UPDATED_STATE);
        assertThat(testDevice.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testDevice.getLocation()).isEqualTo(UPDATED_LOCATION);
        assertThat(testDevice.getLongitude()).isEqualTo(UPDATED_LONGITUDE);
        assertThat(testDevice.getLatitude()).isEqualTo(UPDATED_LATITUDE);
        assertThat(testDevice.getObservaciones()).isEqualTo(UPDATED_OBSERVACIONES);
        assertThat(testDevice.getCreateAt()).isEqualTo(UPDATED_CREATE_AT);
        assertThat(testDevice.getDeleteAt()).isEqualTo(UPDATED_DELETE_AT);
    }
    @Test
    @Transactional
    public void updateNonExistingDevice() throws Exception {
        int databaseSizeBeforeUpdate = deviceRepository.findAll().size();

        // Create the Device
        DeviceDTO deviceDTO = deviceMapper.toDto(device);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restDeviceMockMvc.perform(put("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Device in the database
        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteDevice() throws Exception {
        // Initialize the database
        deviceRepository.saveAndFlush(device);

        int databaseSizeBeforeDelete = deviceRepository.findAll().size();

        // Delete the device
        restDeviceMockMvc.perform(delete("/api/devices/{id}", device.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Device.class);
        Device device1 = new Device();
        device1.setId(1L);
        Device device2 = new Device();
        device2.setId(device1.getId());
        assertThat(device1).isEqualTo(device2);
        device2.setId(2L);
        assertThat(device1).isNotEqualTo(device2);
        device1.setId(null);
        assertThat(device1).isNotEqualTo(device2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(DeviceDTO.class);
        DeviceDTO deviceDTO1 = new DeviceDTO();
        deviceDTO1.setId(1L);
        DeviceDTO deviceDTO2 = new DeviceDTO();
        assertThat(deviceDTO1).isNotEqualTo(deviceDTO2);
        deviceDTO2.setId(deviceDTO1.getId());
        assertThat(deviceDTO1).isEqualTo(deviceDTO2);
        deviceDTO2.setId(2L);
        assertThat(deviceDTO1).isNotEqualTo(deviceDTO2);
        deviceDTO1.setId(null);
        assertThat(deviceDTO1).isNotEqualTo(deviceDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(deviceMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(deviceMapper.fromId(null)).isNull();
    }

    @Test
    @Transactional
    public void updateDeviceAsProviderShouldBeForbidden() throws Exception {

        // Initialize user as provider
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.PROVIDER));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("provider", "token",authorities));
        SecurityContextHolder.setContext(securityContext);


        // Initialize the database
        deviceRepository.saveAndFlush(device);

        // Update the device
        Device updatedDevice = deviceRepository.findById(device.getId()).get();
        // Disconnect from session so that the updates on updatedDevice are not directly saved in db
        em.detach(updatedDevice);
        updatedDevice
            .state(UPDATED_STATE)
            .name(UPDATED_NAME)
            .location(UPDATED_LOCATION)
            .longitude(UPDATED_LONGITUDE)
            .latitude(UPDATED_LATITUDE)
            .observaciones(UPDATED_OBSERVACIONES)
            .createAt(UPDATED_CREATE_AT)
            .deleteAt(UPDATED_DELETE_AT)
            .updateAt(UPDATED_UPDATE_AT);
        DeviceDTO deviceDTO = deviceMapper.toDto(updatedDevice);
        List<Device> deviceList3 = deviceRepository.findAll();
        restDeviceMockMvc.perform(put("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isForbidden());

        // Validate the that the database is de same
        List<Device> deviceList = deviceRepository.findAll();
        Device testDevice = deviceList.get(deviceList.size() - 1);
        assertThat(testDevice.getReference()).isEqualTo(DEFAULT_REFERENCE);
        assertThat(testDevice.getState()).isEqualTo(DEFAULT_STATE);
        assertThat(testDevice.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testDevice.getLocation()).isEqualTo(DEFAULT_LOCATION);
        assertThat(testDevice.getLongitude()).isEqualTo(DEFAULT_LONGITUDE);
        assertThat(testDevice.getLatitude()).isEqualTo(DEFAULT_LATITUDE);
        assertThat(testDevice.getObservaciones()).isEqualTo(DEFAULT_OBSERVACIONES);
        assertThat(testDevice.getCreateAt()).isEqualTo(DEFAULT_CREATE_AT);
        assertThat(testDevice.getDeleteAt()).isEqualTo(DEFAULT_DELETE_AT);
        assertThat(testDevice.getUpdateAt()).isEqualTo(DEFAULT_UPDATE_AT);
    }

    @Test
    @Transactional
    public void deleteDeviceAsProviderShouldBeForbidden() throws Exception {

        // Initialize user as provider
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.PROVIDER));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("provider", "token",authorities));
        SecurityContextHolder.setContext(securityContext);

        // Initialize the database
        deviceRepository.saveAndFlush(device);

        int databaseSizeBeforeDelete = deviceRepository.findAll().size();

        // Delete the device
        restDeviceMockMvc.perform(delete("/api/devices/{id}", device.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isForbidden());

        // Validate the database is the same
        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(databaseSizeBeforeDelete);
    }

    @Test
    @Transactional
    public void createDeviceAsProviderShouldBeForbidden() throws Exception {
        // Initialize user as provider
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.PROVIDER));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("provider", "token",authorities));
        SecurityContextHolder.setContext(securityContext);

        // Create the Device
        DeviceDTO deviceDTO = deviceMapper.toDto(device);
        restDeviceMockMvc.perform(post("/api/devices")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(deviceDTO)))
            .andExpect(status().isForbidden());

        // Validate the database is the same
        List<Device> deviceList = deviceRepository.findAll();
        assertThat(deviceList).hasSize(0);
    }


    @Ignore
    @Test
    @Transactional
    public void updateOwnDeviceDataAsProviderShouldBeOk() throws Exception {

        // Initialize the first provider
        Provider provider1 = createProvider("provider1");
        providerRepository.saveAndFlush(provider1);

        //Initialize User1 and Usuario1
        Usuario usuario = createUsuarioProvider(provider1);
        usuarioRepository.saveAndFlush(usuario);

        //Initialize another provider
        Provider provider2 = createProvider("provider2");
        providerRepository.saveAndFlush(provider2);

        //Initialize User2 and Usuario2

        Usuario usuario2 = createUsuarioProvider(provider2);
        usuarioRepository.saveAndFlush(usuario2);

        // Initialize user as provider1
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities3 = new ArrayList<>();
        authorities3.add(new SimpleGrantedAuthority(AuthoritiesConstants.PROVIDER));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("provider1", "token",authorities3));
        SecurityContextHolder.setContext(securityContext);

        // Initialize the device to provider 1
        Device device = createEntity(em);
        device.setProvider(provider1);

        deviceRepository.saveAndFlush(device);

        String data = "{}";
        String reference = device.getReference();

        restDeviceMockMvc.perform(post("/api/devices/" + reference + "/data")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(data)))
            .andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void updateOtherDeviceDataAsProviderShouldBeForbidden() throws Exception {

        // Initialize the first provider
        Provider provider1 = createProvider("provider1");
        providerRepository.saveAndFlush(provider1);

        //Initialize User1 and Usuario1
        Usuario usuario = createUsuarioProvider(provider1);
        usuarioRepository.saveAndFlush(usuario);

        //Initialize another provider
        Provider provider2 = createProvider("provider2");
        providerRepository.saveAndFlush(provider2);

        //Initialize User2 and Usuario2

        Usuario usuario2 = createUsuarioProvider(provider2);
        usuarioRepository.saveAndFlush(usuario2);

        // Initialize user as provider1
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities3 = new ArrayList<>();
        authorities3.add(new SimpleGrantedAuthority(AuthoritiesConstants.PROVIDER));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("provider1", "token",authorities3));
        SecurityContextHolder.setContext(securityContext);

        // Initialize the device to provider 1
        Device device = createEntity(em);
        device.setProvider(provider2);

        deviceRepository.saveAndFlush(device);

        String data = "{}";
        String reference = device.getReference();

        restDeviceMockMvc.perform(post("/api/devices/" + reference + "/data")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(data)))
            .andExpect(status().isForbidden());

    }
}

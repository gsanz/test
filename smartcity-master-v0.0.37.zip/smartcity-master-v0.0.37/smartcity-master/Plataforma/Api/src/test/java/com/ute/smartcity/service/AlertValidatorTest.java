package com.ute.smartcity.service;

import com.ute.smartcity.SmartcityApp;
import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.Rule;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.repository.RuleRepository;
import com.ute.smartcity.service.dto.AlertDTO;
import com.ute.smartcity.service.exception.DeviceNotInRuleException;
import com.ute.smartcity.service.exception.DeviceNotPresentException;
import com.ute.smartcity.service.exception.NullDeviceReferenceInAlert;
import com.ute.smartcity.web.rest.DeviceResource;
import com.ute.smartcity.web.rest.DeviceResourceExtIntTest;
import com.ute.smartcity.web.rest.DeviceResourceIntTest;
import com.ute.smartcity.web.rest.RuleResourceIntTest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmartcityApp.class)
public class AlertValidatorTest {

    private static final String DEFAULT_REFERENCE = "AAAAAAAAAA";

    private AlertValidator validator;

    @Autowired
    private EntityManager em;
    @Autowired
    private DeviceRepository deviceRepository;
    @Autowired
    private RuleRepository ruleRepository;

    @Autowired
    private DeviceService deviceService;
    @Autowired
    private RuleService ruleService;

    @Before
    public void setup() {
        validator = new AlertValidator(deviceService,ruleService);

    }

    @Test
    public void shouldRaiseNullDeviceReferenceInAlert() {
        AlertDTO alertDTO = new AlertDTO();
        try {
            AlertDTO dto = validator.validate(alertDTO);
        } catch (NullDeviceReferenceInAlert nullDeviceReferenceInAlert) {
            assertTrue(true);
        } catch (DeviceNotPresentException e) {
            assertTrue(false);
        } catch (DeviceNotInRuleException e) {
            assertTrue(false);
        }
    }
    @Test
    public void shouldNotRaiseNullDeviceReferenceInAlert() {
        AlertDTO alertDTO = new AlertDTO();
        try {

            alertDTO.setDeviceReference(DEFAULT_REFERENCE);
            AlertDTO dto = validator.validate(alertDTO);
        } catch (NullDeviceReferenceInAlert nullDeviceReferenceInAlert) {
            assertTrue(false);
        } catch (DeviceNotPresentException e) {
            assertTrue(true);
        } catch (DeviceNotInRuleException e) {
            assertTrue(true);
        }
    }
    @Test
    public void shouldRaiseDeviceNotPresentException() {
        AlertDTO alertDTO = new AlertDTO();
        try {
            //crear dispositivo
           // DeviceResourceIntTest.createEntity(em);
            alertDTO.setDeviceReference(DEFAULT_REFERENCE);
            AlertDTO dto = validator.validate(alertDTO);
        } catch (NullDeviceReferenceInAlert nullDeviceReferenceInAlert) {
            assertTrue(false);
        } catch (DeviceNotPresentException e) {
            assertTrue(true);
        } catch (DeviceNotInRuleException e) {
            assertTrue(false);
        }
    }
    @Test
    @Transactional
    public void shouldNotRaiseDeviceNotPresentExceptionWithAnExistingDevice() {
        AlertDTO alertDTO = new AlertDTO();
        try {
            Device device = DeviceResourceIntTest.createEntity(em);
            deviceRepository.saveAndFlush(device);
            alertDTO.setDeviceId(device.getId());
            alertDTO.setDeviceReference(device.getReference());
            AlertDTO dto = validator.validate(alertDTO);
        } catch (NullDeviceReferenceInAlert nullDeviceReferenceInAlert) {
            assertTrue(false);
        } catch (DeviceNotPresentException e) {
            assertTrue(false);
        } catch (DeviceNotInRuleException e) {
            assertTrue(false);
        }
    }
    @Test
    @Transactional
    public void shouldRaiseDeviceNotInRuleExceptionWithAnExistingRule() {
        AlertDTO alertDTO = new AlertDTO();
        try {
            Device device = DeviceResourceIntTest.createEntity(em);
            Rule rule = RuleResourceIntTest.createEntity(em);
            Device device2 = DeviceResourceIntTest.createEntity(em);
            device2.setReference("BBBBBBBB");
            deviceRepository.saveAndFlush(device);
            deviceRepository.saveAndFlush(device2);
            rule.addDevice(device2);
            ruleRepository.saveAndFlush(rule);
            alertDTO.setDeviceReference(device.getReference());
            alertDTO.setRule(rule.getReference());
            AlertDTO dto = validator.validate(alertDTO);
        } catch (NullDeviceReferenceInAlert nullDeviceReferenceInAlert) {
            assertTrue(false);
        } catch (DeviceNotPresentException e) {
            assertTrue(false);
        } catch (DeviceNotInRuleException e) {
            assertTrue(true);
        }
    }
    @Test
    @Transactional
    public void shouldNotRaiseAnyException() {
        AlertDTO alertDTO = new AlertDTO();
        try {
            Device device = DeviceResourceIntTest.createEntity(em);
            Rule rule = RuleResourceIntTest.createEntity(em);
            deviceRepository.saveAndFlush(device);
            rule.addDevice(device);
            ruleRepository.saveAndFlush(rule);
            alertDTO.setDeviceReference(device.getReference());
            alertDTO.setRule(rule.getReference());
            AlertDTO dto = validator.validate(alertDTO);
        } catch (NullDeviceReferenceInAlert nullDeviceReferenceInAlert) {
            assertTrue(false);
        } catch (DeviceNotPresentException e) {
            assertTrue(false);
        } catch (DeviceNotInRuleException e) {
            assertTrue(false);
        }
        assertTrue(true);
    }
}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.SmartcityApp;
import com.ute.smartcity.domain.Device;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.repository.FieldsRepository;
import com.ute.smartcity.service.DeviceService;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.FieldsDTO;
import com.ute.smartcity.service.mapper.DeviceMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmartcityApp.class)
public class DeviceServiceImplTest {


    @Autowired
    private FieldsRepository fieldsRepository;

    @Autowired
    private DeviceRepository deviceRepository;

    @Autowired
    private DeviceMapper deviceMapper;

    private DeviceService deviceService;


    @Before
    public void setup() {
        deviceService = new DeviceServiceImpl(fieldsRepository, deviceRepository,deviceMapper);

    }
    @Transactional
    @Test
    public void should_add_device_with_own_fields() {

       //crear entidad
        DeviceDTO device = new DeviceDTO();

        device.setReference("Prueba");
        device.setName("Prueba");
        device.setLongitude("2");
        device.setLatitude("1");

        device.setDeviceTypeId(1L);

        FieldsDTO campo1 = createField("campo1");
        FieldsDTO campo2 = createField("campo2");
        //asignar campos
        device.getFields().add(campo1);
        device.getFields().add(campo2);
        //guardar entidad
        DeviceDTO deviceDTO = deviceService.save(device);


        //Recuperar la entidad en otro
        Optional<Device> optionalDevice = deviceRepository.findById(deviceDTO.getId());
        //Comporbar que tiene los campos
        assertThat(optionalDevice.isPresent());
        assertThat(optionalDevice.get().getFields().size()==2);
    }

    @Transactional
    @Test
    public void should_add_device_with_deviceType_fields() {

        //crear entidad
        DeviceDTO device = new DeviceDTO();

        device.setReference("Prueba");
        device.setName("Prueba");
        device.setLongitude("2");
        device.setLatitude("1");

        device.setDeviceTypeId(1L);


        DeviceDTO deviceDTO = deviceService.save(device);


        //Recuperar la entidad en otro
        Optional<Device> optionalDevice = deviceRepository.findById(deviceDTO.getId());
        //Comporbar que tiene los campos
        assertThat(optionalDevice.isPresent());
        assertThat(optionalDevice.get().getFields().size()>1);
    }
    private FieldsDTO createField(String campo1) {
        FieldsDTO field1 = new FieldsDTO();
        field1.setName(campo1);
        field1.setDescription("descripciopn");
        field1.setAbbreviation("ab");
        field1.setType("type");
        field1.setUnitOfmeasure("unit");
        return field1;
    }
}

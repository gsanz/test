package com.ute.smartcity.service;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.service.dto.DeviceCriteria;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.mapper.DeviceMapper;
import io.github.jhipster.service.QueryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.JoinType;
import java.util.List;

/**
 * Service for executing complex queries for Device entities in the database.
 * The main input is a {@link DeviceCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link DeviceDTO} or a {@link Page} of {@link DeviceDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class DeviceQueryService extends QueryService<Device> {

    private final Logger log = LoggerFactory.getLogger(DeviceQueryService.class);

    private final DeviceRepository deviceRepository;

    private final DeviceMapper deviceMapper;

    public DeviceQueryService(DeviceRepository deviceRepository, DeviceMapper deviceMapper) {
        this.deviceRepository = deviceRepository;
        this.deviceMapper = deviceMapper;
    }

    /**
     * Return a {@link List} of {@link DeviceDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<DeviceDTO> findByCriteria(DeviceCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<Device> specification = createSpecification(criteria);
        return deviceMapper.toDto(deviceRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link DeviceDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<DeviceDTO> findByCriteria(DeviceCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<Device> specification = createSpecification(criteria);
        return deviceRepository.findAll(specification, page)
            .map(deviceMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(DeviceCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<Device> specification = createSpecification(criteria);
        return deviceRepository.count(specification);
    }

    /**
     * Function to convert DeviceCriteria to a {@link Specification}
     */
    private Specification<Device> createSpecification(DeviceCriteria criteria) {

        Specification<Device> specification = Specification.where(null);

        if(criteria == null) {
            return specification;
        }

        if (criteria.getSearch() != null) {
            Specification<Device> busquedaPorTexto = Specification.where(buildStringSpecification(criteria.getSearch(), Device_.reference));
            busquedaPorTexto = busquedaPorTexto.or(buildStringSpecification(criteria.getSearch(), Device_.name));
            specification = specification.and(busquedaPorTexto);
        }
        if (criteria.getId() != null) {
            specification = specification.and(buildSpecification(criteria.getId(), Device_.id));
        }
        if (criteria.getReference() != null) {
            specification = specification.and(buildStringSpecification(criteria.getReference(), Device_.reference));
        }
        if (criteria.getState() != null) {
            specification = specification.and(buildStringSpecification(criteria.getState(), Device_.state));
        }
        if (criteria.getName() != null) {
            specification = specification.and(buildStringSpecification(criteria.getName(), Device_.name));
        }
        if (criteria.getLocation() != null) {
            specification = specification.and(buildStringSpecification(criteria.getLocation(), Device_.location));
        }
        if (criteria.getLongitude() != null) {
            specification = specification.and(buildStringSpecification(criteria.getLongitude(), Device_.longitude));
        }
        if (criteria.getLatitude() != null) {
            specification = specification.and(buildStringSpecification(criteria.getLatitude(), Device_.latitude));
        }
        if (criteria.getCreateAt() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getCreateAt(), Device_.createAt));
        }
        if (criteria.getDeleteAt() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getDeleteAt(), Device_.deleteAt));
        }
        if (criteria.getUpdateAt() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getUpdateAt(), Device_.updateAt));
        }
        if (criteria.getAlertId() != null) {
            specification = specification.and(buildSpecification(criteria.getAlertId(),
                root -> root.join(Device_.alerts, JoinType.LEFT).get(Alert_.id)));
        }
        if (criteria.getFieldsId() != null) {
            specification = specification.and(buildSpecification(criteria.getFieldsId(),
                root -> root.join(Device_.fields, JoinType.LEFT).get(Fields_.id)));
        }
        if (criteria.getDeviceTypeId() != null) {
            specification = specification.and(buildSpecification(criteria.getDeviceTypeId(),
                root -> root.join(Device_.deviceType, JoinType.LEFT).get(DeviceType_.id)));
        }
        if (criteria.getZoneId() != null) {
            specification = specification.and(buildSpecification(criteria.getZoneId(),
                root -> root.join(Device_.zone, JoinType.LEFT).get(Zone_.id)));
        }
        if (criteria.getProviderId() != null) {
            specification = specification.and(buildSpecification(criteria.getProviderId(),
                root -> root.join(Device_.provider, JoinType.LEFT).get(Provider_.id)));
        }
        if (criteria.getProtocolId() != null) {
            specification = specification.and(buildSpecification(criteria.getProtocolId(),
                root -> root.join(Device_.protocol, JoinType.LEFT).get(Protocol_.id)));
        }
        if (criteria.getRuleId() != null) {
            specification = specification.and(buildSpecification(criteria.getRuleId(),
                root -> root.join(Device_.rules, JoinType.LEFT).get(Rule_.id)));
        }
        return specification;

    }
}

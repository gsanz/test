package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.RuleDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Rule and its DTO RuleDTO.
 */
@Mapper(componentModel = "spring", uses = {DeviceTypeMapper.class, DeviceMapper.class})
public interface RuleMapper extends EntityMapper<RuleDTO, Rule> {

    @Mapping(source = "deviceType.id", target = "deviceTypeId")
    @Mapping(source = "deviceType.name", target = "deviceTypeName")
    RuleDTO toDto(Rule rule);

    @Mapping(target = "ruleCompareFields", ignore = true)
    @Mapping(target = "ruleActions", ignore = true)
    @Mapping(source = "deviceTypeId", target = "deviceType")
    Rule toEntity(RuleDTO ruleDTO);

    default Rule fromId(Long id) {
        if (id == null) {
            return null;
        }
        Rule rule = new Rule();
        rule.setId(id);
        return rule;
    }
}

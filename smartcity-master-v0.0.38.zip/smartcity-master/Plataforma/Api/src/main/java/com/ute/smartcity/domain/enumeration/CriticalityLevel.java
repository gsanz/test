package com.ute.smartcity.domain.enumeration;

/**
 * The CriticalityLevel enumeration.
 */
public enum CriticalityLevel {
   // SEVERE, NORMAL, LOW
   LOW, NORMAL, HIGH, CRITICAL
}

package com.ute.smartcity.service;

import com.ute.smartcity.service.dto.FieldsDTO;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Fields.
 */
public interface FieldsService {

    /**
     * Save a fields.
     *
     * @param fieldsDTO the entity to save
     * @return the persisted entity
     */
    FieldsDTO save(FieldsDTO fieldsDTO);

    /**
     * Get all the fields.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<FieldsDTO> findAll(Pageable pageable);

    /**
     * Get the "id" fields.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<FieldsDTO> findOne(Long id);

    /**
     * Delete the "id" fields.
     *
     * @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Get the "id" device id.
     *
     * @param id the id of the entity device
     * @return the entity
     */
    Optional<List<FieldsDTO>> findByDeviceId(Long id);

    Optional<List<FieldsDTO>> findByDeviceTypeId(Long id);
}

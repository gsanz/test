package com.ute.smartcity.service.exception.fiware;

import com.ute.smartcity.web.rest.DeviceResourceExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.HttpClientErrorException;

public class HttpOrionConnectionException extends Exception {
    private final Logger log = LoggerFactory.getLogger(DeviceResourceExt.class);
    public HttpOrionConnectionException(Exception e) {
        log.error("Can't connect to Orion server: " + e.getMessage());
    }
}

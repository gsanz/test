package com.ute.smartcity.domain;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Device.
 */
@Entity
@Table(name = "device")
public class Device implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "reference", nullable = false)
    private String reference;

    @Column(name = "state")
    private String state;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "location")
    private String location;

    @NotNull
    @Column(name = "longitude", nullable = false)
    private String longitude;

    @NotNull
    @Column(name = "latitude", nullable = false)
    private String latitude;

    @Lob
    @Column(name = "observaciones")
    private String observaciones;

    @Column(name = "create_at")
    private ZonedDateTime createAt;

    @Column(name = "delete_at")
    private ZonedDateTime deleteAt;

    @Column(name = "update_at")
    private ZonedDateTime updateAt;

    @OneToMany(mappedBy = "device",orphanRemoval=true)
    private Set<Alert> alerts = new HashSet<>();

    @OneToMany(mappedBy = "device",orphanRemoval=true)
    private Set<Fields> fields = new HashSet<>();
    @ManyToOne(optional = false)
    @NotNull
    @JsonIgnoreProperties("devices")
    private DeviceType deviceType;

    @ManyToOne
    @JsonIgnoreProperties("devices")
    private Zone zone;

    @ManyToOne
    @JsonIgnoreProperties("devices")
    private Provider provider;

    @ManyToOne
    @JsonIgnoreProperties("devices")
    private Protocol protocol;

    @ManyToMany(mappedBy = "devices")
    @JsonIgnore
    private Set<Rule> rules = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReference() {
        return reference;
    }

    public Device reference(String reference) {
        this.reference = reference;
        return this;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getState() {
        return state;
    }

    public Device state(String state) {
        this.state = state;
        return this;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public Device name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public Device location(String location) {
        this.location = location;
        return this;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLongitude() {
        return longitude;
    }

    public Device longitude(String longitude) {
        this.longitude = longitude;
        return this;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public Device latitude(String latitude) {
        this.latitude = latitude;
        return this;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public Device observaciones(String observaciones) {
        this.observaciones = observaciones;
        return this;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public Device createAt(ZonedDateTime createAt) {
        this.createAt = createAt;
        return this;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTime getDeleteAt() {
        return deleteAt;
    }

    public Device deleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
        return this;
    }

    public void setDeleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTime getUpdateAt() {
        return updateAt;
    }

    public Device updateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
        return this;
    }

    public void setUpdateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public Set<Alert> getAlerts() {
        return alerts;
    }

    public Device alerts(Set<Alert> alerts) {
        this.alerts = alerts;
        return this;
    }

    public Device addAlert(Alert alert) {
        this.alerts.add(alert);
        alert.setDevice(this);
        return this;
    }

    public Device removeAlert(Alert alert) {
        this.alerts.remove(alert);
        alert.setDevice(null);
        return this;
    }

    public void setAlerts(Set<Alert> alerts) {
        this.alerts = alerts;
    }

    public Set<Fields> getFields() {
        return fields;
    }

    public Device fields(Set<Fields> fields) {
        this.fields = fields;
        return this;
    }

    public Device addFields(Fields fields) {
        this.fields.add(fields);
        fields.setDevice(this);
        return this;
    }

    public Device removeFields(Fields fields) {
        this.fields.remove(fields);
        fields.setDevice(null);
        return this;
    }

    public void setFields(Set<Fields> fields) {
        this.fields = fields;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public Device deviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
        return this;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    public Zone getZone() {
        return zone;
    }

    public Device zone(Zone zone) {
        this.zone = zone;
        return this;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }

    public Provider getProvider() {
        return provider;
    }

    public Device provider(Provider provider) {
        this.provider = provider;
        return this;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public Protocol getProtocol() {
        return protocol;
    }

    public Device protocol(Protocol protocol) {
        this.protocol = protocol;
        return this;
    }

    public void setProtocol(Protocol protocol) {
        this.protocol = protocol;
    }

    public Set<Rule> getRules() {
        return rules;
    }

    public Device rules(Set<Rule> rules) {
        this.rules = rules;
        return this;
    }

    public Device addRule(Rule rule) {
        this.rules.add(rule);
        rule.getDevices().add(this);
        return this;
    }

    public Device removeRule(Rule rule) {
        this.rules.remove(rule);
        rule.getDevices().remove(this);
        return this;
    }

    public void setRules(Set<Rule> rules) {
        this.rules = rules;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Device device = (Device) o;
        if (device.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), device.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Device{" +
            "id=" + getId() +
            ", reference='" + getReference() + "'" +
            ", state='" + getState() + "'" +
            ", name='" + getName() + "'" +
            ", location='" + getLocation() + "'" +
            ", longitude='" + getLongitude() + "'" +
            ", latitude='" + getLatitude() + "'" +
            ", observaciones='" + getObservaciones() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", deleteAt='" + getDeleteAt() + "'" +
            ", updateAt='" + getUpdateAt() + "'" +
            "}";
    }
}

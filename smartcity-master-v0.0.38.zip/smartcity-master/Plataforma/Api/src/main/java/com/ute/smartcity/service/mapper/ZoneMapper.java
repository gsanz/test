package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.ZoneDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Zone and its DTO ZoneDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ZoneMapper extends EntityMapper<ZoneDTO, Zone> {



    default Zone fromId(Long id) {
        if (id == null) {
            return null;
        }
        Zone zona = new Zone();
        zona.setId(id);
        return zona;
    }
}

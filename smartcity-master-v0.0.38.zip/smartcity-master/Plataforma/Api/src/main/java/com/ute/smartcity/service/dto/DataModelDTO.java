package com.ute.smartcity.service.dto;

import com.ute.smartcity.domain.DataModelField;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A DTO for the DeviceType entity.
 */
public class DataModelDTO implements Serializable {

    @NotNull
    private String reference;

    @NotNull
    private String type;

    @NotNull
    private String name;

    private Set<DataModelField> fields = new HashSet<>();

    public Set<DataModelField> getFields() {
        return fields;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

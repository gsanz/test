package com.ute.smartcity.service.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidatorUtil {

    public boolean validate(String reference, Pattern pattern){
        Matcher matcherReference = pattern.matcher(reference);
        return matcherReference.find();
    }
}

package com.ute.smartcity.web.rest;

import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.UsuarioService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.UsuarioDTO;
import com.ute.smartcity.service.dto.UsuarioCriteria;
import com.ute.smartcity.service.UsuarioQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Usuario.
 */
@RestController
@RequestMapping("/api")
@Api(value="usuario-resource" , description = "Usuario Resource", tags = "usuario-resource")
public class UsuarioResource {

    private final Logger log = LoggerFactory.getLogger(UsuarioResource.class);

    private static final String ENTITY_NAME = "usuario";

    private final UsuarioService usuarioService;

    private final UsuarioQueryService usuarioQueryService;

    public UsuarioResource(UsuarioService usuarioService, UsuarioQueryService usuarioQueryService) {
        this.usuarioService = usuarioService;
        this.usuarioQueryService = usuarioQueryService;
    }

    /**
     * GET  /usuarios : get all the usuarios.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of usuarios in body
     */
    @GetMapping("/usuarios")
    public ResponseEntity<List<UsuarioDTO>> getAllUsuarios(UsuarioCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Usuarios by criteria: {}", criteria);
        Page<UsuarioDTO> page = usuarioQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/usuarios");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /usuarios/count : count all the usuarios.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/usuarios/count")
    public ResponseEntity<Long> countUsuarios(UsuarioCriteria criteria) {
        log.debug("REST request to count Usuarios by criteria: {}", criteria);
        return ResponseEntity.ok().body(usuarioQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /usuarios/:id : get the "id" usuario.
     *
     * @param id the id of the usuarioDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the usuarioDTO, or with status 404 (Not Found)
     */
    @GetMapping("/usuarios/{id}")
    public ResponseEntity<UsuarioDTO> getUsuario(@PathVariable Long id) {
        log.debug("REST request to get Usuario : {}", id);
        Optional<UsuarioDTO> usuarioDTO = usuarioService.findOne(id);
        return ResponseUtil.wrapOrNotFound(usuarioDTO);
    }

    /**
     * DELETE  /usuarios/:id : delete the "id" usuario.
     *
     * @param id the id of the usuarioDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/usuarios/{id}")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<Void> deleteUsuario(@PathVariable Long id) {
        log.debug("REST request to delete Usuario : {}", id);
        usuarioService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

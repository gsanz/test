package com.ute.smartcity.web.rest;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.DeviceType;
import com.ute.smartcity.domain.Rule;
import com.ute.smartcity.domain.User;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.security.SecurityUtils;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.DeviceTypeCriteria;
import com.ute.smartcity.service.dto.DeviceTypeDTO;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.dto.UsuarioDTO;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.service.util.EncodeSymbols;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.errors.UnathorizedException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.web.util.ResponseUtil;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * REST controller for managing DeviceType.
 */
@RestController
@RequestMapping("/api")
@Api(value="deviceType-resource" , description = "DeviceType Resource", tags = "deviceType-resource")
public class DeviceTypeResourceExt {

    private final Logger log = LoggerFactory.getLogger(DeviceTypeResourceExt.class);

    private static final String ENTITY_NAME = "deviceType";

    private final DeviceTypeService deviceTypeService;

    private final DeviceTypeQueryService deviceTypeQueryService;

    private final UserService userService;

    private final UsuarioService usuarioService;

    private final DeviceRepository deviceRepository;

    private final RuleService ruleService;

    private final String PERMISSION_DENIED = "You do not have permission to retrieve this information.";

    private final String PERMISSION_KEY = "permission";

    public static final Pattern VALID_REFERENCE =
        Pattern.compile("[^A-Za-z0-9_]", Pattern.CASE_INSENSITIVE);

    public DeviceTypeResourceExt(DeviceTypeService deviceTypeService, DeviceTypeQueryService deviceTypeQueryService, UserService userService, UsuarioService usuarioService, DeviceRepository deviceRepository, RuleService ruleService) {
        this.deviceTypeService = deviceTypeService;
        this.deviceTypeQueryService = deviceTypeQueryService;
        this.userService = userService;
        this.usuarioService = usuarioService;
        this.deviceRepository = deviceRepository;
        this.ruleService = ruleService;
    }

    /**
     * GET  /device-types : get all the deviceTypes.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of deviceTypes in body
     */
    @GetMapping("/device-types")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "','" + AuthoritiesConstants.PROVIDER + "')")
    public ResponseEntity<List<DeviceTypeDTO>> getAllDeviceTypes(DeviceTypeCriteria criteria, Pageable pageable) {
        log.debug("REST request to get DeviceTypes by criteria: {}", criteria);
        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        boolean isProvider = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.PROVIDER);
        if (!isAdmin && !isProvider) {
            Optional<String> optionalUser = SecurityUtils.getCurrentUserLogin();
            if (optionalUser.isPresent()) {
                String userString = optionalUser.get();
                Optional<User> optUserWithAuthority =userService.getUserWithAuthoritiesByLogin(userString);
                if (optUserWithAuthority.isPresent()) {
                    User userRequest = optUserWithAuthority.get();
                    LongFilter longFilter = new LongFilter();
                    longFilter.setEquals(userRequest.getId());
                    criteria.setUsuariosId(longFilter);
                } else {
                    throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
                }
            }
        }
        Page<DeviceTypeDTO> page = deviceTypeQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/device-types");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /device-types/count : count all the deviceTypes.
     *
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the count in body
     */
    @GetMapping("/device-types/count")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<Long> countDeviceTypes(DeviceTypeCriteria criteria) {
        log.debug("REST request to count DeviceTypes by criteria: {}", criteria);
        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        if (!isAdmin) {
            Optional<String> optionalUser = SecurityUtils.getCurrentUserLogin();
            if( optionalUser.isPresent()) {
                String userString = optionalUser.get();
                Optional<User> optUserWithAuthori =userService.getUserWithAuthoritiesByLogin(userString);
                if (optUserWithAuthori.isPresent()) {
                    User userRequest = optUserWithAuthori.get();
                    LongFilter longFilter = new LongFilter();
                    longFilter.setEquals(userRequest.getId());
                    criteria.setUsuariosId(longFilter);

                } else {
                    throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
                }
            }
        }
        return ResponseEntity.ok().body(deviceTypeQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /device-types/:id : get the "id" deviceType.
     *
     * @param id the id of the deviceTypeDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the deviceTypeDTO, or with status 404 (Not Found)
     */
    @GetMapping("/device-types/{id}")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<DeviceTypeDTO> getDeviceType(@PathVariable Long id) {
        log.debug("REST request to get DeviceType : {}", id);
        Optional<DeviceTypeDTO> deviceTypeDTO = deviceTypeService.findOne(id);
        if (!deviceTypeDTO.isPresent()) {
            return ResponseUtil.wrapOrNotFound(deviceTypeDTO);
        }

        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        if (isAdmin) {
            return ResponseUtil.wrapOrNotFound(deviceTypeDTO);
        }

        Optional<String> optionalUser = SecurityUtils.getCurrentUserLogin();
        if (!optionalUser.isPresent() ) {
            return ResponseUtil.wrapOrNotFound(deviceTypeDTO);
        }

        String userString = optionalUser.get();

        if (!userService.getUserWithAuthoritiesByLogin(userString).isPresent()) {
            return ResponseUtil.wrapOrNotFound(deviceTypeDTO);
        }

        Optional<User> userByAuthByLogin = userService.getUserWithAuthoritiesByLogin(userString);
        User userRequest = null;
        if(userByAuthByLogin.isPresent()){
            userRequest = userByAuthByLogin.get();
        }

        if(userRequest != null) {
            Optional<UsuarioDTO> usuarioOptional = usuarioService.findOne(userRequest.getId());
            if (!usuarioOptional.isPresent()) {
                throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
            }


            DeviceTypeDTO deviceTypeDTOSearch = usuarioOptional.get().getDevicesTypes().stream()
                .filter(deviceType -> deviceTypeDTO.get().getId().equals(deviceType.getId()))
                .findAny()
                .orElse(null);

            if (deviceTypeDTOSearch == null) {
                throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
            }
        }

        return ResponseUtil.wrapOrNotFound(deviceTypeDTO);
    }

    /**
     * POST  /device-types : Create a new deviceType.
     *
     * @param deviceTypeDTO the deviceTypeDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new deviceTypeDTO, or with status 400 (Bad Request) if the deviceType has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/device-types")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<DeviceTypeDTO> createDeviceType(@Valid @RequestBody DeviceTypeDTO deviceTypeDTO) throws URISyntaxException {
        log.debug("REST request to save DeviceType : {}", deviceTypeDTO);
        Optional<DeviceType> deviceTipeOptional = deviceTypeService.findByReference(deviceTypeDTO.getReference());

        if (deviceTipeOptional.isPresent()){
            throw new BadRequestAlertException("A new device cannot already have a Reference", ENTITY_NAME, "referenceexists");
        }
        if (deviceTypeDTO.getId() != null) {
            throw new BadRequestAlertException("A new deviceType cannot already have an ID", ENTITY_NAME, "idexists");
        }
        String reference = deviceTypeDTO.getReference().trim();
        if (deviceTypeDTO.getReference() == null || deviceTypeDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("A device needs a reference", ENTITY_NAME, "noreference");
        }
        String type = deviceTypeDTO.getType().trim();
        if (deviceTypeDTO.getType() == null || deviceTypeDTO.getType().equals("") || type.length() <= 0) {
            throw new BadRequestAlertException("A device needs a type", ENTITY_NAME, "notype");
        }
        String name = deviceTypeDTO.getName().trim();
        if (deviceTypeDTO.getName() == null || deviceTypeDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("A device needs a name", ENTITY_NAME, "noname");
        }
        validateReference(deviceTypeDTO.getReference());

        DeviceTypeDTO result = null;

        EncodeSymbols encodeSymbols = new EncodeSymbols();
        deviceTypeDTO = encodeSymbols.checkEncodeDeviceType(deviceTypeDTO);

        try {
            result = deviceTypeService.save(deviceTypeDTO);
        } catch (PlatformException e) {
            log.debug("Save devicetype failed in the platform: ", e);
            throw new BadRequestAlertException("There was an error trying to save the device type to fiware", ENTITY_NAME, "fail-save-orion-devicetype");
        } catch (Exception e) {
            log.debug("Save devicetype failed: ", e);
        }

        if(result != null) {
            return ResponseEntity.created(new URI("/api/device-types/" + result.getId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
                .body(result);
        }

        return null;
    }

    /**
     * PUT  /device-types : Updates an existing deviceType.
     *
     * @param deviceTypeDTO the deviceTypeDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated deviceTypeDTO,
     * or with status 400 (Bad Request) if the deviceTypeDTO is not valid,
     * or with status 500 (Internal Server Error) if the deviceTypeDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/device-types")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<DeviceTypeDTO> updateDeviceType(@Valid @RequestBody DeviceTypeDTO deviceTypeDTO) {
        log.debug("REST request to update DeviceType : {}", deviceTypeDTO);
        if (deviceTypeDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String reference = deviceTypeDTO.getReference().trim();
        if (deviceTypeDTO.getReference() == null || deviceTypeDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("A device needs a reference", ENTITY_NAME, "noreference");
        }
        String type = deviceTypeDTO.getType().trim();
        if (deviceTypeDTO.getType() == null || deviceTypeDTO.getType().equals("") || type.length() <= 0) {
            throw new BadRequestAlertException("A device needs a type", ENTITY_NAME, "notype");
        }
        String name = deviceTypeDTO.getName().trim();
        if (deviceTypeDTO.getName() == null || deviceTypeDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("A device needs a name", ENTITY_NAME, "noname");
        }
        validateReference(deviceTypeDTO.getReference());

        DeviceTypeDTO result = null;

        EncodeSymbols encodeSymbols = new EncodeSymbols();
        deviceTypeDTO = encodeSymbols.checkEncodeDeviceType(deviceTypeDTO);

        try {
            result = deviceTypeService.save(deviceTypeDTO);
        } catch (PlatformException e) {
            log.debug("Update devicetype failed: ", e);
            throw new BadRequestAlertException("There was an error trying to update the device type on fiware", ENTITY_NAME, "fail-save-orion-devicetype");
        }
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, deviceTypeDTO.getId().toString()))
            .body(result);
    }

    /**
     * DELETE  /device-types/:id : delete the "id" deviceType.
     *
     * @param id the id of the deviceTypeDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/device-types/{id}")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<Void> deleteDeviceType(@PathVariable Long id) {
        log.debug("REST request to delete DeviceType : {}", id);

        checkIfExisitsDeviceWithThisType(id);

        checkIfExistsRulesWithThisType(id);


        try {
            deviceTypeService.delete(id);
        }  catch (PlatformException e) {
            log.debug("Update devicetype failed: ", e);
            throw new BadRequestAlertException("There was an error trying to delete the device type on fiware", ENTITY_NAME, "fail-delete-orion-devicetype");
        } catch (Exception e) {
            log.debug("Delete devicetype failed: ", e);
        }
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    private void checkIfExistsRulesWithThisType(@PathVariable Long id) {
        Optional<List<RuleDTO>> rules = ruleService.findByDeviceType(id);

        if(rules.isPresent()) {
            throw new BadRequestAlertException("Can't delete a device type when there are rules attached to it", ENTITY_NAME, "rulesattached");
        }
    }

    private void checkIfExisitsDeviceWithThisType(@PathVariable Long id) {
        Optional<List<Device>> allByDeviceTypeId = deviceRepository.findAllByDeviceTypeId(id);

        if(allByDeviceTypeId.isPresent()) {
            throw new BadRequestAlertException("Can't delete a device type when there are devices attached to it", ENTITY_NAME, "devicesattached");
        }
    }

    public void validateReference(String reference){
        Matcher matcherReference = VALID_REFERENCE.matcher(reference);
        boolean isNotValidReference = matcherReference.find();

        if (isNotValidReference) {
            log.debug("Invalid reference: " + reference + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Bad reference characters", ENTITY_NAME, "referenceInvalid");
        }
    }
}

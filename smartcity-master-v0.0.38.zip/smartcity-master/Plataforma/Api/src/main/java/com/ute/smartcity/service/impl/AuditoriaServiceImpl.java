package com.ute.smartcity.service.impl;

import com.ute.smartcity.service.AuditoriaService;
import com.ute.smartcity.domain.Auditoria;
import com.ute.smartcity.repository.AuditoriaRepository;
import com.ute.smartcity.service.dto.AuditoriaDTO;
import com.ute.smartcity.service.mapper.AuditoriaMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing Auditoria.
 */
@Service
@Transactional
public class AuditoriaServiceImpl implements AuditoriaService {

    private final Logger log = LoggerFactory.getLogger(AuditoriaServiceImpl.class);

    private final AuditoriaRepository auditoriaRepository;

    private final AuditoriaMapper auditoriaMapper;

    public AuditoriaServiceImpl(AuditoriaRepository auditoriaRepository, AuditoriaMapper auditoriaMapper) {
        this.auditoriaRepository = auditoriaRepository;
        this.auditoriaMapper = auditoriaMapper;
    }

    /**
     * Save a auditoria.
     *
     * @param auditoriaDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public AuditoriaDTO save(AuditoriaDTO auditoriaDTO) {
        log.debug("Request to save Auditoria : {}", auditoriaDTO);

        Auditoria auditoria = auditoriaMapper.toEntity(auditoriaDTO);
        auditoria = auditoriaRepository.save(auditoria);
        return auditoriaMapper.toDto(auditoria);
    }

    /**
     * Get all the auditorias.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<AuditoriaDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Auditorias");
        return auditoriaRepository.findAll(pageable)
            .map(auditoriaMapper::toDto);
    }


    /**
     * Get one auditoria by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<AuditoriaDTO> findOne(Long id) {
        log.debug("Request to get Auditoria : {}", id);
        return auditoriaRepository.findById(id)
            .map(auditoriaMapper::toDto);
    }

    /**
     * Delete the auditoria by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Auditoria : {}", id);
        auditoriaRepository.deleteById(id);
    }
}

package com.ute.smartcity.web.rest;

import com.ute.smartcity.service.DeviceService;
import com.ute.smartcity.service.DeviceTypeService;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.DeviceTypeMapper;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for managing Device.
 */
@RestController
@RequestMapping("/api")
@Api(value="device-resource" , description = "Device Resource", tags = "device-resource")
public class DeviceResource {

    private final Logger log = LoggerFactory.getLogger(DeviceResource.class);

    private static final String ENTITY_NAME = "device";

    private final DeviceService deviceService;

    private final DeviceMapper deviceMapper;

    private final DeviceTypeService deviceTypeService;

    private final DeviceTypeMapper deviceTypeMapper;

    private final SmartCityPlatformService smartCityPlatformService;

    public DeviceResource(DeviceService deviceService, DeviceMapper deviceMapper, DeviceTypeService deviceTypeService, DeviceTypeMapper deviceTypeMapper, SmartCityPlatformService smartCityPlatformService) {
        this.deviceService = deviceService;
        this.deviceMapper = deviceMapper;
        this.deviceTypeService = deviceTypeService;
        this.deviceTypeMapper = deviceTypeMapper;
        this.smartCityPlatformService = smartCityPlatformService;
    }



}

package com.ute.smartcity.service;


import com.ute.smartcity.repository.DeviceObservationRepository;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.DeviceObservationCriteria;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class DeviceObservationQueryService {

    private final Logger log = LoggerFactory.getLogger(DeviceObservationQueryService.class);

    private final DeviceObservationRepository observationsRepository;

    public DeviceObservationQueryService(DeviceObservationRepository observationsRepository) {
        this.observationsRepository = observationsRepository;
    }

    public Page<JSONObject> findByCriteria(DeviceDTO deviceDTO, DeviceObservationCriteria criteria, Pageable pageable, String dateFieldToFilter){
        log.debug("DeviceObservationQueryService findByCriteria device {} criteria {}" ,deviceDTO,criteria);
        return observationsRepository.findAll(deviceDTO, criteria ,pageable, dateFieldToFilter);
    }
}

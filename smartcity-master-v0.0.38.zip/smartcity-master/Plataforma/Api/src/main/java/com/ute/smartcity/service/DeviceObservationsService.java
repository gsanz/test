package com.ute.smartcity.service;


import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.DeviceObservationCriteria;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface DeviceObservationsService {

    /**
     * Get all the devices.
     * @param device the device information
     * @return the list of entities
     */
    Page<JSONObject> findAll(DeviceDTO device, DeviceObservationCriteria criteria, Pageable pageable, String dateFieldToFilter);
}

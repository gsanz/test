package com.ute.smartcity.web.rest.errors;

public class CreateUsuarioDeviceTypeException extends BadRequestAlertException {

    private static final long serialVersionUID = 1L;

    public CreateUsuarioDeviceTypeException() {
        super("Error creating Usuario!", "usuario", "devicesTypesNotFound");
    }
}

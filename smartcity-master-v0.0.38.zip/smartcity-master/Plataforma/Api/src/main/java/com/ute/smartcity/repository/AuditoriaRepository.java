package com.ute.smartcity.repository;

import com.ute.smartcity.domain.Auditoria;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the Auditoria entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AuditoriaRepository extends JpaRepository<Auditoria, Long>, JpaSpecificationExecutor<Auditoria> {

}

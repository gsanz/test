package com.ute.smartcity.service;

import com.ute.smartcity.service.dto.SubscriptionsDTO;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

/**
 * Service Interface for managing Subscriptions.
 */
public interface SubscriptionsService {

    /**
     * Save a subscriptions.
     *
     * @param subscriptionsDTO the entity to save
     * @return the persisted entity
     */
    SubscriptionsDTO save(SubscriptionsDTO subscriptionsDTO);

    /**
     * Get all the subscriptions.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<SubscriptionsDTO> findAll(Pageable pageable);


    /**
     * Get the "id" subscriptions.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<SubscriptionsDTO> findOne(Long id);

    /**
     * Delete the "id" subscriptions.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}

package com.ute.smartcity.service.dto;
import java.time.Instant;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the AuditFiwarePlatform entity.
 */
public class AuditFiwarePlatformDTO implements Serializable {

    private Long id;

    @NotNull
    private Instant date;

    @NotNull
    private String type;

    @NotNull
    @Size(max = 3500)
    private String requestUrl;

    @NotNull
    @Size(max = 3500)
    private String requestContent;

    @NotNull
    @Size(max = 3500)
    private String responseContent;

    @NotNull
    private Integer responseCode;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Instant getDate() {
        return date;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    public String getRequestContent() {
        return requestContent;
    }

    public void setRequestContent(String requestContent) {
        this.requestContent = requestContent;
    }

    public String getResponseContent() {
        return responseContent;
    }

    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }

    public Integer getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(Integer responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AuditFiwarePlatformDTO auditFiwarePlatformDTO = (AuditFiwarePlatformDTO) o;
        if (auditFiwarePlatformDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), auditFiwarePlatformDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "AuditFiwarePlatformDTO{" +
            "id=" + getId() +
            ", date='" + getDate() + "'" +
            ", type='" + getType() + "'" +
            ", requestUrl='" + getRequestUrl() + "'" +
            ", requestContent='" + getRequestContent() + "'" +
            ", responseContent='" + getResponseContent() + "'" +
            ", responseCode=" + getResponseCode() +
            "}";
    }
}

package com.ute.smartcity.service.dto;
import com.ute.smartcity.domain.enumeration.CompareType;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the RuleCompareFields entity.
 */
public class RuleCompareFieldsDTO implements Serializable {

    private Long id;

    private CompareType compareType;

    private String value;

    private String fieldName;

    private String fieldType;

    private Long ruleId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CompareType getCompareType() {
        return compareType;
    }

    public void setCompareType(CompareType compareType) {
        this.compareType = compareType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Long getRuleId() {
        return ruleId;
    }

    public void setRuleId(Long ruleId) {
        this.ruleId = ruleId;
    }

    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RuleCompareFieldsDTO ruleCompareFieldsDTO = (RuleCompareFieldsDTO) o;
        if (ruleCompareFieldsDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), ruleCompareFieldsDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RuleCompareFieldsDTO{" +
            "id=" + getId() +
            ", compareType='" + getCompareType() + "'" +
            ", value='" + getValue() + "'" +
            ", fieldName='" + getFieldName() + "'" +
            ", rule=" + getRuleId() +
            "}";
    }
}

package com.ute.smartcity.service;

import java.util.List;

import javax.persistence.criteria.JoinType;

import com.ute.smartcity.service.dto.RuleListDTO;
import com.ute.smartcity.service.mapper.RuleListMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.ute.smartcity.domain.Rule;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.RuleRepository;
import com.ute.smartcity.service.dto.RuleCriteria;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.mapper.RuleMapper;

/**
 * Service for executing complex queries for Rule entities in the database.
 * The main input is a {@link RuleCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link RuleDTO} or a {@link Page} of {@link RuleDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class RuleQueryService extends QueryService<Rule> {

    private final Logger log = LoggerFactory.getLogger(RuleQueryService.class);

    private final RuleRepository ruleRepository;

    private final RuleMapper ruleMapper;

    private final RuleListMapper ruleListMapper;

    public RuleQueryService(RuleRepository ruleRepository, RuleMapper ruleMapper, RuleListMapper ruleListMapper) {
        this.ruleRepository = ruleRepository;
        this.ruleMapper = ruleMapper;
        this.ruleListMapper = ruleListMapper;
    }

    /**
     * Return a {@link List} of {@link RuleDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<RuleDTO> findByCriteria(RuleCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<Rule> specification = createSpecification(criteria);
        return ruleMapper.toDto(ruleRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link RuleDTO} which matches the criteria from the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page     The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<RuleDTO> findByCriteria(RuleCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<Rule> specification = createSpecification(criteria);
        return ruleRepository.findAll(specification, page)
            .map(ruleMapper::toDto);
    }

    @Transactional(readOnly = true)
    public Page<RuleListDTO> findListByCriteria(RuleCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<Rule> specification = createSpecification(criteria);
        return ruleRepository.findAll(specification, page)
            .map(ruleListMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     *
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(RuleCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<Rule> specification = createSpecification(criteria);
        return ruleRepository.count(specification);
    }

    /**
     * Function to convert RuleCriteria to a {@link Specification}
     */
    private Specification<Rule> createSpecification(RuleCriteria criteria) {
        Specification<Rule> specification = Specification.where(null);
        if (criteria == null) {
            return specification;
        }
        if (criteria.getId() != null) {
            specification = specification.and(buildSpecification(criteria.getId(), Rule_.id));
        }
        if (criteria.getReference() != null) {
            specification = specification.and(buildStringSpecification(criteria.getReference(), Rule_.reference));
        }
        if (criteria.getDescription() != null) {
            specification = specification.and(buildStringSpecification(criteria.getDescription(), Rule_.description));
        }
        if (criteria.getLevelRule() != null) {
            specification = specification.and(buildSpecification(criteria.getLevelRule(), Rule_.levelRule));
        }
        if (criteria.getEvaluationType() != null) {
            specification = specification.and(buildSpecification(criteria.getEvaluationType(), Rule_.evaluationType));
        }
        if (criteria.getInactivityTime() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getInactivityTime(), Rule_.inactivityTime));
        }
        if (criteria.getTextEPL() != null) {
            specification = specification.and(buildStringSpecification(criteria.getTextEPL(), Rule_.textEPL));
        }
        if (criteria.getCreateAt() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getCreateAt(), Rule_.createAt));
        }
        if (criteria.getDeleteAt() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getDeleteAt(), Rule_.deleteAt));
        }
        if (criteria.getUpdateAt() != null) {
            specification = specification.and(buildRangeSpecification(criteria.getUpdateAt(), Rule_.updateAt));
        }
        if (criteria.getRuleCompareFieldsId() != null) {
            specification = specification.and(buildSpecification(criteria.getRuleCompareFieldsId(),
                root -> root.join(Rule_.ruleCompareFields, JoinType.LEFT).get(RuleCompareFields_.id)));
        }
        if (criteria.getRuleActionId() != null) {
            specification = specification.and(buildSpecification(criteria.getRuleActionId(),
                root -> root.join(Rule_.ruleActions, JoinType.LEFT).get(RuleAction_.id)));
        }
        if (criteria.getDeviceTypeId() != null) {
            specification = specification.and(buildSpecification(criteria.getDeviceTypeId(),
                root -> root.join(Rule_.deviceType, JoinType.LEFT).get(DeviceType_.id)));
        }
        if (criteria.getDeviceId() != null) {
            specification = specification.and(buildSpecification(criteria.getDeviceId(),
                root -> root.join(Rule_.devices, JoinType.LEFT).get(Device_.id)));
        }
        return specification;
    }
}

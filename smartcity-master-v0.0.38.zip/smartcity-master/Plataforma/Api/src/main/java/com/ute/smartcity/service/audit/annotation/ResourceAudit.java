package com.ute.smartcity.service.audit.annotation;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Documented
public @interface ResourceAudit {

    String value() default "";

}

package com.ute.smartcity.service.dto;

import java.io.Serializable;
import java.util.Objects;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;
import io.github.jhipster.service.filter.InstantFilter;

/**
 * Criteria class for the AuditFiwarePlatform entity. This class is used in AuditFiwarePlatformResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /audit-fiware-platforms?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class AuditFiwarePlatformCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private InstantFilter date;

    private StringFilter type;

    private StringFilter requestUrl;

    private StringFilter requestContent;

    private StringFilter responseContent;

    private IntegerFilter responseCode;

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public InstantFilter getDate() {
        return date;
    }

    public void setDate(InstantFilter date) {
        this.date = date;
    }

    public StringFilter getType() {
        return type;
    }

    public void setType(StringFilter type) {
        this.type = type;
    }

    public StringFilter getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(StringFilter requestUrl) {
        this.requestUrl = requestUrl;
    }

    public StringFilter getRequestContent() {
        return requestContent;
    }

    public void setRequestContent(StringFilter requestContent) {
        this.requestContent = requestContent;
    }

    public StringFilter getResponseContent() {
        return responseContent;
    }

    public void setResponseContent(StringFilter responseContent) {
        this.responseContent = responseContent;
    }

    public IntegerFilter getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(IntegerFilter responseCode) {
        this.responseCode = responseCode;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final AuditFiwarePlatformCriteria that = (AuditFiwarePlatformCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(date, that.date) &&
            Objects.equals(type, that.type) &&
            Objects.equals(requestUrl, that.requestUrl) &&
            Objects.equals(requestContent, that.requestContent) &&
            Objects.equals(responseContent, that.responseContent) &&
            Objects.equals(responseCode, that.responseCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        date,
        type,
        requestUrl,
        requestContent,
        responseContent,
        responseCode
        );
    }

    @Override
    public String toString() {
        return "AuditFiwarePlatformCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (date != null ? "date=" + date + ", " : "") +
                (type != null ? "type=" + type + ", " : "") +
                (requestUrl != null ? "requestUrl=" + requestUrl + ", " : "") +
                (requestContent != null ? "requestContent=" + requestContent + ", " : "") +
                (responseContent != null ? "responseContent=" + responseContent + ", " : "") +
                (responseCode != null ? "responseCode=" + responseCode + ", " : "") +
            "}";
    }

}

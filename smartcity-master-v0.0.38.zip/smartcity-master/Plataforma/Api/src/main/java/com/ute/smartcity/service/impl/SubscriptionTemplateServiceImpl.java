package com.ute.smartcity.service.impl;

import com.ute.smartcity.service.SubscriptionTemplateService;
import com.ute.smartcity.domain.SubscriptionTemplate;
import com.ute.smartcity.repository.SubscriptionTemplateRepository;
import com.ute.smartcity.service.dto.SubscriptionTemplateDTO;
import com.ute.smartcity.service.mapper.SubscriptionTemplateMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing SubscriptionTemplate.
 */
@Service
@Transactional
public class SubscriptionTemplateServiceImpl implements SubscriptionTemplateService {

    private final Logger log = LoggerFactory.getLogger(SubscriptionTemplateServiceImpl.class);

    private final SubscriptionTemplateRepository subscriptionTemplateRepository;

    private final SubscriptionTemplateMapper subscriptionTemplateMapper;

    public SubscriptionTemplateServiceImpl(SubscriptionTemplateRepository subscriptionTemplateRepository, SubscriptionTemplateMapper subscriptionTemplateMapper) {
        this.subscriptionTemplateRepository = subscriptionTemplateRepository;
        this.subscriptionTemplateMapper = subscriptionTemplateMapper;
    }

    /**
     * Save a subscriptionTemplate.
     *
     * @param subscriptionTemplateDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public SubscriptionTemplateDTO save(SubscriptionTemplateDTO subscriptionTemplateDTO) {
        log.debug("Request to save SubscriptionTemplate : {}", subscriptionTemplateDTO);
        SubscriptionTemplate subscriptionTemplate = subscriptionTemplateMapper.toEntity(subscriptionTemplateDTO);
        subscriptionTemplate = subscriptionTemplateRepository.save(subscriptionTemplate);
        return subscriptionTemplateMapper.toDto(subscriptionTemplate);
    }

    /**
     * Get all the subscriptionTemplates.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<SubscriptionTemplateDTO> findAll(Pageable pageable) {
        log.debug("Request to get all SubscriptionTemplates");
        return subscriptionTemplateRepository.findAll(pageable)
            .map(subscriptionTemplateMapper::toDto);
    }

    /**
     * Get one subscriptionTemplate by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<SubscriptionTemplateDTO> findOne(Long id) {
        log.debug("Request to get SubscriptionTemplate : {}", id);
        return subscriptionTemplateRepository.findById(id)
            .map(subscriptionTemplateMapper::toDto);
    }

    /**
     * Delete the subscriptionTemplate by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete SubscriptionTemplate : {}", id);
        subscriptionTemplateRepository.deleteById(id);
    }
}

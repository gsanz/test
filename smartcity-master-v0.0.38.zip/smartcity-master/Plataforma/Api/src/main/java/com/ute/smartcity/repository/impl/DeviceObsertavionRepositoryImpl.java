package com.ute.smartcity.repository.impl;

import com.ute.smartcity.repository.DeviceObservationRepository;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.DeviceObservationCriteria;
import net.minidev.json.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Repository
public class DeviceObsertavionRepositoryImpl implements DeviceObservationRepository {


    private  List<JSONObject> getParkingObservations() {

        List<JSONObject> observationList = new ArrayList<>();
        Instant instant = Instant.now();
        long quince = 15L;
        instant = instant.minus(quince * 20, ChronoUnit.MINUTES);

        int totalplazas = 100;
        for (int i = 1; i <= 20; i++) {

            int ocupadas = ThreadLocalRandom.current().nextInt(1, totalplazas);
            int ocupacion = Math.floorDiv(ocupadas * 100, totalplazas);
            JSONObject observation = new JSONObject();

            instant = instant.plus(15, ChronoUnit.MINUTES);
            observation.put("id", "aaaaaaaaaaaaaaaa");
            observation.put("plazas", Integer.toString(totalplazas));
            observation.put("ocupadas", Integer.toString(ocupadas));
            observation.put("ocupacion", Integer.toString(ocupacion) + " %");
            observation.put("recvTime", instant.toString());
            observationList.add(observation);
        }
        return observationList;
    }

    public List<JSONObject> getQualityObservations() {


        List<JSONObject> observationList = new ArrayList<>();
        Instant instant = Instant.now();
        long quince = 15L;
        instant = instant.minus(quince * 20, ChronoUnit.MINUTES);
        for (int i = 1; i <= 20; i++) {
            int randTemp = ThreadLocalRandom.current().nextInt(10, 30);
            int randCO = ThreadLocalRandom.current().nextInt(100, 300);
            JSONObject observation = new JSONObject();

            instant = instant.plus(15, ChronoUnit.MINUTES);
            observation.put("id", "aaaaaaaaaaaaaaaa");
            observation.put("temperature", Integer.toString(randTemp));
            observation.put("CO", Integer.toString(randCO));
            observation.put("recvTime", instant.toString());
            observationList.add(observation);
        }

        return observationList;
    }

    @Override
    public Page<JSONObject> findAll(DeviceDTO device, DeviceObservationCriteria criteria, Pageable pageable, String dateFieldToFilter) {
        int total = 0;
        List<JSONObject> documentList = new ArrayList<>();
        if (device.getDeviceTypeName().contains("alidad")) {
            documentList = getQualityObservations();
        }
        if (device.getDeviceTypeName().contains("arking")) {
            documentList = getParkingObservations();
        }
        total = documentList.size();
        return new PageImpl<>(documentList, pageable, total);
    }
}

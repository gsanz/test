package com.ute.smartcity.service.dto;

import java.io.Serializable;
import java.util.Objects;
import com.ute.smartcity.domain.enumeration.LevelRule;
import com.ute.smartcity.domain.enumeration.EvaluationType;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;
import io.github.jhipster.service.filter.BigDecimalFilter;
import io.github.jhipster.service.filter.ZonedDateTimeFilter;

/**
 * Criteria class for the Rule entity. This class is used in RuleResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /rules?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class RuleCriteria implements Serializable {
    /**
     * Class for filtering LevelRule
     */
    public static class LevelRuleFilter extends Filter<LevelRule> {
    }
    /**
     * Class for filtering EvaluationType
     */
    public static class EvaluationTypeFilter extends Filter<EvaluationType> {
    }

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter reference;

    private StringFilter description;

    private LevelRuleFilter levelRule;

    private EvaluationTypeFilter evaluationType;

    private BigDecimalFilter inactivityTime;

    private StringFilter textEPL;

    private ZonedDateTimeFilter createAt;

    private ZonedDateTimeFilter deleteAt;

    private ZonedDateTimeFilter updateAt;

    private LongFilter ruleCompareFieldsId;

    private LongFilter ruleActionId;

    private LongFilter deviceTypeId;

    private LongFilter deviceId;

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getReference() {
        return reference;
    }

    public void setReference(StringFilter reference) {
        this.reference = reference;
    }

    public StringFilter getDescription() {
        return description;
    }

    public void setDescription(StringFilter description) {
        this.description = description;
    }

    public LevelRuleFilter getLevelRule() {
        return levelRule;
    }

    public void setLevelRule(LevelRuleFilter levelRule) {
        this.levelRule = levelRule;
    }

    public EvaluationTypeFilter getEvaluationType() {
        return evaluationType;
    }

    public void setEvaluationType(EvaluationTypeFilter evaluationType) {
        this.evaluationType = evaluationType;
    }

    public BigDecimalFilter getInactivityTime() {
        return inactivityTime;
    }

    public void setInactivityTime(BigDecimalFilter inactivityTime) {
        this.inactivityTime = inactivityTime;
    }

    public StringFilter getTextEPL() {
        return textEPL;
    }

    public void setTextEPL(StringFilter textEPL) {
        this.textEPL = textEPL;
    }

    public ZonedDateTimeFilter getCreateAt() {
        return createAt;
    }

    public void setCreateAt(ZonedDateTimeFilter createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTimeFilter getDeleteAt() {
        return deleteAt;
    }

    public void setDeleteAt(ZonedDateTimeFilter deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTimeFilter getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(ZonedDateTimeFilter updateAt) {
        this.updateAt = updateAt;
    }

    public LongFilter getRuleCompareFieldsId() {
        return ruleCompareFieldsId;
    }

    public void setRuleCompareFieldsId(LongFilter ruleCompareFieldsId) {
        this.ruleCompareFieldsId = ruleCompareFieldsId;
    }

    public LongFilter getRuleActionId() {
        return ruleActionId;
    }

    public void setRuleActionId(LongFilter ruleActionId) {
        this.ruleActionId = ruleActionId;
    }

    public LongFilter getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(LongFilter deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    public LongFilter getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(LongFilter deviceId) {
        this.deviceId = deviceId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final RuleCriteria that = (RuleCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(reference, that.reference) &&
            Objects.equals(description, that.description) &&
            Objects.equals(levelRule, that.levelRule) &&
            Objects.equals(evaluationType, that.evaluationType) &&
            Objects.equals(inactivityTime, that.inactivityTime) &&
            Objects.equals(textEPL, that.textEPL) &&
            Objects.equals(createAt, that.createAt) &&
            Objects.equals(deleteAt, that.deleteAt) &&
            Objects.equals(updateAt, that.updateAt) &&
            Objects.equals(ruleCompareFieldsId, that.ruleCompareFieldsId) &&
            Objects.equals(ruleActionId, that.ruleActionId) &&
            Objects.equals(deviceTypeId, that.deviceTypeId) &&
            Objects.equals(deviceId, that.deviceId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        reference,
        description,
        levelRule,
        evaluationType,
        inactivityTime,
        textEPL,
        createAt,
        deleteAt,
        updateAt,
        ruleCompareFieldsId,
        ruleActionId,
        deviceTypeId,
        deviceId
        );
    }

    @Override
    public String toString() {
        return "RuleCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (reference != null ? "reference=" + reference + ", " : "") +
                (description != null ? "description=" + description + ", " : "") +
                (levelRule != null ? "levelRule=" + levelRule + ", " : "") +
                (evaluationType != null ? "evaluationType=" + evaluationType + ", " : "") +
                (inactivityTime != null ? "inactivityTime=" + inactivityTime + ", " : "") +
                (textEPL != null ? "textEPL=" + textEPL + ", " : "") +
                (createAt != null ? "createAt=" + createAt + ", " : "") +
                (deleteAt != null ? "deleteAt=" + deleteAt + ", " : "") +
                (updateAt != null ? "updateAt=" + updateAt + ", " : "") +
                (ruleCompareFieldsId != null ? "ruleCompareFieldsId=" + ruleCompareFieldsId + ", " : "") +
                (ruleActionId != null ? "ruleActionId=" + ruleActionId + ", " : "") +
                (deviceTypeId != null ? "deviceTypeId=" + deviceTypeId + ", " : "") +
                (deviceId != null ? "deviceId=" + deviceId + ", " : "") +
            "}";
    }

}

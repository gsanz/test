package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.repository.DeviceObservationRepository;
import com.ute.smartcity.service.DeviceObservationsService;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.DeviceObservationCriteria;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class DeviceObsertavionsServiceImpl implements DeviceObservationsService {

    private final org.slf4j.Logger log = LoggerFactory.getLogger(DeviceObsertavionsServiceImpl.class);

    private final DeviceObservationRepository deviceObservationRepository;

    public DeviceObsertavionsServiceImpl(DeviceObservationRepository deviceObservationRepository) {
        this.deviceObservationRepository = deviceObservationRepository;
    }


    @Override
    public Page<JSONObject> findAll(DeviceDTO device, DeviceObservationCriteria criteria,Pageable pageable, String dateFieldToFilter) {
        return deviceObservationRepository.findAll(device,criteria,pageable,dateFieldToFilter);
    }
}

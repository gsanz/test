/**
 * Audit specific code.
 */
package com.ute.smartcity.config.audit;

package com.ute.smartcity.service.dto;

import java.time.Instant;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;
import com.ute.smartcity.domain.enumeration.TipoCambio;

/**
 * A DTO for the Auditoria entity.
 */
public class AuditoriaDTO implements Serializable {

    private Long id;

    @NotNull
    @Size(max = 250)
    private String entityName;

    @NotNull
    @Size(max = 250)
    private String usuarioLogin;

    @NotNull
    private TipoCambio tipoCambio;

    @NotNull
    private Instant date;

    private Integer entityId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getUsuarioLogin() {
        return usuarioLogin;
    }

    public void setUsuarioLogin(String usuarioLogin) {
        this.usuarioLogin = usuarioLogin;
    }

    public TipoCambio getTipoCambio() {
        return tipoCambio;
    }

    public void setTipoCambio(TipoCambio tipoCambio) {
        this.tipoCambio = tipoCambio;
    }

    public Instant getDate() {
        return date;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public Integer getEntityId() {
        return entityId;
    }

    public void setEntityId(Integer entityId) {
        this.entityId = entityId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AuditoriaDTO auditoriaDTO = (AuditoriaDTO) o;
        if (auditoriaDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), auditoriaDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "AuditoriaDTO{" +
            "id=" + getId() +
            ", entityName='" + getEntityName() + "'" +
            ", usuarioLogin='" + getUsuarioLogin() + "'" +
            ", tipoCambio='" + getTipoCambio() + "'" +
            ", date='" + getDate() + "'" +
            ", entityId=" + getEntityId() +
            "}";
    }
}

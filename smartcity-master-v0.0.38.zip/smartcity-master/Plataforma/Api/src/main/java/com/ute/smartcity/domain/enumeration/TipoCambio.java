package com.ute.smartcity.domain.enumeration;

/**
 * The TipoCambio enumeration.
 */
public enum TipoCambio {
    ALTA, BAJA, MODIFICACION
}

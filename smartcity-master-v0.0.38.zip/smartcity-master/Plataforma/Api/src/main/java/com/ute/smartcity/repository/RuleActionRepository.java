package com.ute.smartcity.repository;

import com.ute.smartcity.domain.RuleAction;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the RuleAction entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RuleActionRepository extends JpaRepository<RuleAction, Long>, JpaSpecificationExecutor<RuleAction> {

}

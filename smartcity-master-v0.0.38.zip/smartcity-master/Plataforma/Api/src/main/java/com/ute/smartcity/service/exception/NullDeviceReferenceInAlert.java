package com.ute.smartcity.service.exception;

import com.ute.smartcity.service.dto.AlertDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NullDeviceReferenceInAlert extends Exception {
    private final Logger log = LoggerFactory.getLogger(NullDeviceReferenceInAlert.class);

    private String message;
    public NullDeviceReferenceInAlert(String message, AlertDTO alertDTO) {
        this.message = message;
        log.error(message + " - " + alertDTO);
    }

    @Override
    public String getMessage() {
        return message;
    }
}

package com.ute.smartcity.service.dto;

import com.ute.smartcity.domain.enumeration.EvaluationType;
import com.ute.smartcity.domain.enumeration.LevelRule;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A DTO for the Rule entity.
 */
public class RuleDTO implements Serializable {

    private Long id;

    @NotNull
    private String reference;

    @NotNull
    @Size(max = 250)
    private String description;

    @NotNull
    private LevelRule levelRule;

    @NotNull
    private EvaluationType evaluationType;

    private BigDecimal inactivityTime;

    @Size(max = 3500)
    private String textEPL;

    private ZonedDateTime createAt;

    private ZonedDateTime deleteAt;

    private ZonedDateTime updateAt;


    private Long deviceTypeId;

    private String deviceTypeName;

    private String deviceTypeType;

    private String deviceTypeReference;

    private Set<DeviceDTO> devices = new HashSet<DeviceDTO>();

    private Set<RuleCompareFieldsDTO> ruleCompareFields = new HashSet<RuleCompareFieldsDTO>();

    private Set<RuleActionDTO> ruleActions = new HashSet<RuleActionDTO>();


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LevelRule getLevelRule() {
        return levelRule;
    }

    public void setLevelRule(LevelRule levelRule) {
        this.levelRule = levelRule;
    }

    public EvaluationType getEvaluationType() {
        return evaluationType;
    }

    public void setEvaluationType(EvaluationType evaluationType) {
        this.evaluationType = evaluationType;
    }

    public BigDecimal getInactivityTime() {
        return inactivityTime;
    }

    public void setInactivityTime(BigDecimal inactivityTime) {
        this.inactivityTime = inactivityTime;
    }

    public String getTextEPL() {
        return textEPL;
    }

    public void setTextEPL(String textEPL) {
        this.textEPL = textEPL;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTime getDeleteAt() {
        return deleteAt;
    }

    public void setDeleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTime getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public Long getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(Long deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    public String getDeviceTypeName() {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    public Set<DeviceDTO> getDevices() {
        return devices;
    }

    public void setDevices(Set<DeviceDTO> devices) {
        this.devices = devices;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RuleDTO ruleDTO = (RuleDTO) o;
        if (ruleDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), ruleDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RuleDTO{" +
            "id=" + getId() +
            ", reference='" + getReference() + "'" +
            ", description='" + getDescription() + "'" +
            ", levelRule='" + getLevelRule() + "'" +
            ", evaluationType='" + getEvaluationType() + "'" +
            ", inactivityTime=" + getInactivityTime() +
            ", textEPL='" + getTextEPL() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", deleteAt='" + getDeleteAt() + "'" +
            ", updateAt='" + getUpdateAt() + "'" +
            ", deviceType=" + getDeviceTypeId() +
            ", deviceType='" + getDeviceTypeName() + "'" +
            ", deviceTypeType='" + getDeviceTypeType() + "'" +
            ", deviceTypeReference='" + getDeviceTypeReference() + "'" +
            "}";
    }

    public Set<RuleCompareFieldsDTO> getRuleCompareFields() {
        return ruleCompareFields;
    }

    public void setRuleCompareFields(Set<RuleCompareFieldsDTO> ruleCompareFields) {
        this.ruleCompareFields = ruleCompareFields;
    }

    public Set<RuleActionDTO> getRuleActions() {
        return ruleActions;
    }

    public void setRuleActions(Set<RuleActionDTO> ruleActions) {
        this.ruleActions = ruleActions;
    }

    public String getDeviceTypeType() {
        return deviceTypeType;
    }

    public void setDeviceTypeType(String deviceTypeType) {
        this.deviceTypeType = deviceTypeType;
    }

    public String getDeviceTypeReference() {
        return deviceTypeReference;
    }

    public void setDeviceTypeReference(String deviceTypeReference) {
        this.deviceTypeReference = deviceTypeReference;
    }
}

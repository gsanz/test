package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.AuditFiwarePlatformDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity AuditFiwarePlatform and its DTO AuditFiwarePlatformDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface AuditFiwarePlatformMapper extends EntityMapper<AuditFiwarePlatformDTO, AuditFiwarePlatform> {



    default AuditFiwarePlatform fromId(Long id) {
        if (id == null) {
            return null;
        }
        AuditFiwarePlatform auditFiwarePlatform = new AuditFiwarePlatform();
        auditFiwarePlatform.setId(id);
        return auditFiwarePlatform;
    }
}

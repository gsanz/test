package com.ute.smartcity.service;

import io.github.jhipster.service.QueryService;
import io.github.jhipster.service.filter.StringFilter;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;

/**
 * Servicio base para construir y ejecutar consultas complejas,
 * incluyendo búsquedas de texto en entidades relacionadas.
 * Hereda de {@link QueryService <ENTITY>}
 *
 * @param <ENTITY> es obligatorio y especifica el tipo de entidad
 */
@Transactional(readOnly = true)
public abstract class QueryServiceExtended<ENTITY> extends QueryService<ENTITY> {


    /**
     * Función Helper que devuelve una especificación para filtrar una referencia uno-a-uno o uno-a-muchos
     * para el caso en el que la propiedad destino sea de tipo {@link String}. Además de las condiciones básicas
     * de igual-a, menor-que, mayor-que, menor-o-igual, mayor-o-igual y null/not null, se extiende la condición
     * contiene, que no es sensible a mayúsculas y minúsculas. Uso:
     *
     * <pre>
     *   Specification&lt;Employee&gt; specByProjectName = buildReferringEntityStringSpecification(
     *      criteria.getProjectName(), Employee_.project, Project_.name);
     * </pre>
     *
     * @param filter     el objeto filtro que contiene el valor que se debe comprobar o un flag si hay que comprobal
     *                   el valor null.
     * @param reference  el atributo del metamodelo estático que contiene la entidad referente (entidad externa)
     * @param valueField el atributo del metamodelo estático que contiene la entidad referida (entidad anidad)
     *                   cuyo valor debe ser comprobado.
     * @param <OTHER>    tipo de la entidad referida
     * @return la especificación.
     */
    protected <OTHER>Specification<ENTITY> buildReferringEntityStringSpecification(
            StringFilter filter,
            SingularAttribute<? super ENTITY, OTHER> reference,
            SingularAttribute<OTHER, String> valueField) {
        if (filter.getEquals() != null) {
            return equalsSpecification(reference, valueField, filter.getEquals());
        } else if (filter.getContains() != null) {
            return likeUpperSpecification(reference, valueField, filter.getContains());
        } else if (filter.getIn() != null) {
            return valueIn(reference, valueField, filter.getIn());
        } else if (filter.getSpecified() != null) {
            return byFieldSpecified(reference, filter.getSpecified());
        }
        return null;
    }

    protected <OTHER>Specification<ENTITY> buildReferringEntityStringSpecification(
        StringFilter filter,
        SetAttribute<? super ENTITY, OTHER> reference,
        SingularAttribute<OTHER, String> valueField) {
        if(filter.getEquals() != null) {
            return equalsSetSpecification(reference, valueField, filter.getEquals());
        } else if (filter.getContains() != null) {
            return likeUpperSetSpecification(reference, valueField, filter.getContains());
        } else if (filter.getIn() != null) {
            return valueIn(reference, valueField, filter.getIn());
        } else if (filter.getSpecified() != null) {
            return byFieldSpecified((SetAttribute<ENTITY, OTHER>)reference, filter.getSpecified());
        }

        return null;
    }

    private <OTHER> Specification<ENTITY> likeUpperSetSpecification(SetAttribute<? super ENTITY, OTHER> reference,
                                                                    SingularAttribute<OTHER, String> valueField,
                                                                    final String value) {
        return (root, query, builder) -> builder.like(builder.upper(root.join(reference).get(valueField)), wrapLikeQuery(value));
    }

    protected <OTHER>Specification<ENTITY> likeUpperSpecification(SingularAttribute<? super ENTITY, OTHER> reference,
                                                                  SingularAttribute<OTHER, String> valueField,
                                                                  final String value) {
        return (root, query, builder) -> builder.like(builder.upper(root.get(reference).get(valueField)), wrapLikeQuery(value));
    }

}

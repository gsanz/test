package com.ute.smartcity.web.rest;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.User;
import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.security.SecurityUtils;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.*;
import com.ute.smartcity.service.exception.*;
import com.ute.smartcity.service.exception.fiware.HttpIOTAgentConnectionException;
import com.ute.smartcity.service.exception.fiware.HttpOrionConnectionException;
import com.ute.smartcity.service.exception.fiware.IOTAgentException;
import com.ute.smartcity.service.exception.fiware.OrionException;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.service.util.LatitudeLongitudeUtil;
import com.ute.smartcity.service.util.ValidatorUtil;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.errors.UnathorizedException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.web.util.ResponseUtil;
import io.swagger.annotations.Api;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import com.ute.smartcity.service.util.EncodeSymbols;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * REST controller for managing Device.
 */
@RestController
@RequestMapping("/api")
@Api(value = "device-resource", description = "Device Resource", tags = "device-resource")
public class DeviceResourceExt {
    private final Logger log = LoggerFactory.getLogger(DeviceResourceExt.class);

    private static final String ENTITY_NAME = "device";

    private final DeviceService deviceService;

    private final DeviceQueryService deviceQueryService;

    private final DeviceObservationsService observationsService;

    private final FieldsService fieldsService;

    private final HistoricalDeviceDataService historicalDeviceDataService;

    private final UserService userService;

    private final UsuarioService usuarioService;

    private final SmartCityPlatformService smartCityPlatformService;

    private final DeviceMapper deviceMapper;

    private final DeviceTypeService deviceTypeService;

    private final UpdateDeviceDataService updateDeviceDataService;

    private final ProviderService providerService;

    private final String PERMISSION_DENIED = "You do not have permission to retrieve this information.";

    private final String PERMISSION_KEY = "permission";

    private final String INVALID_LATITUDE_KEY = "latitudeInvalid";

    private final String INVALID_LONGITUDE_KEY = "longitudeInvalid";

    public static final Pattern REFERENCE_PATTERN =
        Pattern.compile("^[a-zA-Z0-9_]*$", Pattern.CASE_INSENSITIVE);

    public DeviceResourceExt(DeviceService deviceService, DeviceQueryService deviceQueryService,
                             DeviceObservationsService observationsService, FieldsService fieldsService,
                             HistoricalDeviceDataService historicalDeviceDataService, UserService userService,
                             UsuarioService usuarioService, UpdateDeviceDataService updateDeviceDataService,
                             SmartCityPlatformService smartCityPlatformService, DeviceMapper deviceMapper,
                             DeviceTypeService deviceTypeService, ProviderService providerService) {
        this.deviceService = deviceService;
        this.deviceQueryService = deviceQueryService;
        this.observationsService = observationsService;
        this.fieldsService = fieldsService;
        this.historicalDeviceDataService = historicalDeviceDataService;
        this.userService = userService;
        this.usuarioService = usuarioService;
        this.smartCityPlatformService = smartCityPlatformService;
        this.deviceMapper = deviceMapper;
        this.deviceTypeService = deviceTypeService;
        this.updateDeviceDataService = updateDeviceDataService;
        this.providerService = providerService;
    }

    /**
     * GET  /devices : get all the devices.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of devices in body
     */
    @GetMapping("/devices")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "','" + AuthoritiesConstants.PROVIDER + "')")
    public ResponseEntity<List<DeviceDTO>> getAllDevices(DeviceCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Devices by criteria: {}", criteria);
        // deviceList(criteria);
        boolean isProvider = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.PROVIDER);

        if(isProvider) {
            Optional<String> loggedUserName = SecurityUtils.getCurrentUserLogin();

            String userName = null;
            if(loggedUserName.isPresent()){
                userName = loggedUserName.get();
            }
            Optional<User> userByLogin = userService.getUserByLogin(userName);
            Long userId = null;
            if(userByLogin.isPresent()){
                userId = userByLogin.get().getId();
            }
            Optional<UsuarioDTO> usuarioOptional = usuarioService.findOne(userId);
            LongFilter longFilter = new LongFilter();

            Long providerId = null;
            if(usuarioOptional.isPresent()){
                providerId = usuarioOptional.get().getProviderId();
            }

            longFilter.setEquals(providerId);
            criteria.setProviderId(longFilter);
        }

        Page<DeviceDTO> page = deviceQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/devices");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    private void deviceList(DeviceCriteria criteria) {
        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);

        if(isAdmin) {
            return;
        }

        Optional<String> optionalUser = SecurityUtils.getCurrentUserLogin();

        if(!optionalUser.isPresent()) {
            return;
        }

        String userString = optionalUser.get();

        if(!userService.getUserWithAuthoritiesByLogin(userString).isPresent()) {
            throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
        }

        Optional<User> userOptional = userService.getUserWithAuthoritiesByLogin(userString);
        User userRequest = null;
        Optional<UsuarioDTO> usuarioOptional;
        if(userOptional.isPresent()) {
            userRequest = userOptional.get();

            usuarioOptional = usuarioService.findOne(userRequest.getId());
        } else {
            throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
        }

        List<Long> idsDevicesTypes = new ArrayList<Long>();
        if(usuarioOptional.isPresent()) {
            for (DeviceTypeDTO deviceTypeDTO : usuarioOptional.get().getDevicesTypes()) {
                idsDevicesTypes.add(deviceTypeDTO.getId());
            }
            if (idsDevicesTypes.size() > 0) {
                LongFilter longFilter = new LongFilter();
                longFilter.setIn(idsDevicesTypes);
                criteria.setDeviceTypeId(longFilter);
            }
        }
    }

    /**
     * GET  /devices : get all the devices.
     *
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of devices in body
     */
    @GetMapping("/devicesUnpaged")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<List<DeviceDTO>> getAllDevicesUnpaged(DeviceCriteria criteria) {
        log.debug("REST request to get Devices by criteria: {}", criteria);
        // deviceList(criteria);

        List<DeviceDTO> page = deviceQueryService.findByCriteria(criteria);
        //  HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/devicesUnpaged");
        return ResponseEntity.ok().body(page);
    }

    /**
     * GET  /devices/count : count all the devices.
     *
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the count in body
     */
    @GetMapping("/devices/count")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<Long> countDevices(DeviceCriteria criteria) {
        log.debug("REST request to count Devices by criteria: {}", criteria);
        deviceList(criteria);

        return ResponseEntity.ok().body(deviceQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /devices/:id : get the "id" device.
     *
     * @param id the id of the deviceDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the deviceDTO, or with status 404 (Not Found)
     */
    @GetMapping("/devices/{id}")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<DeviceDTO> getDevice(@PathVariable Long id) {
        log.debug("REST request to get Device : {}", id);
        Optional<DeviceDTO> deviceDTO = deviceService.findOne(id);

        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        Optional<String> optionalUser = SecurityUtils.getCurrentUserLogin();

        if(isAdmin) {
            return ResponseUtil.wrapOrNotFound(deviceDTO);
        }

        if (!optionalUser.isPresent()) {
            throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
        }

        String userString = optionalUser.get();

        if(!userService.getUserWithAuthoritiesByLogin(userString).isPresent() ) {
            throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
        }

        Optional<User> userByLogin = userService.getUserWithAuthoritiesByLogin(userString);
        User userRequest = null;

        if(userByLogin.isPresent()) {
            userRequest = userByLogin.get();
        }

        Optional<UsuarioDTO> usuarioOptional = Optional.empty();
        if(userRequest != null) {
            usuarioOptional = usuarioService.findOne(userRequest.getId());
        }

        if (!usuarioOptional.isPresent()) {
            throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
        }


        if(deviceDTO.isPresent()) {
            for (DeviceTypeDTO deviceTypeDTO : usuarioOptional.get().getDevicesTypes()) {

                if (deviceDTO.get().getDeviceTypeId().equals(deviceTypeDTO.getId())) {
                    return ResponseUtil.wrapOrNotFound(deviceDTO);

                }

            }
        }
        throw new UnathorizedException(PERMISSION_DENIED, ENTITY_NAME, PERMISSION_KEY);
    }

    /**
     * GET  /devices/:id/data : get the "id" data device.
     *
     * @param id the id of the data of deviceDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the deviceDTO, or with status 404 (Not Found)
     */
    @GetMapping("/devices/{id}/fields")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<List<FieldsDTO>> getFieldsData(@PathVariable Long id) {
        log.debug("REST request to get Device : {}", id);
        Optional<List<FieldsDTO>> list = fieldsService.findByDeviceId(id);
        return ResponseUtil.wrapOrNotFound(list);
    }

    /**
     * GET  /devices/:id : get the "id" device.
     *
     * @param id the id of the deviceDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the deviceDTO, or with status 404 (Not Found)
     */
    @GetMapping("/devices/{id}/observations")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "','" + AuthoritiesConstants.PROVIDER + "')")
    public ResponseEntity<List<JSONObject>> getDeviceObservations(@PathVariable Long id, DeviceObservationCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Device observations : {}", id);
        Page<JSONObject> page = null;
        Optional<DeviceDTO> deviceDTOOptional = deviceService.findOne(id);
        if (!deviceDTOOptional.isPresent()) {
            throw new BadRequestAlertException("Device does not exists", ENTITY_NAME, "");
        }

        boolean isProvider = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.PROVIDER);

        if(isProvider) {
            Optional<String> loggedUserName = SecurityUtils.getCurrentUserLogin();

            String userName = null;
            if(loggedUserName.isPresent()){
                userName = loggedUserName.get();
            }
            Optional<User> userByLogin = userService.getUserByLogin(userName);

            Long userbyLoginId = null;
            if(userByLogin.isPresent()){
                userbyLoginId = userByLogin.get().getId();
            }
            Optional<UsuarioDTO> usuarioOptional = usuarioService.findOne(userbyLoginId);
            LongFilter longFilter = new LongFilter();

            Long providerId = null;
            if(usuarioOptional.isPresent()){
                providerId = usuarioOptional.get().getProviderId();
            }
            longFilter.setEquals(providerId);
            criteria.setProviderId(longFilter);
        }

        DeviceDTO deviceDTO = deviceDTOOptional.get();
        criteria.setDevice(deviceDTO.getReference());
        criteria.setDeviceType(deviceDTO.getDeviceTypeType());
        page = observationsService.findAll(deviceDTO, criteria, pageable, "recvTime");


        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/devices/" + id.toString() + "/observations");
        return ResponseEntity.ok().headers(headers).body(page.getContent());

    }

    /**
     * GET  /devices/:id : get the "id" device.
     *
     * @param id the id of the deviceDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the deviceDTO, or with status 404 (Not Found)
     */
    @GetMapping("/devices/{id}/historical-data")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.USER + "')")
    public ResponseEntity<HistoricalDeviceDataDTO> getHistoricalData(@PathVariable Long id, @RequestParam String dateFieldToFilter, DeviceObservationCriteria criteria, Pageable page) {
        log.debug("REST request to get Device observations : {}", id, dateFieldToFilter);
        Optional<HistoricalDeviceDataDTO> historicalDataDevice = null;
        try{
             historicalDataDevice = historicalDeviceDataService.getHistoricalDataDevice(id, criteria, page, dateFieldToFilter);
        }catch (DataAccessResourceFailureException e) {
            throw new BadRequestAlertException("There was an error trying to connect with fiware", ENTITY_NAME, "fail-connect-orion");
        }

        return ResponseUtil.wrapOrNotFound(historicalDataDevice);
    }

    /**
     * POST  /devices : Create a new device.
     *
     * @param deviceDTO the deviceDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new deviceDTO, or with status 400 (Bad Request) if the device has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/devices")
    @Transactional
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<DeviceDTO> createDevice(@Valid @RequestBody DeviceDTO deviceDTO) throws URISyntaxException {
        if(deviceDTO.getLocation() == null || deviceDTO.getLocation().equals("")) {
            deviceDTO.setLocation(" ");
        }

        boolean isProvider = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.PROVIDER);

        if(isProvider) {
            throw new AccessDeniedException("403");
        }

        HttpHeaders headers = null;
        log.debug("REST request to save Device : {}", deviceDTO);
        Optional<Device> deviceOptional = deviceService.findByReference(deviceDTO.getReference());

        if(deviceDTO.getId() != null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idexists");
        }
        if (deviceOptional.isPresent()) {
            throw new BadRequestAlertException("A new device cannot already have a Reference", ENTITY_NAME, "referenceexists");
        }
        String name = deviceDTO.getName().trim();
        if (deviceDTO.getName() == null || deviceDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("A device needs a name", ENTITY_NAME, "noname");
        }
        String reference = deviceDTO.getReference().trim();
        if (deviceDTO.getReference() == null || deviceDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("A device needs a reference", ENTITY_NAME, "noreference");
        }
        String latitude = deviceDTO.getLatitude().trim();
        if (deviceDTO.getLatitude() == null || deviceDTO.getLatitude().equals("") || latitude.length() <= 0) {
            throw new BadRequestAlertException("A device needs a latitude", ENTITY_NAME, INVALID_LATITUDE_KEY);
        }
        String longitude = deviceDTO.getLongitude().trim();
        if (deviceDTO.getLongitude() == null || deviceDTO.getLongitude().equals("") || longitude.length() <= 0) {
            throw new BadRequestAlertException("A device needs a longitude", ENTITY_NAME, INVALID_LONGITUDE_KEY);
        }
        if (deviceDTO.getDeviceTypeId() == null ) {
            throw new BadRequestAlertException("A device needs a device type", ENTITY_NAME, "notype");
        }
        if (deviceDTO.getFields().size() ==0 ){

            Optional<List<FieldsDTO>> fieldsDTOList = fieldsService.findByDeviceTypeId(deviceDTO.getDeviceTypeId());
            if (fieldsDTOList.isPresent()){

                List<FieldsDTO> fieldsDTOS = fieldsDTOList.get();
                deviceDTO.setFields(new HashSet(fieldsDTOS));
            }
        }
        ValidatorUtil validator = new ValidatorUtil();

        if (!validator.validate(reference, REFERENCE_PATTERN)) {
            log.debug("Invalid reference: " + reference + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Bad reference characters", ENTITY_NAME, "referenceInvalid");
        }
        validateLatitudeLongitude(deviceDTO.getLatitude(), deviceDTO.getLongitude());

       /* EncodeSymbols encodeSymbols = new EncodeSymbols();
        deviceDTO = encodeSymbols.checkEncode(deviceDTO);
    */
        DeviceDTO result = deviceService.save(deviceDTO);
        Optional<DeviceTypeDTO> deviceTypeDTOOptional = deviceTypeService.findOne(deviceDTO.getDeviceTypeId());
        DeviceTypeDTO deviceTypeDTO = null;
        if(deviceTypeDTOOptional.isPresent()) {
            deviceTypeDTO = deviceTypeDTOOptional.get();
        }
        if(deviceTypeDTO != null) {
            result.setDeviceTypeReference(deviceTypeDTO.getReference());
            result.setDeviceTypeName(deviceTypeDTO.getName());
            result.setDeviceTypeType(deviceTypeDTO.getType());
        }

        headers = HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString());

        try {
            smartCityPlatformService.addDevice(result);
        }
        catch (PlatformException e){
            log.error("PlatormException" , e.getMessage());
            throw new BadRequestAlertException("There was an error trying to save the device to fiware", ENTITY_NAME, "fail-save-orion-device");
        }
        catch (Exception e){
            log.error("PlatormException" , e.getMessage());
            throw new BadRequestAlertException("There was an error trying to save the device to fiware", ENTITY_NAME, "fail-save-orion-device");
        }


        return ResponseEntity.created(new URI("/api/devices/" + result.getId()))
            .headers(headers)
            .body(result);
    }
    /**
     * POST  /devices : Create a new device.
     *
     * @param reference the deviceDTO to update data
     * @return the ResponseEntity with status 201 (Created) and with body the new deviceDTO, or with status 400 (Bad Request) if the device has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/devices/{reference}/data")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.PROVIDER + "')")
    public void UpdataDeviceData(@PathVariable String reference,@RequestBody  String data)  {
        log.debug("REST request to UpdataDeviceData Device : {}", reference);
        boolean isProvider = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.PROVIDER);

        Optional<Device> deviceOptional = deviceService.findByReference(reference);
        if(!deviceOptional.isPresent()) {
            log.debug("REST request to UpdataDeviceData Device : {There is no device with reference: {} }", reference);
            throw new BadRequestAlertException("There is no device with such reference", ENTITY_NAME, "referenceDoesntexist");
        }

        Device deviceDTO = deviceOptional.get();
        if(isProvider) {
            Optional<String> loggedUserName = SecurityUtils.getCurrentUserLogin();

            String userName = null;
            if(loggedUserName.isPresent()){
                userName = loggedUserName.get();
            }
            Optional<User> userByLogin = userService.getUserByLogin( userName );

            Long userByLoginId = null;
            if(userByLogin.isPresent()){
                userByLoginId = userByLogin.get().getId();
            }
            Optional<UsuarioDTO> usuarioOptional = usuarioService.findOne(userByLoginId);

            Long providerId = null;
            if(usuarioOptional.isPresent()){
                providerId = usuarioOptional.get().getProviderId();
            }
            Optional<ProviderDTO> provider = providerService.findOne(providerId);

            //If device provider id != providerId or provider dont exist -> FORBIDDEN
            if (provider.isPresent() && (deviceDTO.getProvider() == null || !deviceDTO.getProvider().getId().equals(provider.get().getId()))){
                throw new AccessDeniedException("403");
            }
        }
        try {
            updateDeviceDataService.updateDeviceData(deviceDTO, data, reference);
        } catch (HttpOrionConnectionException ex) {
            throw new BadRequestAlertException(ex.getMessage(), ENTITY_NAME, "orionoffline");
        } catch (Exception e) {
            log.debug("REST request to UpdataDeviceData Device : Something went wrong {} {}", reference, data);
            throw new BadRequestAlertException("Something went wrong", ENTITY_NAME, "referenceexists");
        }

    }
    /**
     * PUT  /devices : Updates an existing device.
     *
     * @param deviceDTO the deviceDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated deviceDTO,
     * or with status 400 (Bad Request) if the deviceDTO is not valid,
     * or with status 500 (Internal Server Error) if the deviceDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/devices")
    @ResourceAudit(ENTITY_NAME)
    @Transactional
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<DeviceDTO> updateDevice(@Valid @RequestBody DeviceDTO deviceDTO) {
        log.debug("REST request to update Device : {}", deviceDTO);

        boolean isProvider = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.PROVIDER);

        if(deviceDTO.getLocation() == null || deviceDTO.getLocation().equals("")) {
            deviceDTO.setLocation(" ");
        }

        if(isProvider) {
            throw new AccessDeniedException("403");
        }

        if (deviceDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String name = deviceDTO.getName().trim();
        if (deviceDTO.getName() == null || deviceDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("A device needs a name", ENTITY_NAME, "noname");
        }
        String reference = deviceDTO.getReference().trim();
        if (deviceDTO.getReference() == null || deviceDTO.getReference().equals("") || reference.length() <= 0) {
            throw new BadRequestAlertException("A device needs a reference", ENTITY_NAME, "noreference");
        }
        String latitude = deviceDTO.getLatitude().trim();
        if (deviceDTO.getLatitude() == null || deviceDTO.getLatitude().equals("") || latitude.length() <= 0) {
            throw new BadRequestAlertException("A device needs a latitude", ENTITY_NAME, INVALID_LATITUDE_KEY);
        }
        String longitude = deviceDTO.getLongitude().trim();
        if (deviceDTO.getLongitude() == null || deviceDTO.getLongitude().equals("") || longitude.length() <= 0) {
            throw new BadRequestAlertException("A device needs a longitude", ENTITY_NAME, INVALID_LONGITUDE_KEY);
        }
        if (deviceDTO.getDeviceTypeId() == null ) {
            throw new BadRequestAlertException("A device needs a device type", ENTITY_NAME, "notype");
        }

        ValidatorUtil validator = new ValidatorUtil();

        if (!validator.validate(reference, REFERENCE_PATTERN)) {
            log.debug("Invalid reference: " + reference + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Bad reference characters", ENTITY_NAME, "referenceInvalid");
        }

        validateLatitudeLongitude(deviceDTO.getLatitude(), deviceDTO.getLongitude());

        Optional<DeviceDTO> actualDevice = deviceService.findOne(deviceDTO.getId());
        if(!actualDevice.isPresent()) {
            throw new BadRequestAlertException("Device in not present, not found", ENTITY_NAME, "editreference");
        }

        boolean hasInvalidChanges = !(actualDevice.get().getReference().equals(deviceDTO.getReference())) ||
            !(actualDevice.get().getDeviceTypeId().equals(deviceDTO.getDeviceTypeId()));

        if (hasInvalidChanges) {
            throw new BadRequestAlertException("The modification of these fields is not allowed", ENTITY_NAME, "editreference");
        }

       /* EncodeSymbols encodeSymbols = new EncodeSymbols();
        deviceDTO = encodeSymbols.checkEncode(deviceDTO);*/

        deviceDTO.setUpdateAt(ZonedDateTime.now());
        DeviceDTO result = deviceService.save(deviceDTO);
        HttpHeaders headers =  HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, deviceDTO.getId().toString());

        try {
            smartCityPlatformService.updateDevice(deviceDTO);
        } catch (PlatformException e) {
            log.error("PlatormException" , e.getMessage());
            throw new BadRequestAlertException("There was an error trying to save the device to fiware", ENTITY_NAME, "fail-save-orion-device");
        }

        return ResponseEntity.ok()
            .headers(headers)
            .body(result);
    }
    /**
     * DELETE  /devices/:id : delete the "id" device.
     *
     * @param id the id of the deviceDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/devices/{id}")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<Void> deleteDevice(@PathVariable Long id) {
        log.debug("REST request to delete Device : {}", id);
        boolean isProvider = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.PROVIDER);

        if(isProvider) {
            throw new AccessDeniedException("403");
        }

        Optional<DeviceDTO> optionalDeviceDTO = deviceService.findOne(id);
        if(optionalDeviceDTO.isPresent()) {
            Device device = deviceMapper.toEntity(optionalDeviceDTO.get());

            long idDeviceType = device.getDeviceType().getId();
            Optional<DeviceTypeDTO> deviceTypeDTOOptional = deviceTypeService.findOne(idDeviceType);

            if(deviceTypeDTOOptional.isPresent()) {
                device.getDeviceType().setId(deviceTypeDTOOptional.get().getId());
                device.getDeviceType().setReference(deviceTypeDTOOptional.get().getReference());
                String reference = device.getReference();
                String servicepath = device.getDeviceType().getReference();
                try {

                    smartCityPlatformService.removeDevice(reference, servicepath);
                    smartCityPlatformService.removeIoTDevice(optionalDeviceDTO.get());
                } catch (PlatformException e) {
                    log.error("PlatormException" , e.getMessage());
                    throw new BadRequestAlertException("There was an error trying to delete the device from fiware", ENTITY_NAME, "fail-delete-orion-device");
                }

            }else{
                log.error("El dispositivo no tiene asignado ningun tipo");
            }
        }else{
            log.error("El dispositivo no existe");
        }
        deviceService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    private void validateLatitudeLongitude(String latitude, String longitude) {
        if (!LatitudeLongitudeUtil.isValidLatitude(latitude)) {
            log.debug("Invalid latitude: " + latitude + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Invalid latitude", ENTITY_NAME, INVALID_LATITUDE_KEY);
        } else if (!LatitudeLongitudeUtil.isValidLongitude(longitude)) {
            log.debug("Invalid longitude: " + longitude + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Invalid latitude", ENTITY_NAME, INVALID_LONGITUDE_KEY);
        }
    }
}

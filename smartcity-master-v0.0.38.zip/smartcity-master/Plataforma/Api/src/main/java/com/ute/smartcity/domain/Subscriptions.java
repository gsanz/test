package com.ute.smartcity.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A Subscriptions.
 */
@Entity
@Table(name = "subscriptions")
public class Subscriptions implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "description", nullable = false)
    private String description;

    @NotNull
    @Column(name = "endpoint", nullable = false)
    private String endpoint;

    @Column(name = "platform_id")
    private String platformId;

    @Column(name = "create_at")
    private ZonedDateTime createAt;

    @Column(name = "state")
    private String state;

    @ManyToOne
    @JsonIgnoreProperties("subscriptions")
    private DeviceType deviceType;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Subscriptions name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public Subscriptions description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public Subscriptions endpoint(String endpoint) {
        this.endpoint = endpoint;
        return this;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getPlatformId() {
        return platformId;
    }

    public Subscriptions platformId(String platformId) {
        this.platformId = platformId;
        return this;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public Subscriptions createAt(ZonedDateTime createAt) {
        this.createAt = createAt;
        return this;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public String getState() {
        return state;
    }

    public Subscriptions state(String state) {
        this.state = state;
        return this;
    }

    public void setState(String state) {
        this.state = state;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public Subscriptions deviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
        return this;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Subscriptions subscriptions = (Subscriptions) o;
        if (subscriptions.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), subscriptions.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Subscriptions{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", endpoint='" + getEndpoint() + "'" +
            ", platformId='" + getPlatformId() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", state='" + getState() + "'" +
            "}";
    }
}

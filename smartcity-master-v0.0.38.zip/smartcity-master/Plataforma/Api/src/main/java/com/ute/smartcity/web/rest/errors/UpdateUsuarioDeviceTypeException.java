package com.ute.smartcity.web.rest.errors;

public class UpdateUsuarioDeviceTypeException extends BadRequestAlertException {

    private static final long serialVersionUID = 1L;

    public UpdateUsuarioDeviceTypeException() {
        super("Error updating Usuario!", "usuario", "devicesTypesNotFound");
    }
}

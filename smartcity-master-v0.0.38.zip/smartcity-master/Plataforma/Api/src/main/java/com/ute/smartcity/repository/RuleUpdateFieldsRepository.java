package com.ute.smartcity.repository;

import com.ute.smartcity.domain.RuleUpdateFields;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the RuleUpdateFields entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RuleUpdateFieldsRepository extends JpaRepository<RuleUpdateFields, Long>, JpaSpecificationExecutor<RuleUpdateFields> {

}

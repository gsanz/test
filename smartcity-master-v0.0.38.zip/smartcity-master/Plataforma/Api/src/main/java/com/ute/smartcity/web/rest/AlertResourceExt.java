package com.ute.smartcity.web.rest;

import com.ute.smartcity.domain.Alert;
import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.enumeration.AlertState;
import com.ute.smartcity.domain.enumeration.CriticalityLevel;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.AlertCriteria;
import com.ute.smartcity.service.dto.AlertDTO;
import com.ute.smartcity.service.exception.DeviceNotInRuleException;
import com.ute.smartcity.service.exception.DeviceNotPresentException;
import com.ute.smartcity.service.exception.NullDeviceReferenceInAlert;
import com.ute.smartcity.service.mapper.AlertMapper;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@Api(value="alerts", description="Alert Resource",tags = "alert-resource")
public class AlertResourceExt {
    private final Logger log = LoggerFactory.getLogger(AlertResourceExt.class);

    private static final String ENTITY_NAME = "alert";

    private final AlertService alertService;

    private final AlertValidator alertValidator;

    private final AlertMapper alertMapper;

    private final AlertQueryService alertQueryService;

    private final MailService mailService;

    private final DeviceService deviceService;

    public AlertResourceExt(AlertService alertService, AlertValidator alertValidator, AlertMapper alertMapper, AlertQueryService alertQueryService, MailService mailService, DeviceService deviceService) {
        this.alertService = alertService;
        this.alertValidator = alertValidator;
        this.alertMapper = alertMapper;
        this.alertQueryService = alertQueryService;
        this.mailService = mailService;
        this.deviceService = deviceService;
    }

    /**
     * POST  /alerts : Create a new alert.
     *
     * @param alertDTO the alertDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new alertDTO, or with status 400 (Bad Request) if the alert has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/alerts")
    @ResourceAudit(ENTITY_NAME)
    public ResponseEntity<AlertDTO> createAlert(@Valid @RequestBody AlertDTO alertDTO) throws URISyntaxException {
        log.debug("REST request to save Alert : {}", alertDTO);
        if (alertDTO.getId() != null) {
            throw new BadRequestAlertException("A new alert cannot already have an ID", ENTITY_NAME, "idexists");
        }

        try{
            AlertDTO checkedAlertDTO = alertValidator.validate(alertDTO);
            AlertDTO result = alertService.save(checkedAlertDTO);

            Optional<Device> device = this.deviceService.findByReference(alertDTO.getDeviceReference());
            if (device.isPresent()) {
                Alert alert = alertMapper.toEntity(alertDTO);
                alert.setDevice(device.get());
                mailService.sendAlertMail(alert);
            }


            return ResponseEntity.created(new URI("/api/alerts/" + result.getId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
                .body(result);

        } catch (NullDeviceReferenceInAlert e) {
            throw new BadRequestAlertException(e.getMessage(), ENTITY_NAME, "alertDoesNotHaveDeviceReference");
        } catch (DeviceNotPresentException e) {
            throw new BadRequestAlertException(e.getMessage(), ENTITY_NAME, "deviceNotPresent");
        } catch (DeviceNotInRuleException e) {
            throw new BadRequestAlertException(e.getMessage(), ENTITY_NAME, "deviceNotInRule");
        }
    }

    /**
     * PUT  /alerts : Updates an existing alert.
     *
     * @param alertDTO the alertDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated alertDTO,
     * or with status 400 (Bad Request) if the alertDTO is not valid,
     * or with status 500 (Internal Server Error) if the alertDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/alerts")
    @ResourceAudit(ENTITY_NAME)
    public ResponseEntity<AlertDTO> updateAlert(@Valid @RequestBody AlertDTO alertDTO) throws URISyntaxException {
        log.debug("REST request to update Alert : {}", alertDTO);
        if (alertDTO.getId() == null) {
            return createAlert(alertDTO);
        }

        Optional<AlertDTO> oldAlertDTO = alertService.findOne(alertDTO.getId());

        Long alertDtoId = null;
        if(oldAlertDTO.isPresent()){
            alertDtoId = oldAlertDTO.get().getId();
        }

        alertDTO.setId(alertDtoId);

        String reference = null;
        if(oldAlertDTO.isPresent()){
            reference = oldAlertDTO.get().getReference();
        }

        alertDTO.setReference(reference);

        Long deviceId = null;
        if(oldAlertDTO.isPresent()){
            deviceId = oldAlertDTO.get().getDeviceId();
        }

        alertDTO.setDeviceId(deviceId);

        String deviceName = "";
        if(oldAlertDTO.isPresent()){
            deviceName = oldAlertDTO.get().getDeviceName();
        }
        alertDTO.setDeviceName(deviceName);

        String deviceReference = null;
        if(oldAlertDTO.isPresent()){
            deviceReference = oldAlertDTO.get().getDeviceReference();
        }
        alertDTO.setDeviceReference(deviceReference);

        String description = null;
        if(oldAlertDTO.isPresent()){
            description = oldAlertDTO.get().getDescription();
        }
        alertDTO.setDescription(description);

        CriticalityLevel criticalityLevel = null;
        if(oldAlertDTO.isPresent()){
            criticalityLevel = oldAlertDTO.get().getCriticalityLevel();
        }
        alertDTO.setCriticalityLevel(criticalityLevel);

        AlertDTO result = alertService.save(alertDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, alertDTO.getId().toString()))
            .body(result);
    }
    /**
     * PUT  /alerts : change the state of alert to close
     *
     * @param id of alert to close
     * @return the ResponseEntity with status 200 (OK) and with body the updated alert,
     * or with status 400 (Bad Request) if the alert is not valid,
     * or with status 500 (Internal Server Error) if the alert couldn't be updated
     */
    @PutMapping("/alerts/{id}/close")
    @Timed
    @ResourceAudit(ENTITY_NAME)
    public ResponseEntity<AlertDTO> closeAlert(@PathVariable Long id) {
        try {
            log.debug("REST request to close alert : {}", id);

            Optional<AlertDTO> alert = alertService.findOne(id);

            if(alert.isPresent()){
                AlertDTO alertDTO = alert.get();
                alertDTO.setState(AlertState.CLOSE);
                alertService.save(alertDTO);

                return ResponseEntity.ok()
                    .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, alertDTO.getId().toString()))
                    .body(alertDTO);
            }else{
                throw new BadRequestAlertException("Alert not found. ", ENTITY_NAME, "bad request");
            }
        }
        catch(Exception ex) {
            log.error("DesactivarSesion", "Unexpected exception was thrown.", ex);
            throw new BadRequestAlertException("sutaxiApp.DesactivarSesion.error.unexpectedError", "CloseAlert", "Unexpected exception was thrown.");
        }
    }

    /**
     * GET  /alerts/count : count all the providers.
     *
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the count in body
     */
    @GetMapping("/alerts/count")
    public ResponseEntity<Long> countAlerts(AlertCriteria criteria) {
        log.debug("REST request to count Alerts by criteria: {}", criteria);
        AlertCriteria.AlertStateFilter alertStateFilter = new AlertCriteria.AlertStateFilter();
        alertStateFilter.setEquals(AlertState.OPEN);
        criteria.setState(alertStateFilter);
        return ResponseEntity.ok().body(alertQueryService.countByCriteria(criteria));
    }
}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.service.RuleActionService;
import com.ute.smartcity.domain.RuleAction;
import com.ute.smartcity.repository.RuleActionRepository;
import com.ute.smartcity.service.dto.RuleActionDTO;
import com.ute.smartcity.service.mapper.RuleActionMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing RuleAction.
 */
@Service
@Transactional
public class RuleActionServiceImpl implements RuleActionService {

    private final Logger log = LoggerFactory.getLogger(RuleActionServiceImpl.class);

    private final RuleActionRepository ruleActionRepository;

    private final RuleActionMapper ruleActionMapper;

    public RuleActionServiceImpl(RuleActionRepository ruleActionRepository, RuleActionMapper ruleActionMapper) {
        this.ruleActionRepository = ruleActionRepository;
        this.ruleActionMapper = ruleActionMapper;
    }

    /**
     * Save a ruleAction.
     *
     * @param ruleActionDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public RuleActionDTO save(RuleActionDTO ruleActionDTO) {
        log.debug("Request to save RuleAction : {}", ruleActionDTO);
        RuleAction ruleAction = ruleActionMapper.toEntity(ruleActionDTO);
        ruleAction = ruleActionRepository.save(ruleAction);
        return ruleActionMapper.toDto(ruleAction);
    }

    /**
     * Get all the ruleActions.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<RuleActionDTO> findAll(Pageable pageable) {
        log.debug("Request to get all RuleActions");
        return ruleActionRepository.findAll(pageable)
            .map(ruleActionMapper::toDto);
    }


    /**
     * Get one ruleAction by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<RuleActionDTO> findOne(Long id) {
        log.debug("Request to get RuleAction : {}", id);
        return ruleActionRepository.findById(id)
            .map(ruleActionMapper::toDto);
    }

    /**
     * Delete the ruleAction by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete RuleAction : {}", id);
        ruleActionRepository.deleteById(id);
    }
}

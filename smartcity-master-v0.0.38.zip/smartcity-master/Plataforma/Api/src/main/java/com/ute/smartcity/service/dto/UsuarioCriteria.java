package com.ute.smartcity.service.dto;

import java.io.Serializable;
import java.util.Objects;

import io.github.jhipster.service.filter.*;

/**
 * Criteria class for the Usuario entity. This class is used in UsuarioResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /usuarios?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class UsuarioCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter phone;

    private BooleanFilter doubleFactorAuthentication;

    private LongFilter userId;

    private LongFilter devicesTypesId;

    private StringFilter searchText;

    private StringFilter doubleAuthKey;

    private ZonedDateTimeFilter createAtDoubleAuthKey;

    private ZonedDateTimeFilter lastPasswordDate;

    private IntegerFilter numberAttemptsDoubleAuth;

    public UsuarioCriteria() {
    }

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getPhone() {
        return phone;
    }

    public void setPhone(StringFilter phone) {
        this.phone = phone;
    }

    public BooleanFilter getDoubleFactorAuthentication() {
        return doubleFactorAuthentication;
    }

    public void setDoubleFactorAuthentication(BooleanFilter doubleFactorAuthentication) {
        this.doubleFactorAuthentication = doubleFactorAuthentication;
    }

    public LongFilter getUserId() {
        return userId;
    }

    public void setUserId(LongFilter userId) {
        this.userId = userId;
    }

    public LongFilter getDevicesTypesId() {
        return devicesTypesId;
    }

    public void setDevicesTypesId(LongFilter devicesTypesId) {
        this.devicesTypesId = devicesTypesId;
    }

    public StringFilter getSearchText() {
        return searchText;
    }

    public void setSearchText(StringFilter searchText) {
        this.searchText = searchText;
    }

    public StringFilter getDoubleAuthKey() {
        return doubleAuthKey;
    }

    public void setDoubleAuthKey(StringFilter doubleAuthKey) {
        this.doubleAuthKey = doubleAuthKey;
    }

    public ZonedDateTimeFilter getCreateAtDoubleAuthKey() {
        return createAtDoubleAuthKey;
    }

    public void setCreateAtDoubleAuthKey(ZonedDateTimeFilter createAtDoubleAuthKey) {
        this.createAtDoubleAuthKey = createAtDoubleAuthKey;
    }

    public IntegerFilter getNumberAttemptsDoubleAuth() {
        return numberAttemptsDoubleAuth;
    }

    public void setNumberAttemptsDoubleAuth(IntegerFilter numberAttemptsDoubleAuth) {
        this.numberAttemptsDoubleAuth = numberAttemptsDoubleAuth;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final UsuarioCriteria that = (UsuarioCriteria) o;
        return
            Objects.equals(id, that.id) &&
                Objects.equals(phone, that.phone) &&
                Objects.equals(doubleFactorAuthentication, that.doubleFactorAuthentication) &&
                Objects.equals(userId, that.userId) &&
                Objects.equals(devicesTypesId, that.devicesTypesId) &&
                Objects.equals(doubleAuthKey, that.doubleAuthKey) &&
                Objects.equals(createAtDoubleAuthKey, that.createAtDoubleAuthKey) &&
                Objects.equals(lastPasswordDate, that.lastPasswordDate) &&
                Objects.equals(numberAttemptsDoubleAuth, that.numberAttemptsDoubleAuth) &&
                Objects.equals(searchText, that.searchText);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            id,
            phone,
            doubleFactorAuthentication,
            userId,
            devicesTypesId,
            doubleAuthKey,
            createAtDoubleAuthKey,
            lastPasswordDate,
            numberAttemptsDoubleAuth,
            searchText
            );
    }

    @Override
    public String toString() {
        return "UsuarioCriteria{" +
            (id != null ? "id=" + id + ", " : "") +
            (phone != null ? "phone=" + phone + ", " : "") +
            (doubleFactorAuthentication != null ? "doubleFactorAuthentication=" + doubleFactorAuthentication + ", " : "") +
            (userId != null ? "userId=" + userId + ", " : "") +
            (devicesTypesId != null ? "devicesTypesId=" + devicesTypesId + ", " : "") +
            (doubleAuthKey != null ? "doubleAuthKey=" + doubleAuthKey + ", " : "") +
            (createAtDoubleAuthKey != null ? "createAtDoubleAuthKey=" + createAtDoubleAuthKey + ", " : "") +
            (lastPasswordDate != null ? "lastPasswordDate=" + lastPasswordDate + ", " : "") +
            (numberAttemptsDoubleAuth != null ? "numberAttemptsDoubleAuth=" + numberAttemptsDoubleAuth + ", " : "") +
            (searchText != null ? "searchText=" + searchText + ", " : "") +
            "}";
    }

    public ZonedDateTimeFilter getLastPasswordDate() {
        return lastPasswordDate;
    }

    public void setlLastPasswordDate(ZonedDateTimeFilter lastPasswordDate) {
        this.lastPasswordDate = lastPasswordDate;
    }
}

package com.ute.smartcity.service.platform.generic;

import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.SubscriptionsDTO;
import com.ute.smartcity.service.exception.*;
import com.ute.smartcity.service.exception.fiware.HttpIOTAgentConnectionException;
import com.ute.smartcity.service.exception.fiware.HttpOrionConnectionException;
import com.ute.smartcity.service.exception.fiware.IOTAgentException;
import com.ute.smartcity.service.exception.fiware.OrionException;
import com.ute.smartcity.service.exception.platform.PlatformException;

import java.util.List;

public interface SmartCityPlatformService {

    public void addDevice(DeviceDTO deviceDTO) throws PlatformException;
    public void updateDevice(DeviceDTO deviceDTO)throws PlatformException;
    public void removeDevice(String reference, String servicepath)throws PlatformException;
    public void updateDeviceData(String json, String data, String servicePathRef) throws HttpOrionConnectionException, OrionException;

    public void updateIoTDevice(DeviceDTO deviceDTO) throws IOTAgentException, HttpIOTAgentConnectionException, NullDevicePropertyException, PlatformException;
    public void addIoTDevice(DeviceDTO deviceDTO) throws IOTAgentException, HttpIOTAgentConnectionException, NullDevicePropertyException, PlatformException;
    public void removeIoTDevice(DeviceDTO deviceDTO) throws PlatformException;

    public String getAllDevices() throws HttpOrionConnectionException, OrionException;

    public void addSubscription(SubscriptionsDTO subscriptionsDTO);
    public List<SubscriptionsDTO> addSubscriptions(List<SubscriptionsDTO> subscriptionsDTOList) throws PlatformException;
    public void deleteSubscription(SubscriptionsDTO subscriptionsDTO) throws PlatformException;
}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.Subscriptions;
import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.repository.SubscriptionsRepository;
import com.ute.smartcity.repository.UsuarioRepository;
import com.ute.smartcity.service.DeviceTypeService;
import com.ute.smartcity.domain.DeviceType;
import com.ute.smartcity.repository.DeviceTypeRepository;
import com.ute.smartcity.service.SubscriptionTemplateService;
import com.ute.smartcity.service.dto.DeviceTypeDTO;
import com.ute.smartcity.service.dto.SubscriptionTemplateDTO;
import com.ute.smartcity.service.dto.SubscriptionsDTO;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.service.mapper.DeviceTypeMapper;
import com.ute.smartcity.service.mapper.SubscriptionsMapper;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * Service Implementation for managing DeviceType.
 */
@Service
@Transactional
public class DeviceTypeServiceImpl implements DeviceTypeService {

    private final Logger log = LoggerFactory.getLogger(DeviceTypeServiceImpl.class);

    private final DeviceTypeRepository deviceTypeRepository;

    private final DeviceTypeMapper deviceTypeMapper;

    private final SmartCityPlatformService smartCityPlatformService;

    private final SubscriptionTemplateService subscriptionTemplateService;

    private final SubscriptionsMapper subscriptionsMapper;

    private final SubscriptionsRepository subscriptionsRepository;

    private final UsuarioRepository usuarioRepository;

    public DeviceTypeServiceImpl(DeviceTypeRepository deviceTypeRepository, DeviceTypeMapper deviceTypeMapper, SmartCityPlatformService smartCityPlatformService, SubscriptionTemplateService subscriptionTemplateService, SubscriptionsMapper subscriptionsMapper, SubscriptionsRepository subscriptionsRepository, UsuarioRepository usuarioRepository) {
        this.deviceTypeRepository = deviceTypeRepository;
        this.deviceTypeMapper = deviceTypeMapper;
        this.smartCityPlatformService = smartCityPlatformService;
        this.subscriptionTemplateService = subscriptionTemplateService;
        this.subscriptionsMapper = subscriptionsMapper;
        this.subscriptionsRepository = subscriptionsRepository;
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Save a deviceType.
     *
     * @param deviceTypeDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public DeviceTypeDTO save(DeviceTypeDTO deviceTypeDTO) throws PlatformException {
        log.debug("Request to save DeviceType : {}", deviceTypeDTO);
        DeviceType deviceType = deviceTypeMapper.toEntity(deviceTypeDTO);
        boolean isNewDeviceType =(deviceTypeDTO.getId() == null);

        if (isNewDeviceType){

            createSuscriptions(deviceTypeDTO, deviceType);
        } else {
            Optional<DeviceType> deviceTypeOldOptional = deviceTypeRepository.findById(deviceTypeDTO.getId());
            if (deviceTypeOldOptional.isPresent()) {
                DeviceType deviceTypeActual = deviceTypeOldOptional.get();

                boolean referenceUpdated = !deviceTypeActual.getReference().equals(deviceTypeDTO.getReference());
                boolean typeUpdated = !deviceTypeActual.getType().equals(deviceTypeDTO.getType());
                boolean recreateSuscription =( (typeUpdated) || (referenceUpdated) );
                if (recreateSuscription){
                    deleteSuscriptions(deviceTypeDTO.getId());

                    createSuscriptions(deviceTypeDTO, deviceType);
                }
            }

        }
        deviceType = deviceTypeRepository.save(deviceType);
        return deviceTypeMapper.toDto(deviceType);
    }

    private void deleteSuscriptions(Long id) throws PlatformException {
        List<Subscriptions> deviceTypeSubs = subscriptionsRepository.findByDeviceTypeId(id);
        for (Subscriptions sub : deviceTypeSubs) {

            subscriptionsRepository.deleteById(sub.getId());
            try {
                smartCityPlatformService.deleteSubscription(subscriptionsMapper.toDto(sub));
            }catch (Exception e ){
                // No capturo el error porque necesito continuar para eliminar el t

            }

        }
    }

    private void createSuscriptions(DeviceTypeDTO deviceTypeDTO, DeviceType deviceType) throws PlatformException {

        Page<SubscriptionTemplateDTO> subscriptionTemplateList = subscriptionTemplateService
            .findAll(PageRequest.of(0, 100));
        List<SubscriptionsDTO> subscriptionsDTOList = subscriptionsMapper.
            subscriptionTemplateDTOListToSubscriptionsDTOList(subscriptionTemplateList.getContent(), deviceTypeDTO);

        List<SubscriptionsDTO> subscriptionsDTOListWithID = smartCityPlatformService
            .addSubscriptions(subscriptionsDTOList);

        for (SubscriptionsDTO subsDTO : subscriptionsDTOListWithID) {
            Subscriptions subscription = subscriptionsMapper.toEntity(subsDTO);
            subscription.setDeviceType(deviceType);
            ZonedDateTime zdt = ZonedDateTime.now(ZoneId.of("Europe/Madrid"));
            zdt = zdt.plusHours(2);
            subscription.setCreateAt(zdt);
            subscriptionsRepository.save(subscription);
        }
    }

    /**
     * Get all the deviceTypes.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<DeviceTypeDTO> findAll(Pageable pageable) {
        log.debug("Request to get all DeviceTypes");
        return deviceTypeRepository.findAll(pageable)
            .map(deviceTypeMapper::toDto);
    }


    /**
     * Get one deviceType by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<DeviceTypeDTO> findOne(Long id) {
        log.debug("Request to get DeviceType : {}", id);
        return deviceTypeRepository.findById(id)
            .map(deviceTypeMapper::toDto);
    }

    /**
     * Delete the deviceType by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) throws PlatformException {
        log.debug("Request to delete DeviceType : {}", id);
        deleteSuscriptions(id);
        List<Usuario> usuarios;
        usuarios = usuarioRepository.findAll();

        for (Usuario usuario : usuarios) {
            Set<DeviceType> devicesTypesToIterate = usuario.getDevicesTypes();
            Set<DeviceType> devicesTypesToSet = new HashSet();
            for (DeviceType deviceType : devicesTypesToIterate) {
                if(!deviceType.getId().equals(id)) {
                    devicesTypesToSet.add(deviceType);
                }
            }
            usuario.setDevicesTypes(devicesTypesToSet);
            usuarioRepository.save(usuario);
        }
        deviceTypeRepository.deleteById(id);
    }

    public Optional<DeviceType> findByReference(String reference){
        return deviceTypeRepository.findByReference(reference);
    }
}

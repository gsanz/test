package com.ute.smartcity.web.rest.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

/**
 * Utility class for HTTP headers creation.
 */
public final class HeaderUtil {

    private static final Logger log = LoggerFactory.getLogger(HeaderUtil.class);

    private static final String APPLICATION_NAME = "smartcityApp";

    private static final String APPLICATION_ORION_NAME = "orion";
    private HeaderUtil() {
    }



    public static HttpHeaders createEntityCreationAlert(String entityName, String param) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".created", param);
    }

    public static HttpHeaders createEntityUpdateAlert(String entityName, String param) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".updated", param);
    }

    public static HttpHeaders createEntityDeletionAlert(String entityName, String param) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".deleted", param);
    }

    public static HttpHeaders createEntityDeletionFailureAlert(String entityName, String param) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".deletionFailure", param);
    }

    public static HttpHeaders cuentaBloqueada(String entityName) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".disabled","");
    }
    public static HttpHeaders incorrectCode(String entityName) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".incorrect", "");
    }
    public static HttpHeaders tiempoExpirado(String entityName) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".expired", "");
    }

    public static HttpHeaders deviceSavedInOrion(String entityName) {
        return createAlert(APPLICATION_ORION_NAME + "." + entityName + ".save-orion", "");
    }
    public static HttpHeaders deviceFailSavedInOrion(String entityName) {
        return createFailureAlert(APPLICATION_ORION_NAME, "fail-save-orion", "");
    }

    public static HttpHeaders createEntityFailCreationInOrion(String entityName,  String defaultMessage) {
        log.error("Entity creation orion failed, {}", defaultMessage);
        String errorKey = "orion-fail";
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-" + APPLICATION_ORION_NAME + "-error", "error." + errorKey);
        headers.add("X-" + APPLICATION_ORION_NAME + "-params", entityName);
        return headers;    }

    public static HttpHeaders deviceDeletedInOrion(String entityName) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".delete-orion", "");
    }

    public static HttpHeaders deviceFailDeletedInOrion(String entityName) {
        return createAlert(APPLICATION_NAME + "." + entityName + ".fail-delete-orion", "");
    }

    public static HttpHeaders createAlert(String message, String param) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-" + APPLICATION_NAME + "-alert", message);
        headers.add("X-" + APPLICATION_NAME + "-params", param);
        return headers;
    }
    public static HttpHeaders createFailureAlert(String entityName, String errorKey, String defaultMessage) {
        log.error("Entity processing failed, {}", defaultMessage);
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-" + APPLICATION_NAME + "-error", "error." + errorKey);
        headers.add("X-" + APPLICATION_NAME + "-params", entityName);
        return headers;
    }
}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.service.ZoneService;
import com.ute.smartcity.domain.Zone;
import com.ute.smartcity.repository.ZoneRepository;
import com.ute.smartcity.service.dto.ZoneDTO;
import com.ute.smartcity.service.mapper.ZoneMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing Zone.
 */
@Service
@Transactional
public class ZoneServiceImpl implements ZoneService {

    private final Logger log = LoggerFactory.getLogger(ZoneServiceImpl.class);

    private final ZoneRepository zoneRepository;

    private final DeviceRepository deviceRepository;

    private final ZoneMapper zoneMapper;

    public ZoneServiceImpl(ZoneRepository zoneRepository, ZoneMapper zoneMapper, DeviceRepository deviceRepository) {
        this.zoneRepository = zoneRepository;
        this.zoneMapper = zoneMapper;
        this.deviceRepository = deviceRepository;
    }

    /**
     * Save a zone.
     *
     * @param zoneDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public ZoneDTO save(ZoneDTO zoneDTO) {
        log.debug("Request to save Zone : {}", zoneDTO);
        Zone zone = zoneMapper.toEntity(zoneDTO);
        zone = zoneRepository.save(zone);
        return zoneMapper.toDto(zone);
    }

    /**
     * Get all the zones.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<ZoneDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Zones");
        return zoneRepository.findAll(pageable)
            .map(zoneMapper::toDto);
    }


    /**
     * Get one zone by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<ZoneDTO> findOne(Long id) {
        log.debug("Request to get Zone : {}", id);
        return zoneRepository.findById(id)
            .map(zoneMapper::toDto);
    }

    /**
     * Delete the zone by id.
     *
     * @param id the id of the entity
     */
    @Override
    public Integer delete(Long id) {
        log.debug("Request to delete Zone : {}", id);

        List<Device> devicesByZoneId = deviceRepository.findByZoneId(id);
        Integer result = devicesByZoneId.size();

        if(result >= 1){
            return 0;
        } else {
            zoneRepository.deleteById(id);
            return 1;
        }
    }
}

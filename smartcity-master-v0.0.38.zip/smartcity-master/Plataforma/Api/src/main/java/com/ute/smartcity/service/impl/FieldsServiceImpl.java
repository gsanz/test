package com.ute.smartcity.service.impl;

import com.ute.smartcity.service.FieldsQueryService;
import com.ute.smartcity.service.FieldsService;
import com.ute.smartcity.domain.Fields;
import com.ute.smartcity.repository.FieldsRepository;
import com.ute.smartcity.service.dto.FieldsCriteria;
import com.ute.smartcity.service.dto.FieldsDTO;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.FieldsMapper;
import io.github.jhipster.service.filter.LongFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing Fields.
 */
@Service
@Transactional
public class FieldsServiceImpl implements FieldsService {

    private final Logger log = LoggerFactory.getLogger(FieldsServiceImpl.class);

    private final FieldsRepository fieldsRepository;

    private final FieldsMapper fieldsMapper;

    private final DeviceMapper deviceMapper;

    private final FieldsQueryService fieldsQueryService;

    public FieldsServiceImpl(FieldsRepository fieldsRepository, FieldsMapper fieldsMapper, DeviceMapper deviceMapper, FieldsQueryService fieldsQueryService) {
        this.fieldsRepository = fieldsRepository;
        this.fieldsMapper = fieldsMapper;
        this.deviceMapper = deviceMapper;
        this.fieldsQueryService = fieldsQueryService;
    }

    /**
     * Save a fields.
     *
     * @param fieldsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public FieldsDTO save(FieldsDTO fieldsDTO) {
        log.debug("Request to save Fields : {}", fieldsDTO);

        Fields fields = fieldsMapper.toEntity(fieldsDTO);
        fields = fieldsRepository.save(fields);
        return fieldsMapper.toDto(fields);
    }

    /**
     * Get all the fields.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<FieldsDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Fields");
        return fieldsRepository.findAll(pageable)
            .map(fieldsMapper::toDto);
    }


    /**
     * Get one fields by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<FieldsDTO> findOne(Long id) {
        log.debug("Request to get Fields : {}", id);
        return fieldsRepository.findById(id)
            .map(fieldsMapper::toDto);
    }

    /**
     * Delete the fields by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Fields : {}", id);
        fieldsRepository.deleteById(id);
    }

    @Override
    public Optional<List<FieldsDTO>> findByDeviceId(Long id) {
        log.debug("find by findByDeviceId : {}", id);
        FieldsCriteria fieldsCriteria = new FieldsCriteria();
        LongFilter longFilter = new LongFilter();
        longFilter.setEquals(id);
        fieldsCriteria.setDeviceId(longFilter);
        List<FieldsDTO> fieldsDTOList = fieldsQueryService.findByCriteria(fieldsCriteria);
        return Optional.ofNullable(fieldsDTOList);
    }

    @Override
    public Optional<List<FieldsDTO>> findByDeviceTypeId(Long id) {
        log.debug("find by device :, id: {}", id);
        FieldsCriteria fieldsCriteria = new FieldsCriteria();
        LongFilter longFilter = new LongFilter();
        longFilter.setEquals(id);
        fieldsCriteria.setDeviceTypeId(longFilter);
        List<FieldsDTO> fieldsDTOList = fieldsQueryService.findByCriteria(fieldsCriteria);
        return Optional.ofNullable(fieldsDTOList);
    }
}

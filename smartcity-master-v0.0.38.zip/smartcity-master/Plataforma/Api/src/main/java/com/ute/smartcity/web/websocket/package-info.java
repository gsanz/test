/**
 * WebSocket services, using Spring Websocket.
 */
package com.ute.smartcity.web.websocket;

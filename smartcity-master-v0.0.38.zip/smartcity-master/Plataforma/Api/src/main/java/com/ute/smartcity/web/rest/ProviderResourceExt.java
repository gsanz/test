package com.ute.smartcity.web.rest;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.User;
import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.repository.UserRepository;
import com.ute.smartcity.repository.UsuarioRepository;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.security.SecurityUtils;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.ProviderDTO;
import com.ute.smartcity.service.dto.UsuarioDTO;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.errors.EmailAlreadyUsedException;
import com.ute.smartcity.web.rest.errors.LoginAlreadyUsedException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * REST controller for managing Provider.
 */
@RestController
@RequestMapping("/api")
public class ProviderResourceExt {

    private final Logger log = LoggerFactory.getLogger(ProviderResourceExt.class);

    private static final String ENTITY_NAME = "provider";

    private static final String REQUIRED_EMAIL = "The field email is required";

    public static final Pattern VALID_EMAIL =
        Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    public static final Pattern VALID_PHONE =
        Pattern.compile("\\d{9}|(?:\\d{3}-){2}\\d{4}|\\(\\d{3}\\)\\d{3}-?\\d{4}");
    private final ProviderService providerService;

    private final UsuarioRepository usuarioRepository;

    private final UsuarioService usuarioService;

    private final UserRepository userRepository;

    private final UserService userService;

    private final DeviceService deviceService;

    private final ProviderQueryService providerQueryService;

    public ProviderResourceExt(ProviderService providerService, UsuarioRepository usuarioRepository, UsuarioService usuarioService, UserRepository userRepository, UserService userService, DeviceService deviceService, ProviderQueryService providerQueryService) {
        this.providerService = providerService;
        this.usuarioRepository = usuarioRepository;
        this.usuarioService = usuarioService;
        this.userService = userService;
        this.userRepository = userRepository;
        this.deviceService = deviceService;
        this.providerQueryService = providerQueryService;
    }

    /**
     * GET  /providers/:id : get the "id" provider.
     *
     * @param id the id of the providerDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the providerDTO, or with status 404 (Not Found)
     */
    @GetMapping("/providers/{id}")
    public ResponseEntity<ProviderDTO> getProvider(@PathVariable Long id) {
        log.debug("REST request to get Provider : {}", id);
        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        if (!isAdmin) {
            Optional<String> loggedUserName = SecurityUtils.getCurrentUserLogin();

            String name = null;
            if(loggedUserName.isPresent()){
                name = loggedUserName.get();
            }
            Optional<User> userByLogin = userService.getUserByLogin(name);

            Long userByLoginId = null;
            if(userByLogin.isPresent()){
                userByLoginId = userByLogin.get().getId();
            }
            Optional<UsuarioDTO> usuarioOptional = usuarioService.findOne(userByLoginId);

            if(usuarioOptional.isPresent()){
                if(!usuarioOptional.get().getProviderId().equals(id)) {
                    throw new BadRequestAlertException("You can't see a provider that is not you", ENTITY_NAME, "notmachedproviderid");
                }
            }
        }
        Optional<ProviderDTO> providerDTO = providerService.findOne(id);
        return ResponseUtil.wrapOrNotFound(providerDTO);
    }

    /**
     * POST  /providers : Create a new provider.
     *
     * @param providerDTO the providerDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new providerDTO, or with status 400 (Bad Request) if the provider has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/providers")
    @ResourceAudit(ENTITY_NAME)
    public ResponseEntity<ProviderDTO> createProvider(@Valid @RequestBody ProviderDTO providerDTO) throws URISyntaxException {
        log.debug("REST request to save Provider : {}", providerDTO);
        if (providerDTO.getId() != null) {
            throw new BadRequestAlertException("A new provider cannot already have an ID", ENTITY_NAME, "idexists");
        }
        String name = providerDTO.getName().trim();
        if (providerDTO.getName() == null || providerDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("The field name is required", ENTITY_NAME, "noname");
        }
        String mobile = providerDTO.getMobile().trim();
        if (providerDTO.getMobile() == null || providerDTO.getMobile().equals("") || mobile.length() <= 0) {
            throw new BadRequestAlertException("The field mobile is required", ENTITY_NAME, "nomobile");
        }
        String email = providerDTO.getEmail().trim();
        if (providerDTO.getEmail() == null || providerDTO.getEmail().equals("") || email.length() <= 0) {
            throw new BadRequestAlertException(REQUIRED_EMAIL, ENTITY_NAME, "noemail");
        }
        if (validateFields(providerDTO.getEmail() , providerDTO.getMobile() )){
            throw new BadRequestAlertException(REQUIRED_EMAIL, ENTITY_NAME, "badfields");
        }
        Optional<User> existingUser = userRepository.findOneByEmailIgnoreCase(providerDTO.getEmail());
        if (existingUser.isPresent()) {
            throw new EmailAlreadyUsedException();
        }
        existingUser = userRepository.findOneByLogin(providerDTO.getEmail().toLowerCase());
        if (existingUser.isPresent()) {
            throw new LoginAlreadyUsedException();
        }
        Optional<Usuario> existingUsuario = usuarioRepository.findOneByPhone(providerDTO.getMobile().toLowerCase());
        if (existingUsuario.isPresent()) {
            throw new BadRequestAlertException("Provider phone already exists", ENTITY_NAME, "phoneexist");
        }


        ProviderDTO result = providerService.create(providerDTO);
        return ResponseEntity.created(new URI("/api/providers/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /providers : Updates an existing provider.
     *
     * @param providerDTO the providerDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated providerDTO,
     * or with status 400 (Bad Request) if the providerDTO is not valid,
     * or with status 500 (Internal Server Error) if the providerDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/providers")
    @PreAuthorize("hasAnyRole('" + AuthoritiesConstants.ADMIN + "','" + AuthoritiesConstants.PROVIDER + "')")
    @ResourceAudit(ENTITY_NAME)
    public ResponseEntity<ProviderDTO> updateProvider(@Valid @RequestBody ProviderDTO providerDTO) throws URISyntaxException {
        log.debug("REST request to update Provider : {}", providerDTO);
        if (providerDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String name = providerDTO.getName().trim();
        if (providerDTO.getName() == null || providerDTO.getName().equals("") || name.length() <= 0) {
            throw new BadRequestAlertException("The field name is required", ENTITY_NAME, "noname");
        }
        String mobile = providerDTO.getMobile().trim();
        if (providerDTO.getMobile() == null || providerDTO.getMobile().equals("") || mobile.length() <= 0) {
            throw new BadRequestAlertException("The field mobile is required", ENTITY_NAME, "nomobile");
        }
        String email = providerDTO.getEmail().trim();
        if (providerDTO.getEmail() == null || providerDTO.getEmail().equals("") || email.length() <= 0) {
            throw new BadRequestAlertException(REQUIRED_EMAIL, ENTITY_NAME, "noemail");
        }
        if (validateFields(providerDTO.getEmail() , providerDTO.getMobile() )){
            throw new BadRequestAlertException(REQUIRED_EMAIL, ENTITY_NAME, "badfields");
        }

        boolean isAdmin = SecurityUtils.isCurrentUserInRole(AuthoritiesConstants.ADMIN);
        if(!isAdmin) {
            Optional<String> loggedUserName = SecurityUtils.getCurrentUserLogin();
            if(!loggedUserName.isPresent()) {
                throw new BadRequestAlertException("You need to be logged", ENTITY_NAME, "notloggedin");
            }
            Optional<User> userByLogin = userService.getUserByLogin(loggedUserName.get());
            Long userByLoginId = null;
            if(userByLogin.isPresent()){
                userByLoginId = userByLogin.get().getId();
            }
            Optional<UsuarioDTO> usuarioOptional = usuarioService.findOne(userByLoginId);

            if(usuarioOptional.isPresent()){
                if(!usuarioOptional.get().getProviderId().equals(providerDTO.getId())) {
                    throw new BadRequestAlertException("You can't update a provider that is not you", ENTITY_NAME, "notmachedproviderid");
                }
            }
        }

        Optional<User> existingUser = userRepository.findOneByEmailIgnoreCase(providerDTO.getEmail());
        Usuario existingUsuario = null;
        if (existingUser.isPresent()) {
            existingUsuario = usuarioRepository.findOneById(existingUser.get().getId());
        }
        if (existingUsuario != null && !existingUsuario.getProvider().getId().equals(providerDTO.getId())) {
            throw new EmailAlreadyUsedException();
        }
        existingUser = userRepository.findOneByLogin(providerDTO.getName().toLowerCase());
        if (existingUser.isPresent()) {
            existingUsuario = usuarioRepository.findOneById(existingUser.get().getId());
        }
        if (existingUsuario != null && !existingUsuario.getProvider().getId().equals(providerDTO.getId())) {
            throw new LoginAlreadyUsedException();
        }
        Optional<Usuario> usuario = usuarioRepository.findOneByPhone(providerDTO.getMobile().toLowerCase());
        if (usuario.isPresent()) {
            existingUsuario = usuarioRepository.findOneById(usuario.get().getId());
        }
        if (existingUsuario != null && !existingUsuario.getProvider().getId().equals(providerDTO.getId())) {
            throw new BadRequestAlertException("Provider phone already exists", ENTITY_NAME, "phoneexist");
        }

        ProviderDTO result = providerService.save(providerDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, providerDTO.getId().toString()))
            .body(result);
    }

    /**
     * DELETE  /providers/:id : delete the "id" provider.
     *
     * @param id the id of the providerDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/providers/{id}")
    @ResourceAudit(ENTITY_NAME)
    public ResponseEntity<Void> deleteProvider(@PathVariable Long id) {
        log.debug("REST request to delete Provider : {}", id);

        List<Device> devicesByProviderId = deviceService.findAllByProviderId(id);
        if (!devicesByProviderId.isEmpty()){
            throw new BadRequestAlertException("First, delete all the devices of this provider", ENTITY_NAME, "deletedevices");
        }

        providerService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    public boolean validateFields(String email, String phone){

        Matcher matcherEmail = VALID_EMAIL.matcher(email);
        Matcher matcherPhone = VALID_PHONE.matcher(phone);

        boolean isValidEmail = matcherEmail.find();
        boolean isValidPhone = matcherPhone.find();

        if (!isValidEmail || !isValidPhone) {
            return true;
        } else {
            return false;
        }
    }

}

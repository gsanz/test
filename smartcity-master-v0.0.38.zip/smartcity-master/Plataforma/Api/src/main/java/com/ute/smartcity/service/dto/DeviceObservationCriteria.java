package com.ute.smartcity.service.dto;

import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.LongFilter;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Objects;

/**
 * Criteria class for the Provider entity. This class is used in ProviderResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /providers?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */

@Component
public class DeviceObservationCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    private String device;

    private String deviceType;

    private String fromDate;

    private String toDate;

    private LongFilter providerId;

    public LongFilter getProviderId() {
        return providerId;
    }

    public void setProviderId(LongFilter providerId) {
        this.providerId = providerId;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DeviceObservationCriteria that = (DeviceObservationCriteria) o;
        return Objects.equals(device, that.device) &&
            Objects.equals(deviceType, that.deviceType) &&
            Objects.equals(fromDate, that.fromDate) &&
            Objects.equals(toDate, that.toDate) &&
            Objects.equals(providerId, that.providerId);
    }

    @Override
    public int hashCode() {

        return Objects.hash(device, deviceType, fromDate, toDate, providerId);
    }

    @Override
    public String toString() {
        return "DeviceObservationCriteria{" +
            "device=" + device +
            ", deviceType=" + deviceType +
            ", fromDate=" + fromDate +
            ", toDate=" + toDate +
            ", providerId=" + providerId +
            '}';
    }
}

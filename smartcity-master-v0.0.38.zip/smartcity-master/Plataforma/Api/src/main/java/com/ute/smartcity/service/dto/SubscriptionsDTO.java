package com.ute.smartcity.service.dto;
import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Subscriptions entity.
 */
public class SubscriptionsDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    private String description;

    @NotNull
    private String endpoint;

    private String platformId;

    private ZonedDateTime createAt;

    private String state;


    private Long deviceTypeId;

    private String deviceTypeName;

    private String deviceTypeType;

    private String deviceTypeReference;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Long getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(Long deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    public String getDeviceTypeName() {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SubscriptionsDTO subscriptionsDTO = (SubscriptionsDTO) o;
        if (subscriptionsDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), subscriptionsDTO.getId());
    }

    public String getDeviceTypeType() {
        return deviceTypeType;
    }

    public void setDeviceTypeType(String deviceTypeType) {
        this.deviceTypeType = deviceTypeType;
    }

    public String getDeviceTypeReference() {
        return deviceTypeReference;
    }

    public void setDeviceTypeReference(String deviceTypeReference) {
        this.deviceTypeReference = deviceTypeReference;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SubscriptionsDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", endpoint='" + getEndpoint() + "'" +
            ", platformId='" + getPlatformId() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", state='" + getState() + "'" +
            ", deviceType=" + getDeviceTypeId() +
            ", deviceType='" + getDeviceTypeName() + "'" +
            "}";
    }
}

package com.ute.smartcity.service;

import java.util.List;

import javax.persistence.criteria.JoinType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.ute.smartcity.domain.RuleCompareFields;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.RuleCompareFieldsRepository;
import com.ute.smartcity.service.dto.RuleCompareFieldsCriteria;
import com.ute.smartcity.service.dto.RuleCompareFieldsDTO;
import com.ute.smartcity.service.mapper.RuleCompareFieldsMapper;

/**
 * Service for executing complex queries for RuleCompareFields entities in the database.
 * The main input is a {@link RuleCompareFieldsCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link RuleCompareFieldsDTO} or a {@link Page} of {@link RuleCompareFieldsDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class RuleCompareFieldsQueryService extends QueryService<RuleCompareFields> {

    private final Logger log = LoggerFactory.getLogger(RuleCompareFieldsQueryService.class);

    private final RuleCompareFieldsRepository ruleCompareFieldsRepository;

    private final RuleCompareFieldsMapper ruleCompareFieldsMapper;

    public RuleCompareFieldsQueryService(RuleCompareFieldsRepository ruleCompareFieldsRepository, RuleCompareFieldsMapper ruleCompareFieldsMapper) {
        this.ruleCompareFieldsRepository = ruleCompareFieldsRepository;
        this.ruleCompareFieldsMapper = ruleCompareFieldsMapper;
    }

    /**
     * Return a {@link List} of {@link RuleCompareFieldsDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<RuleCompareFieldsDTO> findByCriteria(RuleCompareFieldsCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<RuleCompareFields> specification = createSpecification(criteria);
        return ruleCompareFieldsMapper.toDto(ruleCompareFieldsRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link RuleCompareFieldsDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<RuleCompareFieldsDTO> findByCriteria(RuleCompareFieldsCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<RuleCompareFields> specification = createSpecification(criteria);
        return ruleCompareFieldsRepository.findAll(specification, page)
            .map(ruleCompareFieldsMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(RuleCompareFieldsCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<RuleCompareFields> specification = createSpecification(criteria);
        return ruleCompareFieldsRepository.count(specification);
    }

    /**
     * Function to convert RuleCompareFieldsCriteria to a {@link Specification}
     */
    private Specification<RuleCompareFields> createSpecification(RuleCompareFieldsCriteria criteria) {
        Specification<RuleCompareFields> specification = Specification.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildSpecification(criteria.getId(), RuleCompareFields_.id));
            }
            if (criteria.getCompareType() != null) {
                specification = specification.and(buildSpecification(criteria.getCompareType(), RuleCompareFields_.compareType));
            }
            if (criteria.getValue() != null) {
                specification = specification.and(buildStringSpecification(criteria.getValue(), RuleCompareFields_.value));
            }
            if (criteria.getFieldName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getFieldName(), RuleCompareFields_.fieldName));
            }
            if (criteria.getRuleId() != null) {
                specification = specification.and(buildSpecification(criteria.getRuleId(),
                    root -> root.join(RuleCompareFields_.rule, JoinType.LEFT).get(Rule_.id)));
            }
        }
        return specification;
    }
}

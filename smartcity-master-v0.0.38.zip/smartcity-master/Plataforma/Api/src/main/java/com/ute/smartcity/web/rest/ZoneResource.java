package com.ute.smartcity.web.rest;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.ZoneService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.ZoneDTO;
import com.ute.smartcity.service.dto.ZoneCriteria;
import com.ute.smartcity.service.ZoneQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Zone.
 */
@RestController
@RequestMapping("/api")
public class ZoneResource {

    private final Logger log = LoggerFactory.getLogger(ZoneResource.class);

    private static final String ENTITY_NAME = "zone";

    private final ZoneService zoneService;

    private final ZoneQueryService zoneQueryService;

    public ZoneResource(ZoneService zoneService, ZoneQueryService zoneQueryService) {
        this.zoneService = zoneService;
        this.zoneQueryService = zoneQueryService;
    }

    /**
     * GET  /zones : get all the zones.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of zones in body
     */
    @GetMapping("/zones")
    public ResponseEntity<List<ZoneDTO>> getAllZones(ZoneCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Zones by criteria: {}", criteria);
        Page<ZoneDTO> page = zoneQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/zones");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /zones : get all the zones.
     *
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of zones in body
     */
    @GetMapping("/zonesUnpaged")
    public ResponseEntity<List<ZoneDTO>> getAllZonesUnpaged(ZoneCriteria criteria) {
        log.debug("REST request to get Zones by criteria: {}", criteria);
        List<ZoneDTO> page = zoneQueryService.findByCriteria(criteria);
    //    HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/zones");
        return ResponseEntity.ok().body(page);
    }

    /**
    * GET  /zones/count : count all the zones.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/zones/count")
    public ResponseEntity<Long> countZones(ZoneCriteria criteria) {
        log.debug("REST request to count Zones by criteria: {}", criteria);
        return ResponseEntity.ok().body(zoneQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /zones/:id : get the "id" zone.
     *
     * @param id the id of the zoneDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the zoneDTO, or with status 404 (Not Found)
     */
    @GetMapping("/zones/{id}")
    public ResponseEntity<ZoneDTO> getZone(@PathVariable Long id) {
        log.debug("REST request to get Zone : {}", id);
        Optional<ZoneDTO> zoneDTO = zoneService.findOne(id);
        return ResponseUtil.wrapOrNotFound(zoneDTO);
    }

    /**
     * DELETE  /zones/:id : delete the "id" zone.
     *
     * @param id the id of the zoneDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/zones/{id}")
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<Void> deleteZone(@PathVariable Long id) {
        log.debug("REST request to delete Zone : {}", id);
        Integer result = zoneService.delete(id);

        if(result == 0) {
            return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionFailureAlert(ENTITY_NAME, id.toString())).build();
        } else {
            return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
        }
    }
}

package com.ute.smartcity.domain.enumeration;

/**
 * The AlertState enumeration.
 */
public enum AlertState {
    OPEN, CLOSE
}

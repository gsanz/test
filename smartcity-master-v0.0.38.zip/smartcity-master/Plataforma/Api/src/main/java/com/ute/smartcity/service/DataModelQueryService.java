package com.ute.smartcity.service;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.repository.DataModelRepository;
import com.ute.smartcity.service.dto.DataModelCriteria;
import com.ute.smartcity.service.dto.DataModelDTO;
import com.ute.smartcity.service.dto.DeviceTypeCriteria;
import com.ute.smartcity.service.dto.DeviceTypeDTO;
import com.ute.smartcity.service.mapper.DataModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * Service for executing complex queries for DeviceType entities in the database.
 * The main input is a {@link DeviceTypeCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link DeviceTypeDTO} or a {@link Page} of {@link DeviceTypeDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class DataModelQueryService extends QueryServiceExtended<DataModel> {

    private final Logger log = LoggerFactory.getLogger(DataModelQueryService.class);

    private final DataModelRepository dataModelRepository;

    private final DataModelMapper dataModelMapper;

    public DataModelQueryService(DataModelRepository dataModelRepository, DataModelMapper dataModelMapper) {
        this.dataModelRepository = dataModelRepository;
        this.dataModelMapper = dataModelMapper;
    }


    @Transactional(readOnly = true)
    public Page<DataModelDTO> findByCriteria(DataModelCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<DataModel> specification = createSpecification(criteria);
        Page<DataModel> dataModels = dataModelRepository.findAll(specification, page);
        return dataModels.map(dataModelMapper::toDto);
    }



    /**
     * Function to convert DeviceTypeCriteria to a {@link Specification}
     */
    private Specification<DataModel> createSpecification(DataModelCriteria criteria) {
        Specification<DataModel> specification = Specification.where(null);
        if (criteria != null) {

            if (criteria.getReference() != null) {
                specification = specification.and(buildStringSpecification(criteria.getReference(), DataModel_.reference));
            }
            if (criteria.getName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getName(), DataModel_.name));
            }


        }
        return specification;
    }
}

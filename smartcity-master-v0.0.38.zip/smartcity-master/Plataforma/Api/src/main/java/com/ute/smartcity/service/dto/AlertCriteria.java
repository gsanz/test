package com.ute.smartcity.service.dto;

import java.io.Serializable;
import java.util.Objects;
import com.ute.smartcity.domain.enumeration.CriticalityLevel;
import com.ute.smartcity.domain.enumeration.AlertState;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;
import io.github.jhipster.service.filter.ZonedDateTimeFilter;

/**
 * Criteria class for the Alert entity. This class is used in AlertResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /alerts?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class AlertCriteria implements Serializable {
    /**
     * Class for filtering CriticalityLevel
     */
    public static class CriticalityLevelFilter extends Filter<CriticalityLevel> {
    }
    /**
     * Class for filtering AlertState
     */
    public static class AlertStateFilter extends Filter<AlertState> {
    }

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter reference;

    private CriticalityLevelFilter criticalityLevel;

    private AlertStateFilter state;

    private StringFilter description;

    private StringFilter message;

    private ZonedDateTimeFilter createAt;

    private LongFilter deviceId;

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getReference() {
        return reference;
    }

    public void setReference(StringFilter reference) {
        this.reference = reference;
    }

    public CriticalityLevelFilter getCriticalityLevel() {
        return criticalityLevel;
    }

    public void setCriticalityLevel(CriticalityLevelFilter criticalityLevel) {
        this.criticalityLevel = criticalityLevel;
    }

    public AlertStateFilter getState() {
        return state;
    }

    public void setState(AlertStateFilter state) {
        this.state = state;
    }

    public StringFilter getDescription() {
        return description;
    }

    public void setDescription(StringFilter description) {
        this.description = description;
    }

    public StringFilter getMessage() {
        return message;
    }

    public void setMessage(StringFilter message) {
        this.message = message;
    }

    public ZonedDateTimeFilter getCreateAt() {
        return createAt;
    }

    public void setCreateAt(ZonedDateTimeFilter createAt) {
        this.createAt = createAt;
    }

    public LongFilter getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(LongFilter deviceId) {
        this.deviceId = deviceId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final AlertCriteria that = (AlertCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(reference, that.reference) &&
            Objects.equals(criticalityLevel, that.criticalityLevel) &&
            Objects.equals(state, that.state) &&
            Objects.equals(description, that.description) &&
            Objects.equals(message, that.message) &&
            Objects.equals(createAt, that.createAt) &&
            Objects.equals(deviceId, that.deviceId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        reference,
        criticalityLevel,
        state,
        description,
        message,
        createAt,
        deviceId
        );
    }

    @Override
    public String toString() {
        return "AlertCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (reference != null ? "reference=" + reference + ", " : "") +
                (criticalityLevel != null ? "criticalityLevel=" + criticalityLevel + ", " : "") +
                (state != null ? "state=" + state + ", " : "") +
                (description != null ? "description=" + description + ", " : "") +
                (message != null ? "message=" + message + ", " : "") +
                (createAt != null ? "createAt=" + createAt + ", " : "") +
                (deviceId != null ? "deviceId=" + deviceId + ", " : "") +
            "}";
    }

}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.User;
import com.ute.smartcity.service.MailService;
import com.ute.smartcity.service.UserService;
import com.ute.smartcity.service.UsuarioService;
import com.ute.smartcity.domain.Usuario;
import com.ute.smartcity.repository.UsuarioRepository;
import com.ute.smartcity.service.dto.UsuarioDTO;
import com.ute.smartcity.service.mapper.UserMapper;
import com.ute.smartcity.service.mapper.UsuarioMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing Usuario.
 */
@Service
@Transactional
public class UsuarioServiceImpl implements UsuarioService {

    private final Logger log = LoggerFactory.getLogger(UsuarioServiceImpl.class);

    private final UsuarioRepository usuarioRepository;

    private final UsuarioMapper usuarioMapper;
    private final UserMapper userMapper;

    private final UserService userService;
    private final MailService mailService;

    public UsuarioServiceImpl(UsuarioRepository usuarioRepository, UsuarioMapper usuarioMapper, UserMapper userMapper, UserService userService, MailService mailService) {
        this.usuarioRepository = usuarioRepository;
        this.usuarioMapper = usuarioMapper;
        this.userMapper = userMapper;
        this.userService = userService;
        this.mailService = mailService;
    }

    /**
     * Save a usuario.
     *
     * @param usuarioDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public UsuarioDTO save(UsuarioDTO usuarioDTO) {
        log.debug("Request to save Usuario : {}", usuarioDTO);

        Usuario usuario = usuarioMapper.toEntity(usuarioDTO);
        usuario = usuarioRepository.save(usuario);
        return usuarioMapper.toDto(usuario);
    }

    /**
     * Get all the usuarios.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<UsuarioDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Usuarios");
        return usuarioRepository.findAll(pageable)
            .map(usuarioMapper::toDto);
    }


    /**
     * Get one usuario by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<UsuarioDTO> findOne(Long id) {
        log.debug("Request to get Usuario : {}", id);
        return usuarioRepository.findOneWithEagerRelationships(id)
            .map(usuarioMapper::toDto);
    }

    /**
     * Delete the usuario by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Usuario : {}", id);
        Usuario userById = getUserById(id);
        usuarioRepository.deleteById(id);
        if (userById != null){
            userService.delete(userById.getId());
        }
    }

    @Override
    public UsuarioDTO createUsuario(UsuarioDTO usuarioDTO) {
        Usuario usuario = usuarioMapper.toEntity(usuarioDTO);

        usuario.setLastPasswordDate(ZonedDateTime.now());

        User newUser = userService.createUser(usuarioDTO.getUser());
        mailService.sendCreationEmail(newUser);
        usuario.setUser(newUser);

        usuario = usuarioRepository.save(usuario);
        return usuarioMapper.toDto(usuario);
    }

    @Override
    public UsuarioDTO updateUsuario(UsuarioDTO usuarioDTO) {
        Usuario usuario = usuarioMapper.toEntity(usuarioDTO);
        User user = userMapper.userDTOToUser(usuarioDTO.getUser());

        userService.updateUser(usuarioDTO.getUser());
        usuario.setUser(user);

        usuario = usuarioRepository.save(usuario);
        return usuarioMapper.toDto(usuario);
    }

    @Override
    public UsuarioDTO checkAttempts(Long userId){
        Usuario usuario = getUserById(userId);

        int intentos = usuario.getNumberAttemptsDoubleAuth();
        usuario.setNumberAttemptsDoubleAuth(intentos+1);

        if (usuario.getNumberAttemptsDoubleAuth() >= 3) {
            mailService.sendUserDisabledMail(usuario.getUser());
            usuario.getUser().setActivated(false);
            mailService.sendUserDisabledMail(usuario.getUser());
        }

        usuario = usuarioRepository.save(usuario);
        return usuarioMapper.toDto(usuario);
    }

    @Override
    public UsuarioDTO resetAttempts(Long userId) {
        Usuario usuario = getUserById(userId);

        usuario.setNumberAttemptsDoubleAuth(0);

        usuario = usuarioRepository.save(usuario);
        return usuarioMapper.toDto(usuario);
    }

    @Override
    public Usuario firstTimeDate(Long userId) {
        Usuario usuario = getUserById(userId);

        if (usuario.getLastPasswordDate() == null) {
            usuario.setLastPasswordDate(ZonedDateTime.now());
            /*usuario.getUser().setResetDate(Instant.now());
            usuario.getUser().setCreatedDate(Instant.now());*/
        }

        usuario = usuarioRepository.save(usuario);
        return usuario;
    }

    @Override
    public Optional<Usuario> getDevicesByUsuario(Long id) {
        return usuarioRepository.findOneWithEagerRelationships(id);
    }

    @Override
    public UsuarioDTO updateUsuarioWithEmail(UsuarioDTO usuarioDTO) {
        Usuario usuario = usuarioMapper.toEntity(usuarioDTO);
        usuario.setLastPasswordDate(ZonedDateTime.now());
        userService.updateUser(usuarioDTO.getUser());
        User updatedUser = userService.updateUsertipoUser(usuarioDTO.getUser());
        if (updatedUser != null) {
            mailService.sendChangemailEmail(updatedUser);
        }
        usuario.setUser(updatedUser);
        usuario = usuarioRepository.save(usuario);
        return usuarioMapper.toDto(usuario);
    }

    /**
     * Get all the Usuario with eager load of many-to-many relationships.
     *
     * @return the list of entities
     */
    public Page<UsuarioDTO> findAllWithEagerRelationships(Pageable pageable) {
        return usuarioRepository.findAllWithEagerRelationships(pageable).map(usuarioMapper::toDto);
    }

    public List<UsuarioDTO> getAll() {
        return usuarioMapper.toDto(usuarioRepository.findAll());
    }

    @Override
    public Usuario getUserById(Long id) {
        Usuario usuario = usuarioRepository.findOneById(id);
        return usuario;
    }

    @Override
    public Optional<Usuario> getUserByProviderId(Long providerId) {
        Optional<Usuario> usuario = usuarioRepository.findOneByProviderId(providerId);
        return usuario;
    }
}

package com.ute.smartcity.service.dto;

import javax.validation.constraints.NotNull;
import java.util.List;

public class HistoricalDeviceDataDTO {
    @NotNull
    private DeviceDTO deviceDTO;
    @NotNull
    private DeviceTypeDTO deviceTypeDTO;
    @NotNull
    private List<FieldsDTO> fields;

    public DeviceDTO getDeviceDTO() {
        return deviceDTO;
    }

    public void setDeviceDTO(DeviceDTO deviceDTO) {
        this.deviceDTO = deviceDTO;
    }

    public DeviceTypeDTO getDeviceTypeDTO() {
        return deviceTypeDTO;
    }

    public void setDeviceTypeDTO(DeviceTypeDTO deviceTypeDTO) {
        this.deviceTypeDTO = deviceTypeDTO;
    }

    public List<FieldsDTO> getFields() {
        return fields;
    }

    public void setFields(List<FieldsDTO> fields) {
        this.fields = fields;
    }
}

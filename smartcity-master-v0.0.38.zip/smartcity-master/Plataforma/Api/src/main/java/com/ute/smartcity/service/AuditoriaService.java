package com.ute.smartcity.service;

import com.ute.smartcity.service.dto.AuditoriaDTO;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

/**
 * Service Interface for managing Auditoria.
 */
public interface AuditoriaService {

    /**
     * Save a auditoria.
     *
     * @param auditoriaDTO the entity to save
     * @return the persisted entity
     */
    AuditoriaDTO save(AuditoriaDTO auditoriaDTO);

    /**
     * Get all the auditorias.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<AuditoriaDTO> findAll(Pageable pageable);


    /**
     * Get the "id" auditoria.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<AuditoriaDTO> findOne(Long id);

    /**
     * Delete the "id" auditoria.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}

/**
 * Data Access Objects used by WebSocket services.
 */
package com.ute.smartcity.web.websocket.dto;

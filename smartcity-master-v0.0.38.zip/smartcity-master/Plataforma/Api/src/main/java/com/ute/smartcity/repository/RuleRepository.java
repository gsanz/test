package com.ute.smartcity.repository;

import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.Rule;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * Spring Data  repository for the Rule entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RuleRepository extends JpaRepository<Rule, Long>, JpaSpecificationExecutor<Rule> {

    @Query(value = "select distinct rule from Rule rule left join fetch rule.devices",
        countQuery = "select count(distinct rule) from Rule rule")
    Page<Rule> findAllWithEagerRelationships(Pageable pageable);

    @Query(value = "select distinct rule from Rule rule left join fetch rule.devices")
    List<Rule> findAllWithEagerRelationships();

    @Query("select rule from Rule rule left join fetch rule.devices where rule.id =:id")
    Optional<Rule> findOneWithEagerRelationships(@Param("id") Long id);

    Optional<Rule> findByReference(String rule);

    Optional<List<Rule>> findByDevices(Device device);

    Optional<List<Rule>> findByDeviceTypeId(Long id);
}

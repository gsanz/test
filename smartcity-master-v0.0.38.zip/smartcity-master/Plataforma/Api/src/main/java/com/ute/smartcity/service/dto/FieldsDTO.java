package com.ute.smartcity.service.dto;

import javax.persistence.Lob;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * A DTO for the Fields entity.
 */
public class FieldsDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;


    private String abbreviation;

    private String description;

    @NotNull
    private String type;


    private String unitOfmeasure;

    private String value;

    @Lob
    private String metadata;


    private Long deviceId;

    private Long deviceTypeId;

    private String deviceReference;

    private String deviceName;

    private List<String> data;

    private List<String> labels;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnitOfmeasure() {
        return unitOfmeasure;
    }

    public void setUnitOfmeasure(String unitOfmeasure) {
        this.unitOfmeasure = unitOfmeasure;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public Long getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Long deviceId) {
        this.deviceId = deviceId;
    }

    public Long getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(Long deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FieldsDTO fieldsDTO = (FieldsDTO) o;
        if (fieldsDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), fieldsDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "FieldsDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", abbreviation='" + getAbbreviation() + "'" +
            ", description='" + getDescription() + "'" +
            ", type='" + getType() + "'" +
            ", unitOfmeasure='" + getUnitOfmeasure() + "'" +
            ", value='" + getValue() + "'" +
            ", metadata='" + getMetadata() + "'" +
            ", device=" + getDeviceId() +
            ", deviceType=" + getDeviceTypeId() +
            "}";
    }

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }

    public String getDeviceReference() {
        return deviceReference;
    }

    public void setDeviceReference(String deviceReference) {
        this.deviceReference = deviceReference;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }
}

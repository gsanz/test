package com.ute.smartcity.service.dto;

import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;

import java.io.Serializable;
import java.util.Objects;

/**
 * Criteria class for the DeviceType entity. This class is used in DeviceTypeResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /device-types?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class DeviceTypeCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter type;

    private StringFilter reference;

    private StringFilter name;

    private StringFilter search;

    private LongFilter fieldsId;

    private LongFilter usuariosId;

    public DeviceTypeCriteria() {
    }

    public LongFilter getId() {
        return id;
    }

    public StringFilter getType() {
        return type;
    }

    public void setType(StringFilter type) {
        this.type = type;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getReference() {
        return reference;
    }

    public void setReference(StringFilter reference) {
        this.reference = reference;
    }

    public StringFilter getName() {
        return name;
    }

    public void setName(StringFilter name) {
        this.name = name;
    }

    public StringFilter getSearch() {
        return search;
    }

    public void setSearch(StringFilter search) {
        this.search = search;
    }

    public LongFilter getFieldsId() {
        return fieldsId;
    }

    public void setFieldsId(LongFilter fieldsId) {
        this.fieldsId = fieldsId;
    }

    public LongFilter getUsuariosId() {
        return usuariosId;
    }

    public void setUsuariosId(LongFilter usuariosId) {
        this.usuariosId = usuariosId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final DeviceTypeCriteria that = (DeviceTypeCriteria) o;
        return
            Objects.equals(id, that.id) &&
                Objects.equals(type, that.type) &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(name, that.name) &&
                Objects.equals(fieldsId, that.fieldsId) &&
                Objects.equals(usuariosId, that.usuariosId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            id,
            type,
            reference,
            name,
            fieldsId,
            usuariosId
        );
    }

    @Override
    public String toString() {
        return "DeviceTypeCriteria{" +
            (id != null ? "id=" + id + ", " : "") +
            (type != null ? "type=" + type + ", " : "") +
            (reference != null ? "reference=" + reference + ", " : "") +
            (name != null ? "name=" + name + ", " : "") +
            (fieldsId != null ? "fieldsId=" + fieldsId + ", " : "") +
            (usuariosId != null ? "usuariosId=" + usuariosId + ", " : "") +
            "}";
    }

}

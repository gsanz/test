package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.DataModel;
import com.ute.smartcity.domain.DataModelField;
import com.ute.smartcity.domain.DeviceType;
import com.ute.smartcity.service.dto.DataModelDTO;
import com.ute.smartcity.service.dto.DeviceTypeDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * Mapper for the entity DeviceType and its DTO DeviceTypeDTO.
 */
@Mapper(componentModel = "spring", uses = {DataModelFieldMapper.class})
public interface DataModelMapper extends EntityMapper<DataModelDTO, DataModel> {

    @Mapping(target = "fields", ignore = false)
    DataModelDTO toDto(DataModel dataModel);


    default DataModel fromId(Long id) {
        if (id == null) {
            return null;
        }
        DataModel dataModel = new DataModel();
        dataModel.setId(id);
        return dataModel;
    }
}

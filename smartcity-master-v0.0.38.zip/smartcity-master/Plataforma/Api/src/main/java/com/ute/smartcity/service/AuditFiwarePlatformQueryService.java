package com.ute.smartcity.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import io.github.jhipster.service.QueryService;
import com.ute.smartcity.domain.AuditFiwarePlatform;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.AuditFiwarePlatformRepository;
import com.ute.smartcity.service.dto.AuditFiwarePlatformCriteria;
import com.ute.smartcity.service.dto.AuditFiwarePlatformDTO;
import com.ute.smartcity.service.mapper.AuditFiwarePlatformMapper;

/**
 * Service for executing complex queries for AuditFiwarePlatform entities in the database.
 * The main input is a {@link AuditFiwarePlatformCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link AuditFiwarePlatformDTO} or a {@link Page} of {@link AuditFiwarePlatformDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class AuditFiwarePlatformQueryService extends QueryService<AuditFiwarePlatform> {

    private final Logger log = LoggerFactory.getLogger(AuditFiwarePlatformQueryService.class);

    private final AuditFiwarePlatformRepository auditFiwarePlatformRepository;

    private final AuditFiwarePlatformMapper auditFiwarePlatformMapper;

    public AuditFiwarePlatformQueryService(AuditFiwarePlatformRepository auditFiwarePlatformRepository, AuditFiwarePlatformMapper auditFiwarePlatformMapper) {
        this.auditFiwarePlatformRepository = auditFiwarePlatformRepository;
        this.auditFiwarePlatformMapper = auditFiwarePlatformMapper;
    }

    /**
     * Return a {@link List} of {@link AuditFiwarePlatformDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<AuditFiwarePlatformDTO> findByCriteria(AuditFiwarePlatformCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<AuditFiwarePlatform> specification = createSpecification(criteria);
        return auditFiwarePlatformMapper.toDto(auditFiwarePlatformRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link AuditFiwarePlatformDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<AuditFiwarePlatformDTO> findByCriteria(AuditFiwarePlatformCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<AuditFiwarePlatform> specification = createSpecification(criteria);
        return auditFiwarePlatformRepository.findAll(specification, page)
            .map(auditFiwarePlatformMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(AuditFiwarePlatformCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<AuditFiwarePlatform> specification = createSpecification(criteria);
        return auditFiwarePlatformRepository.count(specification);
    }

    /**
     * Function to convert AuditFiwarePlatformCriteria to a {@link Specification}
     */
    private Specification<AuditFiwarePlatform> createSpecification(AuditFiwarePlatformCriteria criteria) {
        Specification<AuditFiwarePlatform> specification = Specification.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildSpecification(criteria.getId(), AuditFiwarePlatform_.id));
            }
            if (criteria.getDate() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getDate(), AuditFiwarePlatform_.date));
            }
            if (criteria.getType() != null) {
                specification = specification.and(buildStringSpecification(criteria.getType(), AuditFiwarePlatform_.type));
            }
            if (criteria.getRequestUrl() != null) {
                specification = specification.and(buildStringSpecification(criteria.getRequestUrl(), AuditFiwarePlatform_.requestUrl));
            }
            if (criteria.getRequestContent() != null) {
                specification = specification.and(buildStringSpecification(criteria.getRequestContent(), AuditFiwarePlatform_.requestContent));
            }
            if (criteria.getResponseContent() != null) {
                specification = specification.and(buildStringSpecification(criteria.getResponseContent(), AuditFiwarePlatform_.responseContent));
            }
            if (criteria.getResponseCode() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getResponseCode(), AuditFiwarePlatform_.responseCode));
            }
        }
        return specification;
    }
}

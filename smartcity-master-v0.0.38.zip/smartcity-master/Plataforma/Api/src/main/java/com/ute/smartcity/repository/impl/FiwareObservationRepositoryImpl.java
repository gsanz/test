package com.ute.smartcity.repository.impl;

import com.mongodb.*;
import com.ute.smartcity.repository.DeviceObservationRepository;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.DeviceObservationCriteria;
import net.minidev.json.JSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;


@Repository
@Primary
@Profile({"fiware"})
public class FiwareObservationRepositoryImpl implements DeviceObservationRepository {

    private final Logger log = LoggerFactory.getLogger(FiwareObservationRepositoryImpl.class);

    @Value("${application.fiware.mongo.host}")
    private String mongoServerUrl;

    @Value("${application.fiware.mongo.port}")
    private Integer mongoServerPort;

    @Value("${application.fiware.mongo.database}")
    private String mongoDatabase;

    public static final String recvTime = "recvTime";

    public Page<JSONObject> findAll(DeviceDTO device, DeviceObservationCriteria criteria, Pageable pageable, String dateFieldToFilter) {
        Page<JSONObject> map = null;
        if (device != null && criteria != null) {
            log.debug("FindAllObservation from device : {} with criteria : {}", device.toString(), criteria.toString());

            String collectionName = "sth_/" + device.getDeviceTypeReference();

            long pageNumber = pageable.getPageNumber();
            int pageSize = pageable.getPageSize();
            criteria.setDevice(device.getReference());
            MongoTemplate template = getMongoTemplate();

            Query query = createQuery(criteria, dateFieldToFilter);

            long total = template.count(query, Document.class, collectionName);
            log.debug("Total number of observations {} ", total);
            query.limit(pageSize).skip(pageNumber * pageSize);
            log.debug("limit number of observations to {} ", pageSize);
            List<Document> documentList = template.find(query, Document.class, collectionName);

            Collections.reverse(documentList);
            Page<Document> page = new PageImpl<>(documentList, pageable, total);
            log.debug("Map observations  ");
            map = page.map(entity -> {
                JSONObject dto = new JSONObject();

                for (Map.Entry entry : entity.entrySet()) {
                    String key = (String) entry.getKey();

                    if (key.contains(dateFieldToFilter) && dateFieldToFilter.equals(recvTime)) {
                        Date date = entity.getDate(key);
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
                        dto.put(key, simpleDateFormat.format(date));
                    } else if (key.contains(dateFieldToFilter) && !dateFieldToFilter.equals(recvTime)) {
                        String dateString = entity.getString(key);
                        dto.put(key, dateString);
                    } else {
                        Object value = entity.get(key);
                        dto.put(key, value);
                    }
                }
                log.debug("observation map {}", entity.toString());
                return dto;
            });


        }

        return map;

    }

    private MongoTemplate getMongoTemplate() {

        String host = mongoServerUrl.replace("http://", "");
        host = host.replace("https://", "");
        log.debug("Connecting to  {}:{}:{} ", host, mongoServerPort, mongoDatabase);
        MongoClient mongo = new MongoClient(host, mongoServerPort);
        return new MongoTemplate(mongo, mongoDatabase);
    }

    private Query createQuery(DeviceObservationCriteria criteria, String dateFieldToFilter) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime fromDateTime = null;
        LocalDateTime toDateTime = null;
        Query query = new Query();
        if (criteria.getDevice() != null) {

            query.addCriteria(Criteria.where("entityId").is(criteria.getDevice()));
        }
        if (criteria.getDeviceType() != null) {
            query.addCriteria(Criteria.where("entityType").is(criteria.getDeviceType()));
        }
        if ((criteria.getFromDate() != null) || (criteria.getToDate() != null)) {
            Criteria dateCriteria = Criteria.where(dateFieldToFilter);

            if (criteria.getFromDate() != null) {
                try {
                    String fromDate = criteria.getFromDate();
                    if (dateFieldToFilter.equals(recvTime)) {
                        fromDateTime = LocalDate.parse(fromDate, dtf).atStartOfDay();
                        dateCriteria.gte(fromDateTime);
                    } else {
                        dateCriteria.gte(fromDate);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
            }
            if (criteria.getToDate() != null) {
                try {
                    String toDate = criteria.getToDate();
                    toDateTime = LocalDate.parse(toDate, dtf).atStartOfDay();
                    boolean isTheSameDay = toDateTime.equals(fromDateTime);
                    if (isTheSameDay) {
                        toDateTime = toDateTime.plusDays(1);
                    }
                    if (dateFieldToFilter.equals(recvTime)) {
                        dateCriteria.lt(toDateTime);
                    } else {
                        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
                        String formattedDateTime = toDateTime.format(formatter);
                        dateCriteria.lt(formattedDateTime);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
            }

            query.addCriteria(dateCriteria);
        }
        query.with(new Sort(Sort.Direction.DESC, dateFieldToFilter));
        return query;
    }
}

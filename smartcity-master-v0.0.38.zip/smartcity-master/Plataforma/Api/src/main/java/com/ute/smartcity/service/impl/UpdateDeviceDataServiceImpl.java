package com.ute.smartcity.service.impl;


import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.ute.smartcity.domain.Alert;
import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.enumeration.AlertState;
import com.ute.smartcity.domain.enumeration.CriticalityLevel;
import com.ute.smartcity.domain.enumeration.DeviceAlert;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.AlertDTO;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.FieldsDTO;
import com.ute.smartcity.service.exception.fiware.HttpOrionConnectionException;
import com.ute.smartcity.service.exception.IllegalTypeException;
import com.ute.smartcity.service.exception.fiware.OrionException;
import com.ute.smartcity.service.mapper.AlertMapper;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.EntityFiwareAdapter;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.web.rest.DeviceResourceExt;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ute.smartcity.service.UpdateDeviceDataService;


import java.time.Instant;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class UpdateDeviceDataServiceImpl implements UpdateDeviceDataService {

    private final Logger log = LoggerFactory.getLogger(DeviceResourceExt.class);

    private final DeviceService deviceService;

    private final FieldsService fieldsService;

    private final AlertService alertService;

    private final EntityFiwareAdapter entityFiwareAdapter;

    private final SmartCityPlatformService smartCityPlatformService;

    private final MailService mailService;

    private final AlertMapper alertMapper;

    private final DeviceMapper deviceMapper;

    public UpdateDeviceDataServiceImpl(DeviceService deviceService, FieldsService fieldsService,
                                       AlertService alertService, EntityFiwareAdapter entityFiwareAdapter, SmartCityPlatformService smartCityPlatformService, MailService mailService, AlertMapper alertMapper, DeviceMapper deviceMapper) {
        this.deviceService = deviceService;
        this.fieldsService = fieldsService;
        this.alertService = alertService;
        this.entityFiwareAdapter = entityFiwareAdapter;
        this.smartCityPlatformService = smartCityPlatformService;
        this.mailService = mailService;
        this.alertMapper = alertMapper;
        this.deviceMapper = deviceMapper;
    }

    @Override
    public void updateDeviceData(Device device, String data, String reference) throws HttpOrionConnectionException,
        OrionException, IllegalTypeException {

        //Obtener Campos
        Optional<List<FieldsDTO>> campos = fieldsService.findByDeviceId(device.getId());
        if(!campos.isPresent()) {
            log.debug("REST request to updateDeviceData Device : {There are no fields in that device }", device);
            throw new BadRequestAlertException("There are no fields in that device", "updateDeviceData", device.toString());
        }
        //Casar campos
        //boolean updateEntity = true;
       // entityFiwareAdapter.DeviceToEntity(device,updateEntity)
        String entity = entityFiwareAdapter.dataToEntityJson(data, campos);

        //enviar a smartCityService
        smartCityPlatformService.updateDeviceData(entity, reference, device.getDeviceType().getReference());

    }
    @Override
    @Transactional
    @Scheduled(cron = "0 0 * * * *")
    public void syncDevices() throws HttpOrionConnectionException, OrionException {

        String fiwareEntities = smartCityPlatformService.getAllDevices();

        JsonArray parsedFiwareEntities = new JsonParser().parse(fiwareEntities).getAsJsonArray();

        for (JsonElement entity: parsedFiwareEntities) {
            DeviceDTO deviceDTO = entityFiwareAdapter.entitiesToDevice(entity);
            if(deviceDTO != null) {
                if(deviceDTO.getState().equals(DeviceAlert.ERROR.toString())) {
                    AlertDTO alertDTO = getAlertDTO(deviceDTO);
                    alertService.save(alertDTO);
                    Alert alert = alertMapper.toEntity(alertDTO);
                    alert.setDevice(deviceMapper.toEntity(deviceDTO));
                    mailService.sendAlertMail(alert);
                }
                deviceService.save(deviceDTO);
                Optional<List<FieldsDTO>> campos = fieldsService.findByDeviceId(deviceDTO.getId());
                if(campos.isPresent()) {
                    for (Map.Entry<String, JsonElement> entry : entity.getAsJsonObject().entrySet()) {
                        for (FieldsDTO campo : campos.get()) {
                            FieldsDTO campoCasado = entityFiwareAdapter.fiwareFieldValueToDeviceFieldValue(entry, campo);
                            fieldsService.save(campoCasado);
                        }
                    }
                }
            }
        }
    }

    private AlertDTO getAlertDTO(DeviceDTO deviceDTO) {
        AlertDTO alertDTO = new AlertDTO();
        alertDTO.setCriticalityLevel(CriticalityLevel.CRITICAL);
        alertDTO.setReference(deviceDTO.getReference());
        alertDTO.setState(AlertState.OPEN);
        alertDTO.setDeviceId(deviceDTO.getId());
        alertDTO.setCreateAt(Instant.now().atZone(ZoneId.of("Europe/Madrid")));
        alertDTO.setDescription("Dispositivo sin conexión");
        return alertDTO;
    }
}

package com.ute.smartcity.web.rest;

import com.ute.smartcity.service.AlertService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.AlertDTO;
import com.ute.smartcity.service.dto.AlertCriteria;
import com.ute.smartcity.service.AlertQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Alert.
 */
@RestController
@RequestMapping("/api")
@Api(value="alerts", description="Alert Resource",tags = "alert-resource")
public class AlertResource {

    private final Logger log = LoggerFactory.getLogger(AlertResource.class);

    private static final String ENTITY_NAME = "alert";

    private final AlertService alertService;

    private final AlertQueryService alertQueryService;

    public AlertResource(AlertService alertService, AlertQueryService alertQueryService) {
        this.alertService = alertService;
        this.alertQueryService = alertQueryService;
    }



    /**
     * GET  /alerts : get all the alerts.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of alerts in body
     */
    @GetMapping("/alerts")
    public ResponseEntity<List<AlertDTO>> getAllAlerts(AlertCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Alerts by criteria: {}", criteria);
        Page<AlertDTO> page = alertQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/alerts");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /**
     * GET  /alerts/:id : get the "id" alert.
     *
     * @param id the id of the alertDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the alertDTO, or with status 404 (Not Found)
     */
    @GetMapping("/alerts/{id}")
    public ResponseEntity<AlertDTO> getAlert(@PathVariable Long id) {
        log.debug("REST request to get Alert : {}", id);
        Optional<AlertDTO> alertDTO = alertService.findOne(id);
        return ResponseUtil.wrapOrNotFound(alertDTO);
    }

    /**
     * DELETE  /alerts/:id : delete the "id" alert.
     *
     * @param id the id of the alertDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/alerts/{id}")
    @ResourceAudit(ENTITY_NAME)
    public ResponseEntity<Void> deleteAlert(@PathVariable Long id) {
        log.debug("REST request to delete Alert : {}", id);
        alertService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

package com.ute.smartcity.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

import com.ute.smartcity.domain.enumeration.CompareType;

/**
 * A RuleCompareFields.
 */
@Entity
@Table(name = "rule_compare_fields")
public class RuleCompareFields implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "compare_type")
    private CompareType compareType;

    @Column(name = "jhi_value")
    private String value;

    @Column(name = "field_name")
    private String fieldName;

    @Column(name = "field_type")
    private String fieldType;

    @ManyToOne
    @JsonIgnoreProperties("ruleCompareFields")
    private Rule rule;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CompareType getCompareType() {
        return compareType;
    }

    public RuleCompareFields compareType(CompareType compareType) {
        this.compareType = compareType;
        return this;
    }

    public void setCompareType(CompareType compareType) {
        this.compareType = compareType;
    }

    public String getValue() {
        return value;
    }

    public RuleCompareFields value(String value) {
        this.value = value;
        return this;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getFieldName() {
        return fieldName;
    }

    public RuleCompareFields fieldName(String fieldName) {
        this.fieldName = fieldName;
        return this;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldType() {
        return fieldType;
    }

    public RuleCompareFields fieldType(String fieldType) {
        this.fieldType = fieldType;
        return this;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    public Rule getRule() {
        return rule;
    }

    public RuleCompareFields rule(Rule rule) {
        this.rule = rule;
        return this;
    }

    public void setRule(Rule rule) {
        this.rule = rule;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RuleCompareFields ruleCompareFields = (RuleCompareFields) o;
        if (ruleCompareFields.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), ruleCompareFields.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RuleCompareFields{" +
            "id=" + getId() +
            ", compareType='" + getCompareType() + "'" +
            ", value='" + getValue() + "'" +
            ", fieldName='" + getFieldName() + "'" +
            ", fieldType='" + getFieldType() + "'" +
            "}";
    }
}

package com.ute.smartcity.domain.enumeration;

/**
 * The CompareType enumeration.
 */
public enum CompareType {
    EQUALS, GREATER_THAN, GREAT_THAN_OR_EQUAL_TO, LESS_THAN, LESS_THAN_OR_EQUAL_TO
}

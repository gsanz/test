package com.ute.smartcity.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Fields.
 */
@Entity
@Table(name = "fields")
public class Fields implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "abbreviation")
    private String abbreviation;

    @Column(name = "description")
    private String description;

    @NotNull
    @Column(name = "jhi_type", nullable = false)
    private String type;

    @Column(name = "unit_ofmeasure")
    private String unitOfmeasure;

    @Column(name = "jhi_value")
    private String value;

    @Lob
    @Column(name = "metadata")
    private String metadata;

    @ManyToOne
    @JsonIgnoreProperties("fields")
    private Device device;

    @ManyToOne
    @JsonIgnoreProperties("fields")
    private DeviceType deviceType;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Fields name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public Fields abbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
        return this;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getDescription() {
        return description;
    }

    public Fields description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public Fields type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnitOfmeasure() {
        return unitOfmeasure;
    }

    public Fields unitOfmeasure(String unitOfmeasure) {
        this.unitOfmeasure = unitOfmeasure;
        return this;
    }

    public void setUnitOfmeasure(String unitOfmeasure) {
        this.unitOfmeasure = unitOfmeasure;
    }

    public String getValue() {
        return value;
    }

    public Fields value(String value) {
        this.value = value;
        return this;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getMetadata() {
        return metadata;
    }

    public Fields metadata(String metadata) {
        this.metadata = metadata;
        return this;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public Device getDevice() {
        return device;
    }

    public Fields device(Device device) {
        this.device = device;
        return this;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public Fields deviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
        return this;
    }

    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Fields fields = (Fields) o;
        if (fields.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), fields.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Fields{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", abbreviation='" + getAbbreviation() + "'" +
            ", description='" + getDescription() + "'" +
            ", type='" + getType() + "'" +
            ", unitOfmeasure='" + getUnitOfmeasure() + "'" +
            ", value='" + getValue() + "'" +
            ", metadata='" + getMetadata() + "'" +
            "}";
    }
}

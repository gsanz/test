package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.RuleActionDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity RuleAction and its DTO RuleActionDTO.
 */
@Mapper(componentModel = "spring", uses = {RuleMapper.class})
public interface RuleActionMapper extends EntityMapper<RuleActionDTO, RuleAction> {

    @Mapping(source = "rule.id", target = "ruleId")
    RuleActionDTO toDto(RuleAction ruleAction);

    @Mapping(source = "ruleId", target = "rule")
    @Mapping(target = "ruleUpdateFields", ignore = true)
    RuleAction toEntity(RuleActionDTO ruleActionDTO);

    default RuleAction fromId(Long id) {
        if (id == null) {
            return null;
        }
        RuleAction ruleAction = new RuleAction();
        ruleAction.setId(id);
        return ruleAction;
    }
}

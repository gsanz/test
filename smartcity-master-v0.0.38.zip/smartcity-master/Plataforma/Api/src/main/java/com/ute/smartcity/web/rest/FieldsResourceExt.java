package com.ute.smartcity.web.rest;

import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.DeviceService;
import com.ute.smartcity.service.DeviceTypeService;
import com.ute.smartcity.service.FieldsQueryService;
import com.ute.smartcity.service.FieldsService;
import com.ute.smartcity.service.audit.annotation.ResourceAudit;
import com.ute.smartcity.service.dto.DeviceDTO;
import com.ute.smartcity.service.dto.FieldsCriteria;
import com.ute.smartcity.service.dto.FieldsDTO;
import com.ute.smartcity.service.exception.NullDevicePropertyException;
import com.ute.smartcity.service.exception.fiware.HttpIOTAgentConnectionException;
import com.ute.smartcity.service.exception.fiware.IOTAgentException;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.DeviceTypeMapper;
import com.ute.smartcity.service.mapper.FieldsMapper;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.service.util.ValidatorUtil;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * REST controller for managing Fields.
 */
@RestController
@RequestMapping("/api")
public class FieldsResourceExt {

    private final Logger log = LoggerFactory.getLogger(FieldsResourceExt.class);

    private static final String ENTITY_NAME = "fields";

    private final FieldsService fieldsService;

    private final DeviceService deviceService;

    private final SmartCityPlatformService smartCityPlatformService;

    public static final Pattern NAME_PATTERN =
        Pattern.compile("^[a-zA-Z0-9_]*$", Pattern.CASE_INSENSITIVE);

    public FieldsResourceExt(FieldsService fieldsService, DeviceService deviceService, SmartCityPlatformService smartCityPlatformService) {
        this.fieldsService = fieldsService;
        this.deviceService = deviceService;
        this.smartCityPlatformService = smartCityPlatformService;
    }

    /**
     * POST  /fields : Create a new fields.
     *
     * @param fieldsDTO the fieldsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new fieldsDTO, or with status 400 (Bad Request) if the fields has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */

    @PostMapping("/fields")
    @Transactional
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<FieldsDTO> createFields(@Valid @RequestBody FieldsDTO fieldsDTO) throws URISyntaxException, IOTAgentException, HttpIOTAgentConnectionException, NullDevicePropertyException {
        log.debug("REST request to save Fields : {}", fieldsDTO);
        if (fieldsDTO.getId() != null) {
            throw new BadRequestAlertException("A new fields cannot already have an ID", ENTITY_NAME, "idexists");
        }
        String name = fieldsDTO.getName().trim();
        if (name.length() <= 0) {
            throw new BadRequestAlertException("A new fields needs to have a name", ENTITY_NAME, "noname");
        }
        String type = fieldsDTO.getType().trim();
        if (type.length() <= 0) {
            throw new BadRequestAlertException("A new fields needs to have a type", ENTITY_NAME, "notype");
        }

        if((fieldsDTO.getDeviceId() == null) && (fieldsDTO.getDeviceTypeId() == null)) {
            throw new BadRequestAlertException("El campo no tiene ningun dispositivo o tipo de dispositivo asignado", ENTITY_NAME, "noname");
        }

        ValidatorUtil validator = new ValidatorUtil();

        if (!validator.validate(fieldsDTO.getName(), NAME_PATTERN)) {
            log.debug("Invalid name: " + fieldsDTO.getName() + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Bad reference characters", ENTITY_NAME, "referenceInvalid");
        }

        if (fieldsDTO.getDeviceId() != null) {
            long idDevice = fieldsDTO.getDeviceId();
            try {
                updateFields(idDevice, fieldsDTO, false);
            } catch (PlatformException e) {
                log.error("Error al crear campos en plataforma {}", e.getMessage());
                throw new BadRequestAlertException("There was an error trying to save the field to fiware", ENTITY_NAME, "fail-save-orion-field");
            }
        }

        FieldsDTO result = fieldsService.save(fieldsDTO);

        return ResponseEntity.created(new URI("/api/fields/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /fields : Updates an existing fields.
     *
     * @param fieldsDTO the fieldsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated fieldsDTO,
     * or with status 400 (Bad Request) if the fieldsDTO is not valid,
     * or with status 500 (Internal Server Error) if the fieldsDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */

    @PutMapping("/fields")
    @Transactional
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<FieldsDTO> updateFields(@Valid @RequestBody FieldsDTO fieldsDTO) throws IOTAgentException, HttpIOTAgentConnectionException, NullDevicePropertyException {
        log.debug("REST request to update Fields : {}", fieldsDTO);
        if (fieldsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String name = fieldsDTO.getName().trim();
        if (name.length() <= 0) {
            throw new BadRequestAlertException("A new fields needs to have a name", ENTITY_NAME, "noname");
        }
        if((fieldsDTO.getDeviceId() == null) && (fieldsDTO.getDeviceTypeId() == null)) {
            throw new BadRequestAlertException("El campo no tiene ningun dispositivo o tipo de dispositivo asignado", ENTITY_NAME, "noname");
        }

        ValidatorUtil validator = new ValidatorUtil();

        if (!validator.validate(fieldsDTO.getName(), NAME_PATTERN)) {
            log.debug("Invalid name: " + fieldsDTO.getName() + " " + ENTITY_NAME);
            throw new BadRequestAlertException("Bad reference characters", ENTITY_NAME, "referenceInvalid");
        }

        FieldsDTO result = fieldsService.save(fieldsDTO);
        if (fieldsDTO.getDeviceId() != null) {
            long idDevice = fieldsDTO.getDeviceId();
            try {
                updateFields(idDevice, result, false);
            } catch (PlatformException e) {
                log.error("Error al actualizar campos en plataforma {}", e.getMessage());
                throw new BadRequestAlertException("There was an error trying to update the field to fiware", ENTITY_NAME, "fail-save-orion-field");
            }
        }
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, fieldsDTO.getId().toString()))
            .body(result);
    }

    /**
     * DELETE  /fields/:id : delete the "id" fields.
     *
     * @param id the id of the fieldsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/fields/{id}")
    @Transactional
    @ResourceAudit(ENTITY_NAME)
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<Void> deleteFields(@PathVariable Long id) {
        log.debug("REST request to delete Fields : {}", id);

        Optional<FieldsDTO> optionalFieldsDTO = fieldsService.findOne(id);

        if (!optionalFieldsDTO.isPresent()) {
            throw new BadRequestAlertException("No se ha encontrado el campo", ENTITY_NAME, "nofield");
        }
        FieldsDTO fieldsDTO = optionalFieldsDTO.get();

        if((fieldsDTO.getDeviceId() == null) && (fieldsDTO.getDeviceTypeId() == null)) {
            throw new BadRequestAlertException("El campo no tiene ningun dispositivo con ID asignado", ENTITY_NAME, "noname");
        }

        fieldsService.delete(id);

        if (fieldsDTO.getDeviceId() != null) {
            long idDevice = fieldsDTO.getDeviceId();
            try {
                updateFields(idDevice, fieldsDTO, true);
            } catch (Exception e) {
                log.error("error al actualizar campos de un dispositivo", e.getMessage());
                throw new BadRequestAlertException("There was an error trying to save the device to fiware", ENTITY_NAME, "fail-delete-orion-field");
            }
        }
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    private void updateFields(long idDevice, FieldsDTO field, boolean isDeleting) throws IOTAgentException, HttpIOTAgentConnectionException, NullDevicePropertyException, PlatformException {
        Optional<DeviceDTO> deviceDTOOptional = deviceService.findOne(idDevice);
        boolean deviceExists = (deviceDTOOptional.isPresent());
        if (deviceExists) {
            Set<FieldsDTO> fields = deviceDTOOptional.get().getFields();
            if (!isDeleting) {
                fields.add(field);
                deviceDTOOptional.get().setFields(fields);
            } else {
                fields.remove(field);
                deviceDTOOptional.get().setFields(fields);
            }

            DeviceDTO deviceDTO = deviceDTOOptional.get();
            smartCityPlatformService.updateDevice(deviceDTO);
            if (deviceDTO.getProtocolId() != null) {
                smartCityPlatformService.updateIoTDevice(deviceDTO);
            }
        } else {
            log.error("El field no tiene asignado ningun tipo de dispositivo");
        }
    }
}

package com.ute.smartcity.service.exception;

import com.google.gson.JsonElement;
import com.ute.smartcity.web.rest.DeviceResourceExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IllegalTypeException extends Exception {
    private final Logger log = LoggerFactory.getLogger(DeviceResourceExt.class);
    public IllegalTypeException(IllegalArgumentException e, String type, JsonElement contentValue) {
        log.error("Failed trying to parse the value: \" "+contentValue+"\" to type: \" "+type+"\". " + e.getMessage());
    }
}

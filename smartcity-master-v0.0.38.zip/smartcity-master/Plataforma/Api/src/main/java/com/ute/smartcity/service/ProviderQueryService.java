package com.ute.smartcity.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ute.smartcity.domain.Provider;
import com.ute.smartcity.domain.*; // for static metamodels
import com.ute.smartcity.repository.ProviderRepository;
import com.ute.smartcity.service.dto.ProviderCriteria;
import com.ute.smartcity.service.dto.ProviderDTO;
import com.ute.smartcity.service.mapper.ProviderMapper;

/**
 * Service for executing complex queries for Provider entities in the database.
 * The main input is a {@link ProviderCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link ProviderDTO} or a {@link Page} of {@link ProviderDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class ProviderQueryService extends QueryServiceExtended<Provider> {

    private final Logger log = LoggerFactory.getLogger(ProviderQueryService.class);

    private final ProviderRepository providerRepository;

    private final ProviderMapper providerMapper;

    public ProviderQueryService(ProviderRepository providerRepository, ProviderMapper providerMapper) {
        this.providerRepository = providerRepository;
        this.providerMapper = providerMapper;
    }

    /**
     * Return a {@link List} of {@link ProviderDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<ProviderDTO> findByCriteria(ProviderCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<Provider> specification = createSpecification(criteria);
        return providerMapper.toDto(providerRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link ProviderDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<ProviderDTO> findByCriteria(ProviderCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<Provider> specification = createSpecification(criteria);
        return providerRepository.findAll(specification, page)
            .map(providerMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(ProviderCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<Provider> specification = createSpecification(criteria);
        return providerRepository.count(specification);
    }

    /**
     * Function to convert ProviderCriteria to a {@link Specification}
     */
    private Specification<Provider> createSpecification(ProviderCriteria criteria) {
        Specification<Provider> specification = Specification.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildSpecification(criteria.getId(), Provider_.id));
            }
            if (criteria.getSearch() != null) {
                Specification<Provider> busquedaPorTexto = Specification.where(buildStringSpecification(criteria.getSearch(), Provider_.name));
                specification = specification.and(busquedaPorTexto);
            }
            if (criteria.getName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getName(), Provider_.name));
            }
            if (criteria.getAddress() != null) {
                specification = specification.and(buildStringSpecification(criteria.getAddress(), Provider_.address));
            }
            if (criteria.getMobile() != null) {
                specification = specification.and(buildStringSpecification(criteria.getMobile(), Provider_.mobile));
            }
            if (criteria.getEmail() != null) {
                specification = specification.and(buildStringSpecification(criteria.getEmail(), Provider_.email));
            }
        }
        return specification;
    }
}

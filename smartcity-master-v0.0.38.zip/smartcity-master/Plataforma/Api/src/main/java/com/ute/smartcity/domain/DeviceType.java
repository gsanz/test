package com.ute.smartcity.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A DeviceType.
 */
@ApiModel(description = "The DeviceType entity. @author javi.jimenez")
@Entity
@Table(name = "device_type")
public class DeviceType implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "type", nullable = false)
    private String type;

    @NotNull
    @Column(name = "reference", nullable = false)
    private String reference;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @Lob
    @Column(name = "image")
    private byte[] image;

    @Column(name = "image_content_type")
    private String imageContentType;

    @Lob
    @Column(name = "image_marker")
    private byte[] imageMarker;

    @Column(name = "image_marker_content_type")
    private String imageMarkerContentType;

    @Column(name = "create_at")
    private ZonedDateTime createAt;

    @Column(name = "delete_at")
    private ZonedDateTime deleteAt;

    @Column(name = "update_at")
    private ZonedDateTime updateAt;

    @ApiModelProperty(value = "DeviceType (1) <---> (*) Fields")
    @OneToMany(mappedBy = "deviceType", cascade = CascadeType.REMOVE, orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<Fields> fields = new HashSet<>();

    @ManyToMany(mappedBy = "devicesTypes")
    @JsonIgnore
    private Set<Usuario> usuarios = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public DeviceType type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReference() {
        return reference;
    }

    public DeviceType reference(String reference) {
        this.reference = reference;
        return this;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getName() {
        return name;
    }

    public DeviceType name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getImage() {
        return image;
    }

    public DeviceType image(byte[] image) {
        this.image = image;
        return this;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getImageContentType() {
        return imageContentType;
    }

    public DeviceType imageContentType(String imageContentType) {
        this.imageContentType = imageContentType;
        return this;
    }

    public void setImageContentType(String imageContentType) {
        this.imageContentType = imageContentType;
    }

    public byte[] getImageMarker() {
        return imageMarker;
    }

    public DeviceType imageMarker(byte[] imageMarker) {
        this.imageMarker = imageMarker;
        return this;
    }

    public void setImageMarker(byte[] imageMarker) {
        this.imageMarker = imageMarker;
    }

    public String getImageMarkerContentType() {
        return imageMarkerContentType;
    }

    public DeviceType imageMarkerContentType(String imageMarkerContentType) {
        this.imageMarkerContentType = imageMarkerContentType;
        return this;
    }

    public void setImageMarkerContentType(String imageMarkerContentType) {
        this.imageMarkerContentType = imageMarkerContentType;
    }

    public ZonedDateTime getCreateAt() {
        return createAt;
    }

    public DeviceType createAt(ZonedDateTime createAt) {
        this.createAt = createAt;
        return this;
    }

    public void setCreateAt(ZonedDateTime createAt) {
        this.createAt = createAt;
    }

    public ZonedDateTime getDeleteAt() {
        return deleteAt;
    }

    public DeviceType deleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
        return this;
    }

    public void setDeleteAt(ZonedDateTime deleteAt) {
        this.deleteAt = deleteAt;
    }

    public ZonedDateTime getUpdateAt() {
        return updateAt;
    }

    public DeviceType updateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
        return this;
    }

    public void setUpdateAt(ZonedDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public Set<Fields> getFields() {
        return fields;
    }

    public DeviceType fields(Set<Fields> fields) {
        this.fields = fields;
        return this;
    }

    public DeviceType addFields(Fields fields) {
        this.fields.add(fields);
        fields.setDeviceType(this);
        return this;
    }

    public DeviceType removeFields(Fields fields) {
        this.fields.remove(fields);
        fields.setDeviceType(null);
        return this;
    }

    public void setFields(Set<Fields> fields) {
        this.fields = fields;
    }

    public Set<Usuario> getUsuarios() {
        return usuarios;
    }

    public DeviceType usuarios(Set<Usuario> usuarios) {
        this.usuarios = usuarios;
        return this;
    }

    public DeviceType addUsuarios(Usuario usuario) {
        this.usuarios.add(usuario);
        usuario.getDevicesTypes().add(this);
        return this;
    }

    public DeviceType removeUsuarios(Usuario usuario) {
        this.usuarios.remove(usuario);
        usuario.getDevicesTypes().remove(this);
        return this;
    }

    public void setUsuarios(Set<Usuario> usuarios) {
        this.usuarios = usuarios;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DeviceType deviceType = (DeviceType) o;
        if (deviceType.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), deviceType.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "DeviceType{" +
            "id=" + getId() +
            ", type='" + getType() + "'" +
            ", reference='" + getReference() + "'" +
            ", name='" + getName() + "'" +
            ", image='" + getImage() + "'" +
            ", imageContentType='" + getImageContentType() + "'" +
            ", imageMarker='" + getImageMarker() + "'" +
            ", imageMarkerContentType='" + getImageMarkerContentType() + "'" +
            ", createAt='" + getCreateAt() + "'" +
            ", deleteAt='" + getDeleteAt() + "'" +
            ", updateAt='" + getUpdateAt() + "'" +
            "}";
    }
}

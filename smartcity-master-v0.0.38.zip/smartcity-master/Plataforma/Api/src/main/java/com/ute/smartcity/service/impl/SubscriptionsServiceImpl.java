package com.ute.smartcity.service.impl;

import com.ute.smartcity.service.SubscriptionsService;
import com.ute.smartcity.domain.Subscriptions;
import com.ute.smartcity.repository.SubscriptionsRepository;
import com.ute.smartcity.service.dto.SubscriptionsDTO;
import com.ute.smartcity.service.mapper.SubscriptionsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing Subscriptions.
 */
@Service
@Transactional
public class SubscriptionsServiceImpl implements SubscriptionsService {

    private final Logger log = LoggerFactory.getLogger(SubscriptionsServiceImpl.class);

    private final SubscriptionsRepository subscriptionsRepository;

    private final SubscriptionsMapper subscriptionsMapper;

    public SubscriptionsServiceImpl(SubscriptionsRepository subscriptionsRepository, SubscriptionsMapper subscriptionsMapper) {
        this.subscriptionsRepository = subscriptionsRepository;
        this.subscriptionsMapper = subscriptionsMapper;
    }

    /**
     * Save a subscriptions.
     *
     * @param subscriptionsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public SubscriptionsDTO save(SubscriptionsDTO subscriptionsDTO) {
        log.debug("Request to save Subscriptions : {}", subscriptionsDTO);
        Subscriptions subscriptions = subscriptionsMapper.toEntity(subscriptionsDTO);
        subscriptions = subscriptionsRepository.save(subscriptions);
        return subscriptionsMapper.toDto(subscriptions);
    }

    /**
     * Get all the subscriptions.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<SubscriptionsDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Subscriptions");
        return subscriptionsRepository.findAll(pageable)
            .map(subscriptionsMapper::toDto);
    }


    /**
     * Get one subscriptions by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<SubscriptionsDTO> findOne(Long id) {
        log.debug("Request to get Subscriptions : {}", id);
        return subscriptionsRepository.findById(id)
            .map(subscriptionsMapper::toDto);
    }

    /**
     * Delete the subscriptions by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Subscriptions : {}", id);
        subscriptionsRepository.deleteById(id);
    }
}

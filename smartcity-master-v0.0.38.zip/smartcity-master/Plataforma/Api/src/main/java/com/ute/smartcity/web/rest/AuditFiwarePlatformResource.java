package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.AuditFiwarePlatformService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.AuditFiwarePlatformDTO;
import com.ute.smartcity.service.dto.AuditFiwarePlatformCriteria;
import com.ute.smartcity.service.AuditFiwarePlatformQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing AuditFiwarePlatform.
 */
@RestController
@RequestMapping("/api")
public class AuditFiwarePlatformResource {

    private final Logger log = LoggerFactory.getLogger(AuditFiwarePlatformResource.class);

    private static final String ENTITY_NAME = "auditFiwarePlatform";

    private final AuditFiwarePlatformService auditFiwarePlatformService;

    private final AuditFiwarePlatformQueryService auditFiwarePlatformQueryService;

    public AuditFiwarePlatformResource(AuditFiwarePlatformService auditFiwarePlatformService, AuditFiwarePlatformQueryService auditFiwarePlatformQueryService) {
        this.auditFiwarePlatformService = auditFiwarePlatformService;
        this.auditFiwarePlatformQueryService = auditFiwarePlatformQueryService;
    }

    /**
     * POST  /audit-fiware-platforms : Create a new auditFiwarePlatform.
     *
     * @param auditFiwarePlatformDTO the auditFiwarePlatformDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new auditFiwarePlatformDTO, or with status 400 (Bad Request) if the auditFiwarePlatform has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/audit-fiware-platforms")
    public ResponseEntity<AuditFiwarePlatformDTO> createAuditFiwarePlatform(@Valid @RequestBody AuditFiwarePlatformDTO auditFiwarePlatformDTO) throws URISyntaxException {
        log.debug("REST request to save AuditFiwarePlatform : {}", auditFiwarePlatformDTO);
        if (auditFiwarePlatformDTO.getId() != null) {
            throw new BadRequestAlertException("A new auditFiwarePlatform cannot already have an ID", ENTITY_NAME, "idexists");
        }
        AuditFiwarePlatformDTO result = auditFiwarePlatformService.save(auditFiwarePlatformDTO);
        return ResponseEntity.created(new URI("/api/audit-fiware-platforms/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /audit-fiware-platforms : Updates an existing auditFiwarePlatform.
     *
     * @param auditFiwarePlatformDTO the auditFiwarePlatformDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated auditFiwarePlatformDTO,
     * or with status 400 (Bad Request) if the auditFiwarePlatformDTO is not valid,
     * or with status 500 (Internal Server Error) if the auditFiwarePlatformDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/audit-fiware-platforms")
    public ResponseEntity<AuditFiwarePlatformDTO> updateAuditFiwarePlatform(@Valid @RequestBody AuditFiwarePlatformDTO auditFiwarePlatformDTO) throws URISyntaxException {
        log.debug("REST request to update AuditFiwarePlatform : {}", auditFiwarePlatformDTO);
        if (auditFiwarePlatformDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        AuditFiwarePlatformDTO result = auditFiwarePlatformService.save(auditFiwarePlatformDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, auditFiwarePlatformDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /audit-fiware-platforms : get all the auditFiwarePlatforms.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of auditFiwarePlatforms in body
     */
    @GetMapping("/audit-fiware-platforms")
    public ResponseEntity<List<AuditFiwarePlatformDTO>> getAllAuditFiwarePlatforms(AuditFiwarePlatformCriteria criteria, Pageable pageable) {
        log.debug("REST request to get AuditFiwarePlatforms by criteria: {}", criteria);
        Page<AuditFiwarePlatformDTO> page = auditFiwarePlatformQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/audit-fiware-platforms");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
    * GET  /audit-fiware-platforms/count : count all the auditFiwarePlatforms.
    *
    * @param criteria the criterias which the requested entities should match
    * @return the ResponseEntity with status 200 (OK) and the count in body
    */
    @GetMapping("/audit-fiware-platforms/count")
    public ResponseEntity<Long> countAuditFiwarePlatforms(AuditFiwarePlatformCriteria criteria) {
        log.debug("REST request to count AuditFiwarePlatforms by criteria: {}", criteria);
        return ResponseEntity.ok().body(auditFiwarePlatformQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /audit-fiware-platforms/:id : get the "id" auditFiwarePlatform.
     *
     * @param id the id of the auditFiwarePlatformDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the auditFiwarePlatformDTO, or with status 404 (Not Found)
     */
    @GetMapping("/audit-fiware-platforms/{id}")
    public ResponseEntity<AuditFiwarePlatformDTO> getAuditFiwarePlatform(@PathVariable Long id) {
        log.debug("REST request to get AuditFiwarePlatform : {}", id);
        Optional<AuditFiwarePlatformDTO> auditFiwarePlatformDTO = auditFiwarePlatformService.findOne(id);
        return ResponseUtil.wrapOrNotFound(auditFiwarePlatformDTO);
    }

    /**
     * DELETE  /audit-fiware-platforms/:id : delete the "id" auditFiwarePlatform.
     *
     * @param id the id of the auditFiwarePlatformDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/audit-fiware-platforms/{id}")
    public ResponseEntity<Void> deleteAuditFiwarePlatform(@PathVariable Long id) {
        log.debug("REST request to delete AuditFiwarePlatform : {}", id);
        auditFiwarePlatformService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

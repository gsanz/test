package com.ute.smartcity.service.exception.platform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PlatformException extends Exception {
    private final Logger log = (Logger) LoggerFactory.getLogger(PlatformException.class);
    private int statusCode;
    private String message;
    public PlatformException(Exception ex) {
        log.error("Failed to process the request to platform: " + ex.getMessage());
    }

    public PlatformException(int statusCode,String message) {
        this.statusCode = statusCode;
        this.message = message;
        log.error("Failed to process the request to platform: " + message);
    }
}

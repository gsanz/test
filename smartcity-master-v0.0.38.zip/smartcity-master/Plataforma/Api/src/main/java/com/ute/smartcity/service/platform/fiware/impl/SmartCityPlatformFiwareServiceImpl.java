package com.ute.smartcity.service.platform.fiware.impl;

import com.google.gson.JsonObject;
import com.ute.smartcity.service.platform.fiware.FiwareOrionService;
import com.ute.smartcity.service.exception.fiware.HttpIOTAgentConnectionException;
import com.ute.smartcity.service.exception.fiware.HttpOrionConnectionException;
import com.ute.smartcity.service.exception.fiware.OrionException;
import com.ute.smartcity.service.platform.fiware.FiwareSubscriptionService;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.service.dto.*;
import com.ute.smartcity.service.exception.fiware.IOTAgentException;
import com.ute.smartcity.service.exception.NullDevicePropertyException;
import com.ute.smartcity.service.exception.platform.PlatformException;
import com.ute.smartcity.service.mapper.EntityFiwareAdapter;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SmartCityPlatformFiwareServiceImpl implements SmartCityPlatformService {

    private final Logger log = LoggerFactory.getLogger(SmartCityPlatformFiwareServiceImpl.class);

    private static final String ENTITY_NAME = "SmartCityPlatformFiwareServiceImpl";

    private final EntityFiwareAdapter entityFiwareAdapter;

    private final FiwareOrionService fiwareOrionService;

    private final FiwareSubscriptionService fiwareSubscriptionService;

    public SmartCityPlatformFiwareServiceImpl(EntityFiwareAdapter entityFiwareAdapter,
                                              FiwareOrionService fiwareOrionConnector,
                                              FiwareSubscriptionService fiwareSubscriptionService) {
        this.entityFiwareAdapter = entityFiwareAdapter;
        this.fiwareOrionService = fiwareOrionConnector;
        this.fiwareSubscriptionService = fiwareSubscriptionService;
    }

    @Override
    public void addDevice(DeviceDTO deviceDTO) throws PlatformException {


        String json = entityFiwareAdapter.DeviceToEntity(deviceDTO); // Transforma los datos a JSON (string)
        String servicepath = deviceDTO.getDeviceTypeReference();
        fiwareOrionService.addEntity(json, servicepath); //Llamada a ORION

        boolean isIotDevice = deviceDTO.getProtocolId() != null;
        if (isIotDevice) {
            addIoTDevice(deviceDTO);
        }

    }

    public String getAllDevices() throws HttpOrionConnectionException, OrionException {
        String allEntitiesJson = fiwareOrionService.getAllEntities();

        return allEntitiesJson;
    }

    @Override
    public void addSubscription(SubscriptionsDTO subscriptionsDTO) {
        //TODO Implementar
        FiwareSubscriptionDTO fiwareSubscriptionDTO = entityFiwareAdapter.subscriptionsDTOToFiwareSubscriptionDTO(subscriptionsDTO);

        // FiwareSubscriptionDTO fiwareSubscriptionDTOWithID = fiwareSubscriptionService.addSubscription(fiwareSubscriptionDTO);

    }

    @Override
    public List<SubscriptionsDTO> addSubscriptions(List<SubscriptionsDTO> subscriptionsDTOList) throws PlatformException {
        List<FiwareSubscriptionDTO> fiwareSubscriptionDTOList =
            entityFiwareAdapter.subscriptionsDTOListtoFiwareSubscriptionsDTOList(subscriptionsDTOList);

        List<FiwareSubscriptionDTO> fiwareSubscriptionDTOListWithID = fiwareSubscriptionService.addSubscriptions(fiwareSubscriptionDTOList);

        for (SubscriptionsDTO subsDTO : subscriptionsDTOList) {
            for (FiwareSubscriptionDTO fiwareSubscriptionDTOWithID : fiwareSubscriptionDTOListWithID) {
                if (fiwareSubscriptionDTOWithID.getUrl().equals(subsDTO.getEndpoint())){
                    subsDTO.setPlatformId(fiwareSubscriptionDTOWithID.getIdPattern());
                }
            }
        }
        return subscriptionsDTOList;
    }

    @Override
    public void deleteSubscription(SubscriptionsDTO subscriptionsDTO) throws PlatformException {
               fiwareSubscriptionService.deleteSubscription(subscriptionsDTO);

    }

    public void addIoTDevice(DeviceDTO deviceDTO) throws  PlatformException{


        if(deviceDTO.getDeviceTypeId() != null) {
            if(deviceDTO.getProtocolId() != null) {
                if(deviceDTO.getFields().size() > 0) {
                    JsonObject fiwareDevice = null;
                    try {
                        Set<FieldsDTO> fieldsWithAbbreviation = new HashSet<>();
                        for (FieldsDTO field : deviceDTO.getFields()) {
                            if(field.getAbbreviation() != null) {
                                fieldsWithAbbreviation.add(field);
                            }
                        }
                        deviceDTO.setFields(fieldsWithAbbreviation);

                        fiwareDevice = entityFiwareAdapter.dispositivoToFiwareDevice(deviceDTO);
                    } catch (NullDevicePropertyException e) {
                        log.error("Error al añadir iotAgent  "+e.getMessage());
                        throw new PlatformException(500,"Error al adaptar el dispositivo a IOT");
                    }

                    if(deviceDTO.getDeviceTypeReference()!=null) {
                        fiwareOrionService.addDeviceIOT(fiwareDevice, deviceDTO.getDeviceTypeReference());
                    } else {
                        log.debug("fallo actualizando entidad porque deviceType es nulo");
                        throw new BadRequestAlertException("This device doesn't have deviceType.", ENTITY_NAME, "nullField");
                    }
                } else {
                    log.debug("addIoTDevice method failed because the device doesn't have any field assigned. {}", deviceDTO);
                    throw new BadRequestAlertException("This device doesn't have any field assigned.", ENTITY_NAME, "nullFields");
                }
            } else {
                log.debug("addIoTDevice method failed because the device doesn't have any protocol assigned.", deviceDTO);
                throw new BadRequestAlertException("This device doesn't have any protocol assigned.", ENTITY_NAME, "nullProtocol");
            }
        } else {
            log.debug("addIoTDevice method failed because the device doesn't have any type assigned.", deviceDTO);
            throw new BadRequestAlertException("This device doesn't have any type assigned.", ENTITY_NAME, "nullType");
        }
    }

    @Override
    public void updateDevice(DeviceDTO deviceDTO) throws PlatformException{

        String entity = entityFiwareAdapter.DeviceToEntity(deviceDTO);
        String servicepath = deviceDTO.getDeviceTypeReference();
        String reference = deviceDTO.getReference();
        fiwareOrionService.removeEntity(reference,servicepath);
        fiwareOrionService.addEntity(entity, servicepath );
        boolean isIotDevice = deviceDTO.getProtocolId() != null;
        if (isIotDevice) {
            removeIoTDevice(deviceDTO);
            addIoTDevice(deviceDTO);
        }
    }

    @Override
    public void updateIoTDevice(DeviceDTO deviceDTO) throws IOTAgentException, HttpIOTAgentConnectionException, NullDevicePropertyException,PlatformException {

        if(deviceDTO.getDeviceTypeId() != null) {
            if(deviceDTO.getProtocolId() != null) {
                if(deviceDTO.getFields() != null) {
                    if(deviceDTO.getDeviceTypeReference()!=null) {
                        JsonObject fiwareDevice = entityFiwareAdapter.dispositivoToFiwareDevice(deviceDTO);
                        fiwareOrionService.putDeviceIOT(fiwareDevice, deviceDTO.getDeviceTypeReference(), deviceDTO.getReference());
                        String entity = entityFiwareAdapter.DeviceToEntity(deviceDTO);
                        String fiwareServicePath = deviceDTO.getDeviceTypeReference();
                        String deviceName = deviceDTO.getReference();
                        fiwareOrionService.removeEntity(deviceName,fiwareServicePath);
                        fiwareOrionService.addEntity(entity, fiwareServicePath );
                    }
                } else {
                    log.debug("addIoTDevice method failed because the device doesn't have any field assigned.", deviceDTO);
                    throw new BadRequestAlertException("This device doesn't have any field assigned.", ENTITY_NAME, "nullFields");
                }
            } else {
                log.debug("addIoTDevice method failed because the device doesn't have any protocol assigned.", deviceDTO);
                throw new BadRequestAlertException("This device doesn't have any protocol assigned.", ENTITY_NAME, "nullProtocol");
            }
        } else {
            log.debug("addIoTDevice method failed because the device doesn't have any type assigned.", deviceDTO);
            throw new BadRequestAlertException("This device doesn't have any type assigned.", ENTITY_NAME, "nullType");
        }
    }




    @Override
    public void removeIoTDevice(DeviceDTO deviceDTO) throws PlatformException{

        String deviceId = deviceDTO.getReference();
        String fiwareServicePath = deviceDTO.getDeviceTypeReference();
        fiwareOrionService.removeIotDevice( deviceId,   fiwareServicePath);
    }
    @Override
    public void updateDeviceData(String json, String reference, String servicePathRef) throws HttpOrionConnectionException, OrionException {
        fiwareOrionService.patchEntity(json, reference, servicePathRef);
    }

    public void removeDevice(String reference, String servicepath) throws PlatformException {
        fiwareOrionService.removeEntity(reference, servicepath); //L
    }
}

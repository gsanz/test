package com.ute.smartcity.service;

import com.ute.smartcity.domain.SubscriptionTemplate;
import com.ute.smartcity.service.dto.SubscriptionTemplateDTO;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing SubscriptionTemplate.
 */
public interface SubscriptionTemplateService {

    /**
     * Save a subscriptionTemplate.
     *
     * @param subscriptionTemplateDTO the entity to save
     * @return the persisted entity
     */
    SubscriptionTemplateDTO save(SubscriptionTemplateDTO subscriptionTemplateDTO);

    /**
     * Get all the subscriptionTemplates.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<SubscriptionTemplateDTO> findAll(Pageable pageable);


    /**
     * Get the "id" subscriptionTemplate.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<SubscriptionTemplateDTO> findOne(Long id);

    /**
     * Delete the "id" subscriptionTemplate.
     *
     * @param id the id of the entity
     */
    void delete(Long id);

}

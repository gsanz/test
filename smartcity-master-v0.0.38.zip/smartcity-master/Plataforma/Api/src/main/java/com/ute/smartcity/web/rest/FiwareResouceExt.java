package com.ute.smartcity.web.rest;


import com.ute.smartcity.service.dto.FiwareSubscriptionDTO;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformSubscriptionService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * REST controller for managing Fiware entities.
 */
@RestController
@RequestMapping("/api")
public class FiwareResouceExt {

    private final Logger log = LoggerFactory.getLogger(FiwareResouceExt.class);

    private static final String ENTITY_NAME = "fiware";

    private final SmartCityPlatformSubscriptionService subscriptionService;


    public FiwareResouceExt(SmartCityPlatformSubscriptionService subscriptionService)  {

        this.subscriptionService = subscriptionService;

    }

    /**
     * POST  /rules : Create a new rule.
     *
     * @param subscriptionDTO the subscriptionDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new ruleDTO, or with status 400 (Bad Request) if the rule has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/subscription")
    public ResponseEntity<String> createSubscription(@Valid @RequestBody FiwareSubscriptionDTO subscriptionDTO) throws URISyntaxException {
        log.debug("REST request to save Subscription : {}", subscriptionDTO);

        ResponseEntity<String> result = null;
        try {
            result = subscriptionService.addSubscription(subscriptionDTO);
        } catch (Exception e) {
            throw new BadRequestAlertException("Subscription not created", ENTITY_NAME, "subscriptionNotCreated");
        }


        return ResponseEntity.created(new URI("/v2/subscriptions"))
            .headers(HeaderUtil.createAlert(ENTITY_NAME, "Suscripción creada"))
            .body(result.getBody());
    }




}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.domain.RuleCompareFields;
import com.ute.smartcity.repository.RuleCompareFieldsRepository;
import com.ute.smartcity.service.RuleCompareFieldsService;
import com.ute.smartcity.service.dto.RuleCompareFieldsDTO;
import com.ute.smartcity.service.mapper.RuleCompareFieldsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing RuleCompareFields.
 */
@Service
@Transactional
public class RuleCompareFieldsServiceImpl implements RuleCompareFieldsService {

    private final Logger log = LoggerFactory.getLogger(RuleCompareFieldsServiceImpl.class);

    private final RuleCompareFieldsRepository ruleCompareFieldsRepository;

    private final RuleCompareFieldsMapper ruleCompareFieldsMapper;

    public RuleCompareFieldsServiceImpl(RuleCompareFieldsRepository ruleCompareFieldsRepository, RuleCompareFieldsMapper ruleCompareFieldsMapper) {
        this.ruleCompareFieldsRepository = ruleCompareFieldsRepository;
        this.ruleCompareFieldsMapper = ruleCompareFieldsMapper;
    }

    /**
     * Save a ruleCompareFields.
     *
     * @param ruleCompareFieldsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public RuleCompareFieldsDTO save(RuleCompareFieldsDTO ruleCompareFieldsDTO) {
        log.debug("Request to save RuleCompareFields : {}", ruleCompareFieldsDTO);
        RuleCompareFields ruleCompareFields = ruleCompareFieldsMapper.toEntity(ruleCompareFieldsDTO);
        ruleCompareFields = ruleCompareFieldsRepository.save(ruleCompareFields);
        return ruleCompareFieldsMapper.toDto(ruleCompareFields);
    }

    /**
     * Get all the ruleCompareFields.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<RuleCompareFieldsDTO> findAll(Pageable pageable) {
        log.debug("Request to get all RuleCompareFields");
        return ruleCompareFieldsRepository.findAll(pageable)
            .map(ruleCompareFieldsMapper::toDto);
    }

    /**
     * Get all the ruleCompareFields.
     *
     * @param id RuleId
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public List<RuleCompareFields> findByRuleId(Long id) {
        log.debug("Request to get all RuleCompareFields");
        return ruleCompareFieldsRepository.findByRuleId(id);
    }

    /**
     * Get one ruleCompareFields by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<RuleCompareFieldsDTO> findOne(Long id) {
        log.debug("Request to get RuleCompareFields : {}", id);
        return ruleCompareFieldsRepository.findById(id)
            .map(ruleCompareFieldsMapper::toDto);
    }

    /**
     * Delete the ruleCompareFields by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete RuleCompareFields : {}", id);
        ruleCompareFieldsRepository.deleteById(id);
    }

    /**
     * Delete the ruleCompareFields by ZoneId.
     *
     * @param id the id of the entity
     */
    @Override
    public void deleteByRuleId(Long id) {
        log.debug("Request to delete RuleCompareFields : {}", id);
        ruleCompareFieldsRepository.deleteByRuleId(id);
    }
}

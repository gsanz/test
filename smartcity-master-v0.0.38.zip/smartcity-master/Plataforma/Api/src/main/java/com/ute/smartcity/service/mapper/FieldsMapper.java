package com.ute.smartcity.service.mapper;

import com.ute.smartcity.domain.*;
import com.ute.smartcity.service.dto.FieldsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Fields and its DTO FieldsDTO.
 */
@Mapper(componentModel = "spring", uses = {DeviceMapper.class, DeviceTypeMapper.class})
public interface FieldsMapper extends EntityMapper<FieldsDTO, Fields> {

    @Mapping(source = "device.id", target = "deviceId")
    @Mapping(source = "device.reference", target = "deviceReference")
    @Mapping(source = "device.name", target = "deviceName")
    @Mapping(source = "deviceType.id", target = "deviceTypeId")
    FieldsDTO toDto(Fields fields);

    @Mapping(source = "deviceId", target = "device")
    @Mapping(source = "deviceTypeId", target = "deviceType")
    Fields toEntity(FieldsDTO fieldsDTO);

    default Fields fromId(Long id) {
        if (id == null) {
            return null;
        }
        Fields fields = new Fields();
        fields.setId(id);
        return fields;
    }
}

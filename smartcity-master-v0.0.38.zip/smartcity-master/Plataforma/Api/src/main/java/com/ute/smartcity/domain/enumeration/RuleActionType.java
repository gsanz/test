package com.ute.smartcity.domain.enumeration;

/**
 * The RuleActionType enumeration.
 */
public enum RuleActionType {
    UPDATE, EMAIL, POST
}

package com.ute.smartcity.service.impl;

import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.*;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class HistoricalDeviceDataImpl implements HistoricalDeviceDataService {

    private final Logger log = LoggerFactory.getLogger(DeviceServiceImpl.class);

    private final DeviceService deviceService;
    private final DeviceTypeService deviceTypeService;
    private final FieldsService fieldsService;
    private final DeviceObservationsService deviceObservationsService;

    public HistoricalDeviceDataImpl(DeviceService deviceService, DeviceTypeService deviceTypeService, FieldsService fieldsService, DeviceObservationsService deviceObservationsService) {
        this.deviceService = deviceService;
        this.deviceTypeService = deviceTypeService;
        this.fieldsService = fieldsService;
        this.deviceObservationsService = deviceObservationsService;
    }

    @Override
    public Optional<HistoricalDeviceDataDTO> getHistoricalDataDevice(Long id, DeviceObservationCriteria criteria, Pageable page, String dateFieldToFilter) {
        log.debug("HistoricalDeviceDataImpl getHistoricalDataDevice deviceId:{} criteria:{}",id,criteria);
        HistoricalDeviceDataDTO historicalDeviceDataDTO = new HistoricalDeviceDataDTO();
        Optional<DeviceDTO> deviceOptional = deviceService.findOne(id);
        boolean existsDevice = deviceOptional.isPresent();
        if (existsDevice) {

            DeviceDTO device = deviceOptional.get();
            Optional<DeviceTypeDTO> deviceTypeDTOOptional = deviceTypeService.findOne(device.getDeviceTypeId());
            historicalDeviceDataDTO.setDeviceDTO(device);
            boolean existsDeviceType = deviceTypeDTOOptional.isPresent();
            if (existsDeviceType) {
                log.debug("HistoricalDeviceDataImpl getHistoricalDataDevice deviceId exists");

                DeviceTypeDTO deviceTypeDTO = deviceTypeDTOOptional.get();
                historicalDeviceDataDTO.setDeviceTypeDTO(deviceTypeDTO);
                Optional<List<FieldsDTO>> fieldsDTOOptional = fieldsService.findByDeviceId(id);
                if (fieldsDTOOptional.isPresent()) {
                    log.debug("HistoricalDeviceDataImpl getHistoricalDataDevice deviceId has fields {0}",fieldsDTOOptional.get().toString());
                    Page<JSONObject> observations = deviceObservationsService.findAll(device, criteria, page, dateFieldToFilter);
                    for (FieldsDTO fieldsDTO : fieldsDTOOptional.get()) {
                        List<String> data = new ArrayList<String>();
                        List<String> labels = new ArrayList<String>();
                        for (JSONObject observationItem: observations){
                            log.debug("HistoricalDeviceDataImpl getHistoricalDataDevice deviceId has observations");
                            if (observationItem.containsKey(fieldsDTO.getName()) && observationItem.containsKey(dateFieldToFilter)) {
                                String value = observationItem.get(fieldsDTO.getName()).toString();
                                data.add(value);
                                labels.add(observationItem.get(dateFieldToFilter).toString());
                                fieldsDTO.setValue(observationItem.get(fieldsDTO.getName()).toString());
                            }
                        }

                        fieldsDTO.setData(data);
                        fieldsDTO.setLabels(labels);


                    }
                    historicalDeviceDataDTO.setFields(fieldsDTOOptional.get());
                }else {
                    log.debug("HistoricalDeviceDataImpl getHistoricalDataDevice deviceId has not any fields");
                }
            }
        } else {
            return Optional.empty();
        }

        return Optional.of(historicalDeviceDataDTO);
    }
}

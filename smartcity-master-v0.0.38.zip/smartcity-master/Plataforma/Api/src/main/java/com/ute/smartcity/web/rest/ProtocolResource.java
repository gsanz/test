package com.ute.smartcity.web.rest;
import com.ute.smartcity.service.ProtocolService;
import com.ute.smartcity.web.rest.errors.BadRequestAlertException;
import com.ute.smartcity.web.rest.util.HeaderUtil;
import com.ute.smartcity.web.rest.util.PaginationUtil;
import com.ute.smartcity.service.dto.ProtocolDTO;
import com.ute.smartcity.service.dto.ProtocolCriteria;
import com.ute.smartcity.service.ProtocolQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Protocol.
 */
@RestController
@RequestMapping("/api")
public class ProtocolResource {

    private final Logger log = LoggerFactory.getLogger(ProtocolResource.class);

    private static final String ENTITY_NAME = "protocol";

    private final ProtocolService protocolService;

    private final ProtocolQueryService protocolQueryService;

    public ProtocolResource(ProtocolService protocolService, ProtocolQueryService protocolQueryService) {
        this.protocolService = protocolService;
        this.protocolQueryService = protocolQueryService;
    }

    /**
     * POST  /protocols : Create a new protocol.
     *
     * @param protocolDTO the protocolDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new protocolDTO, or with status 400 (Bad Request) if the protocol has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/protocols")
    public ResponseEntity<ProtocolDTO> createProtocol(@Valid @RequestBody ProtocolDTO protocolDTO) throws URISyntaxException {
        log.debug("REST request to save Protocol : {}", protocolDTO);
        if (protocolDTO.getId() != null) {
            throw new BadRequestAlertException("A new protocol cannot already have an ID", ENTITY_NAME, "idexists");
        }
        String name = protocolDTO.getName().trim();
        if (protocolDTO.getName() == null || protocolDTO.getName().isEmpty() || name.length() <= 0) {
            throw new BadRequestAlertException("The protocol name cant be null", ENTITY_NAME, "noname");
        }
        ProtocolDTO result = protocolService.save(protocolDTO);
        return ResponseEntity.created(new URI("/api/protocols/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /protocols : Updates an existing protocol.
     *
     * @param protocolDTO the protocolDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated protocolDTO,
     * or with status 400 (Bad Request) if the protocolDTO is not valid,
     * or with status 500 (Internal Server Error) if the protocolDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/protocols")
    public ResponseEntity<ProtocolDTO> updateProtocol(@Valid @RequestBody ProtocolDTO protocolDTO) throws URISyntaxException {
        log.debug("REST request to update Protocol : {}", protocolDTO);
        if (protocolDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        String name = protocolDTO.getName().trim();
        if (protocolDTO.getName() == null || protocolDTO.getName().isEmpty() || name.length() <= 0) {
            throw new BadRequestAlertException("The protocol name cant be null", ENTITY_NAME, "noname");
        }
        ProtocolDTO result = protocolService.save(protocolDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, protocolDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /protocols : get all the protocols.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of protocols in body
     */
    @GetMapping("/protocols")
    public ResponseEntity<List<ProtocolDTO>> getAllProtocols(ProtocolCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Protocols by criteria: {}", criteria);
        Page<ProtocolDTO> page = protocolQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/protocols");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /protocols/count : count all the protocols.
     *
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the count in body
     */
    @GetMapping("/protocols/count")
    public ResponseEntity<Long> countProtocols(ProtocolCriteria criteria) {
        log.debug("REST request to count Protocols by criteria: {}", criteria);
        return ResponseEntity.ok().body(protocolQueryService.countByCriteria(criteria));
    }

    /**
     * GET  /protocols/:id : get the "id" protocol.
     *
     * @param id the id of the protocolDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the protocolDTO, or with status 404 (Not Found)
     */
    @GetMapping("/protocols/{id}")
    public ResponseEntity<ProtocolDTO> getProtocol(@PathVariable Long id) {
        log.debug("REST request to get Protocol : {}", id);
        Optional<ProtocolDTO> protocolDTO = protocolService.findOne(id);
        return ResponseUtil.wrapOrNotFound(protocolDTO);
    }

    /**
     * DELETE  /protocols/:id : delete the "id" protocol.
     *
     * @param id the id of the protocolDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/protocols/{id}")
    public ResponseEntity<Void> deleteProtocol(@PathVariable Long id) {
        log.debug("REST request to delete Protocol : {}", id);
        protocolService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}

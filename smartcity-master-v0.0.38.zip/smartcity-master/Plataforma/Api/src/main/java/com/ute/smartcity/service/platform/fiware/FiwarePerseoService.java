package com.ute.smartcity.service.platform.fiware;

import com.ute.smartcity.service.AuditFiwarePlatformService;
import com.ute.smartcity.service.exception.platform.PlatformException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Component
public class FiwarePerseoService {
    private static final String ENTITY_NAME = "FiwarePerseoService";

    private final Logger log = LoggerFactory.getLogger(FiwarePerseoService.class);

    @Value("${application.fiware.perseo}")
    public String perseoURL;

    @Value("${application.fiware.service-path}")
    public String fiware_service;

    private final AuditFiwarePlatformService auditFiwarePlatformService;

    public FiwarePerseoService(AuditFiwarePlatformService auditFiwarePlatformService) {
        this.auditFiwarePlatformService = auditFiwarePlatformService;
    }

    private int statusCode = 0;
    private String responseContent = "";

    public void addRule(String entity, String servicepath) throws PlatformException {
        log.debug("addRule to fiware ",entity);
        String url = perseoURL + "rules";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        HttpEntity<Object> request = new HttpEntity<>(entity, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;

        try{
            response = restTemplate.postForEntity( url, request , String.class );

        }catch (HttpClientErrorException e){
            log.error("No se ha podido crear la regla en Fiware: "+e.getMessage());
            statusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
            throw new PlatformException(e);
        }catch (Exception e){
            log.error("No se ha podido crear la regla en Fiware: "+e.getMessage());
            throw new PlatformException(e);
        } finally {
            if (response != null){
                statusCode = response.getStatusCodeValue();
                responseContent = response.getBody();
            }
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url,statusCode,responseContent,"Add rule");
        }

    }

    public void deleteRule(String ruleName, String servicepath) throws PlatformException {
        log.debug("delete rule in fiware ",ruleName);
        String url = perseoURL + "rules/" + ruleName;

        HttpHeaders headers = new HttpHeaders();
        headers.set("fiware-service", fiware_service);
        headers.set("fiware-servicepath", "/"+servicepath);

        HttpEntity<Object> request = new HttpEntity<>(headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;

        try{
            response =  restTemplate.exchange(url, HttpMethod.DELETE, request, String.class);

        }catch (HttpClientErrorException e){
            log.error("No se ha podido crear la regla en Fiware: "+e.getMessage());
            statusCode = e.getStatusCode().value();
            responseContent = e.getResponseBodyAsString();
        }catch (Exception e){
            log.error("No se ha podido crear la regla en Fiware: "+e.getMessage());
            throw new PlatformException(e);
        } finally {
            if (response != null){
                statusCode = response.getStatusCodeValue();
                responseContent = response.getBody();
            }
            auditFiwarePlatformService.createFiwareAudit(request.toString(),url,statusCode,responseContent,"Delete rule");
        }
    }
}

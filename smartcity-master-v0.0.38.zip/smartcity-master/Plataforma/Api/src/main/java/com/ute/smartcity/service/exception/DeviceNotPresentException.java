package com.ute.smartcity.service.exception;

import com.ute.smartcity.domain.Device;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

public class DeviceNotPresentException extends Exception {
    private final Logger log = LoggerFactory.getLogger(DeviceNotPresentException.class);

    private String message;
    public DeviceNotPresentException(String message, Optional<Device> device) {
        this.message = message;
        log.error(message + " - " + device);
    }

    @Override
    public String getMessage() {
        return message;
    }
}

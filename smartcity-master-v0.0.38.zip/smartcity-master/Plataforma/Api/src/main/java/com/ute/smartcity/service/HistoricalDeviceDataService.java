package com.ute.smartcity.service;

import com.ute.smartcity.service.dto.DeviceObservationCriteria;
import com.ute.smartcity.service.dto.HistoricalDeviceDataDTO;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface HistoricalDeviceDataService {
    Optional<HistoricalDeviceDataDTO> getHistoricalDataDevice(Long id, DeviceObservationCriteria criteria, Pageable page, String dateFieldToFilter) throws DataAccessResourceFailureException;
}

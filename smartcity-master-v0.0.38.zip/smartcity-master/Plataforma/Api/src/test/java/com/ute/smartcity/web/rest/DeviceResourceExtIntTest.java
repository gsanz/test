package com.ute.smartcity.web.rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ute.smartcity.SmartcityApp;
import com.ute.smartcity.domain.*;
import com.ute.smartcity.repository.*;
import com.ute.smartcity.security.AuthoritiesConstants;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.platform.fiware.FiwareOrionService;
import com.ute.smartcity.service.mapper.DeviceMapper;
import com.ute.smartcity.service.mapper.DeviceTypeMapper;
import com.ute.smartcity.service.mapper.EntityFiwareAdapter;
import com.ute.smartcity.service.platform.generic.SmartCityPlatformService;
import com.ute.smartcity.web.rest.errors.ExceptionTranslator;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import javax.validation.constraints.AssertTrue;

import java.lang.reflect.Type;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.*;

import static com.ute.smartcity.web.rest.TestUtil.createFormattingConversionService;
import static com.ute.smartcity.web.rest.TestUtil.sameInstant;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

/**
 * Test class for the DeviceResource REST controller.
 *
 * @see DeviceResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmartcityApp.class)
public class DeviceResourceExtIntTest {

    private static final String DEFAULT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_ADDRESS = "AAAAAAAAAA";
    private static final String UPDATED_ADDRESS = "BBBBBBBBBB";

    private static final String DEFAULT_MOBILE = "647509377";
    private static final String UPDATED_MOBILE = "263485966";

    private static final String DEFAULT_EMAIL = "admin@test.com";
    private static final String UPDATED_EMAIL = "user@test.com";

    private static final byte[] DEFAULT_IMAGE = TestUtil.createByteArray(1, "0");
    private static final byte[] UPDATED_IMAGE = TestUtil.createByteArray(1, "1");
    private static final String DEFAULT_IMAGE_CONTENT_TYPE = "image/jpg";
    private static final String UPDATED_IMAGE_CONTENT_TYPE = "image/png";

    private static final ZonedDateTime DEFAULT_CREATE_AT = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_CREATE_AT = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_DELETE_AT = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_DELETE_AT = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_UPDATE_AT = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_UPDATE_AT = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private DeviceObservationsService deviceObservationsService;

    @Autowired
    private FieldsService fieldsService;

    @Autowired
    private DeviceRepository deviceRepository;

    @Autowired
    private DeviceTypeRepository deviceTypeRepository;

    @Autowired
    private FieldsRepository fieldsRepository;

    @Autowired
    private DeviceQueryService deviceQueryService;

    @Autowired
    private UpdateDeviceDataService updateDeviceDataService;

    @Autowired
    private UserService userService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private HistoricalDeviceDataService historicalDeviceDataService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restDeviceMockMvc;

    private Device device;

    private DeviceType deviceType;

    @Autowired
    private SmartCityPlatformService smartCityPlatformService;

    @Autowired
    private DeviceMapper deviceMapper;

    @Autowired
    private DeviceTypeService deviceTypeService;

    @Autowired
    private DeviceTypeMapper deviceTypeMapper;

    @Autowired
    private ProviderService providerService;

    @Autowired
    private EntityFiwareAdapter entityFiwareAdapter;

    @Autowired
    private FiwareOrionService fiwareOrionConnector;

    @Autowired
    private ProviderRepository providerRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;


    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final DeviceResourceExt deviceResource = new DeviceResourceExt(deviceService, deviceQueryService, deviceObservationsService, fieldsService, historicalDeviceDataService, userService, usuarioService, updateDeviceDataService, smartCityPlatformService, deviceMapper, deviceTypeService, providerService);
        this.restDeviceMockMvc = MockMvcBuilders.standaloneSetup(deviceResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public  Device createEntity(EntityManager em) {

       Device device = new Device()
            .reference("Prueba")
            .name("Prueba")
            .longitude("2")
            .latitude("1");



        return device;
    }

    @Before
    public void initTest() {
        device = createEntity(em);
        deviceType = createDeviceTypeEntity(em);
        fieldsRepository.deleteAll();
        deviceRepository.deleteAll();
    }

    private DeviceType createDeviceTypeEntity(EntityManager em) {
        //Optional<DeviceType> deviceType = deviceTypeRepository.findById((long) IdParking);
        DeviceType type = new DeviceType();
        type.setReference("parking");
        type.setName("parking");
        type.setType("parking");

        return type;
    }


    @Test
    @Transactional
    public void getParkingDeviceData() throws Exception {
        // Initialize the database
        deviceTypeRepository.saveAndFlush(deviceType);
        device.setDeviceType(deviceType);
        deviceRepository.saveAndFlush(device);

        // Get the device
        restDeviceMockMvc.perform(get("/api/devices/{id}/historical-data?dateFieldToFilter=recvTime", device.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
//            .andExpect(jsonPath("$.[*].name").isNotEmpty());

    }

    @Test
    @Transactional
    public void getQualityDeviceData() throws Exception {
        // Initialize the database
        deviceTypeRepository.saveAndFlush(deviceType);
        device.setDeviceType(deviceType);
        deviceRepository.saveAndFlush(device);

        // Get the device
        restDeviceMockMvc.perform(get("/api/devices/{id}/historical-data?dateFieldToFilter=recvTime", device.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
//            .andExpect(jsonPath("$.[*].name").isNotEmpty());

    }

    @Test
    @Transactional
    public void shouldGetAllDevicesAsAdmin() throws Exception {

        Provider provider = createProviderOne();

        Provider provider2 = createProviderTwo();

        // Initialize the database
        providerRepository.saveAndFlush(provider);
        providerRepository.saveAndFlush(provider2);

        // Initialize devices
        DeviceType type = createDeviceType();
        createDeviceOne(provider, type);
        createDevice2(provider2, type);

        //User
        User user = createUser();

        //Usuario
        createUsuario(provider, user);


        //Initialize Provider auth
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities2 = new ArrayList<>();
        authorities2.add(new SimpleGrantedAuthority(AuthoritiesConstants.ADMIN));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin",authorities2));
        SecurityContextHolder.setContext(securityContext);


        // Get the provider
        restDeviceMockMvc.perform(get("/api/devices?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.*",hasSize(2)));
    }

    private DeviceType createDeviceType() {
        DeviceType type = new DeviceType();
        type.setName("default");
        type.setReference("name");
        type.setType("type");
        em.flush();
        em.persist(type);
        return type;
    }


    @Test
    @Transactional
    public void shouldGetOwnDevicesAsProvider() throws Exception {

        Provider provider = createProviderOne();

        Provider provider2 = createProviderTwo();

        // Initialize the database
        providerRepository.saveAndFlush(provider);
        providerRepository.saveAndFlush(provider2);

        // Initialize devices
        DeviceType type = createDeviceType();
        createDeviceOne(provider, type);
        createDevice2(provider2, type);

        //User
        User user = createUser();

        //Usuario
        createUsuario(provider, user);


        //Initialize Provider auth
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        Collection<GrantedAuthority> authorities2 = new ArrayList<>();
        authorities2.add(new SimpleGrantedAuthority(AuthoritiesConstants.PROVIDER));
        securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("provider", "token",authorities2));
        SecurityContextHolder.setContext(securityContext);


        // Get the provider
        restDeviceMockMvc.perform(get("/api/devices?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.*",hasSize(1)));
    }

    private void createDevice2(Provider provider2, DeviceType type) {
        Device device2 = new Device()
            .reference("AAAAAAAA")
            .state("AAAAAAAAAA")
            .name(DEFAULT_NAME)
            .location("AAAAAAAAAAA")
            .longitude("-0.261155")
            .latitude("-1.257179")
            .observaciones("AAAAAAAAAAAAA")
            .createAt(DEFAULT_CREATE_AT)
            .deleteAt(DEFAULT_DELETE_AT)
            .updateAt(DEFAULT_UPDATE_AT)
            .deviceType(type)
            .provider(provider2);


        deviceRepository.saveAndFlush(device2);
    }

    private void createDeviceOne(Provider provider, DeviceType type) {
        Device device = new Device()
            .reference("AAAAAAAA")
            .state("AAAAAAAAAA")
            .name(DEFAULT_NAME)
            .location("AAAAAAAAAAA")
            .longitude("-0.261155")
            .latitude("-1.257179")
            .observaciones("AAAAAAAAAAAAA")
            .createAt(DEFAULT_CREATE_AT)
            .deleteAt(DEFAULT_DELETE_AT)
            .updateAt(DEFAULT_UPDATE_AT)
            .deviceType(type)
            .provider(provider);
        
        deviceRepository.saveAndFlush(device);
    }

    private void createUsuario(Provider provider, User user) {
        Usuario usuario = new Usuario();
        usuario.setUser(user);
        usuario.setPhone("675867654");
        usuario.setDoubleFactorAuthentication(false);
        usuario.setProvider(provider);
        usuario.setImage(DEFAULT_IMAGE);
        usuario.setImageContentType(DEFAULT_IMAGE_CONTENT_TYPE);
        usuario.lastPasswordDate(ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC));

        usuarioRepository.saveAndFlush(usuario);
    }

    private Provider createProviderTwo() {
        return new Provider()
            .name(DEFAULT_NAME + "2")
            .address(DEFAULT_ADDRESS + "2")
            .mobile(DEFAULT_MOBILE + "2")
            .email(DEFAULT_EMAIL + "m")
            .image(DEFAULT_IMAGE)
            .imageContentType(DEFAULT_IMAGE_CONTENT_TYPE)
            .createAt(DEFAULT_CREATE_AT)
            .deleteAt(DEFAULT_DELETE_AT)
            .updateAt(DEFAULT_UPDATE_AT);
    }

    private Provider createProviderOne() {
        return new Provider()
                .name(DEFAULT_NAME)
                .address(DEFAULT_ADDRESS)
                .mobile(DEFAULT_MOBILE)
                .email(DEFAULT_EMAIL)
                .image(DEFAULT_IMAGE)
                .imageContentType(DEFAULT_IMAGE_CONTENT_TYPE)
                .createAt(DEFAULT_CREATE_AT)
                .deleteAt(DEFAULT_DELETE_AT)
                .updateAt(DEFAULT_UPDATE_AT);
    }

    private User createUser() {
        User user = new User();
        user.setLogin("provider");
        user.setPassword(RandomStringUtils.random(60));
        user.setActivated(true);
        user.setEmail(RandomStringUtils.randomAlphabetic(5) + DEFAULT_EMAIL);
        user.setFirstName("provider");
        user.setLastName("provider");
        user.setImageUrl("http://placehold.it/50x50");
        user.setLangKey("en");
        Set<Authority> authorities = new HashSet<>();
        Authority authority = new Authority();
        authority.setName(AuthoritiesConstants.PROVIDER);
        authorities.add(authority);
        user.setAuthorities(authorities);
        return user;
    }

}

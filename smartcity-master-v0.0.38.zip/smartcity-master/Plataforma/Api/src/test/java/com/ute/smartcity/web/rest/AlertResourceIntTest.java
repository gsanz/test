package com.ute.smartcity.web.rest;

import com.ute.smartcity.SmartcityApp;
import com.ute.smartcity.domain.Alert;
import com.ute.smartcity.domain.Device;
import com.ute.smartcity.domain.Rule;
import com.ute.smartcity.domain.enumeration.AlertState;
import com.ute.smartcity.domain.enumeration.CriticalityLevel;
import com.ute.smartcity.repository.AlertRepository;
import com.ute.smartcity.repository.DeviceRepository;
import com.ute.smartcity.repository.RuleRepository;
import com.ute.smartcity.service.*;
import com.ute.smartcity.service.dto.AlertDTO;
import com.ute.smartcity.service.dto.RuleDTO;
import com.ute.smartcity.service.mapper.AlertMapper;
import com.ute.smartcity.service.mapper.RuleMapper;
import com.ute.smartcity.web.rest.errors.ExceptionTranslator;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import static com.ute.smartcity.web.rest.TestUtil.createFormattingConversionService;
import static com.ute.smartcity.web.rest.TestUtil.sameInstant;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
/**
 * Test class for the AlertResource REST controller.
 *
 * @see AlertResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmartcityApp.class)
public class AlertResourceIntTest {

    private static final String DEFAULT_REFERENCE = "AAAAAAAAAA";
    private static final String UPDATED_REFERENCE = "BBBBBBBBBB";

    private static final CriticalityLevel DEFAULT_CRITICALITY_LEVEL = CriticalityLevel.CRITICAL;
    private static final CriticalityLevel UPDATED_CRITICALITY_LEVEL = CriticalityLevel.NORMAL;

    private static final AlertState DEFAULT_STATE = AlertState.OPEN;
    private static final AlertState UPDATED_STATE = AlertState.CLOSE;

    private static final String DEFAULT_DESCRIPTION = "AAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_CREATE_AT = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_CREATE_AT = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    @Autowired
    private AlertRepository alertRepository;

    @Autowired
    private  DeviceRepository deviceRepository;

    @Autowired
    private RuleRepository ruleRepository;

    @Autowired
    private AlertMapper alertMapper;

    @Autowired
    private RuleMapper ruleMapper;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private RuleService ruleService;

    @Autowired
    private AlertService alertService;

    @Autowired
    private AlertQueryService alertQueryService;

    @Autowired
    private MailService mailService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private AlertValidator alertValidator;

    @Autowired
    private EntityManager em;

    private MockMvc restAlertMockMvc;

    private MockMvc restAlertExtMockMvc;

    private Alert alert;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final AlertResource alertResource = new AlertResource(alertService, alertQueryService);
        this.restAlertMockMvc = MockMvcBuilders.standaloneSetup(alertResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();

        final AlertResourceExt alertResourceExt = new AlertResourceExt(alertService,alertValidator, alertMapper, alertQueryService, mailService, deviceService);
        this.restAlertExtMockMvc = MockMvcBuilders.standaloneSetup(alertResourceExt)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Alert createEntity(EntityManager em) {

        Device device = DeviceResourceIntTest.createEntity(em);
        em.flush();
        em.persist(device);

        Alert alert = new Alert()
            .reference(DEFAULT_REFERENCE)
            .criticalityLevel(DEFAULT_CRITICALITY_LEVEL)
            .state(DEFAULT_STATE)
            .description(DEFAULT_DESCRIPTION)
            .device(device)
            .createAt(DEFAULT_CREATE_AT);
        return alert;
    }

    @Before
    public void initTest() {
        alert = createEntity(em);
    }

    @Test
    @Transactional
    public void createAlert() throws Exception {
        int databaseSizeBeforeCreate = alertRepository.findAll().size();
        int databaseSizeBeforeCreateRule = ruleRepository.findAll().size();

        Rule rule = RuleResourceIntTest.createEntity(em);
        em.flush();
        em.persist(rule);

        RuleDTO ruleDTO = ruleMapper.toDto(rule);

        // Create the Alert
        AlertDTO alertDTO = alertMapper.toDto(alert);

        alertDTO.setRule(ruleDTO.getReference());

        restAlertExtMockMvc.perform(post("/api/alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(alertDTO)))
            .andExpect(status().isCreated());

        // Validate the Alert in the database
        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeCreate + 1);
        Alert testAlert = alertList.get(alertList.size() - 1);
        assertThat(testAlert.getReference()).isEqualTo(DEFAULT_REFERENCE);
        assertThat(testAlert.getCriticalityLevel()).isEqualTo(DEFAULT_CRITICALITY_LEVEL);
        assertThat(testAlert.getState()).isEqualTo(DEFAULT_STATE);
        assertThat(testAlert.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);

    }

    @Test
    @Transactional
    public void createAlertWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = alertRepository.findAll().size();

        // Create the Alert with an existing ID
        alert.setId(1L);
        AlertDTO alertDTO = alertMapper.toDto(alert);

        // An entity with an existing ID cannot be created, so this API call must fail
        restAlertMockMvc.perform(post("/api/alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(alertDTO)))
            .andExpect(status().is(405));

        // Validate the Alert in the database
        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkReferenceIsRequired() throws Exception {
        int databaseSizeBeforeTest = alertRepository.findAll().size();
        // set the field null
        alert.setReference(null);

        // Create the Alert, which fails.
        AlertDTO alertDTO = alertMapper.toDto(alert);

        restAlertExtMockMvc.perform(post("/api/alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(alertDTO)))
            .andExpect(status().is(400));

        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeTest);
    }

    @Ignore
    @Test
    @Transactional
    public void checkCriticalityLevelIsRequired() throws Exception {
        int databaseSizeBeforeTest = alertRepository.findAll().size();
        // set the field null
        alert.setCriticalityLevel(null);

        // Create the Alert, which fails.
        AlertDTO alertDTO = alertMapper.toDto(alert);

        restAlertExtMockMvc.perform(post("/api/alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(alertDTO)))
            .andExpect(status().is(400));

        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeTest);
    }
    @Ignore
    @Test
    @Transactional
    public void checkStateIsRequired() throws Exception {
        int databaseSizeBeforeTest = alertRepository.findAll().size();
        // set the field null
        alert.setState(null);

        // Create the Alert, which fails.
        AlertDTO alertDTO = alertMapper.toDto(alert);

        restAlertExtMockMvc.perform(post("/api/alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(alertDTO)))
            .andExpect(status().isBadRequest());

        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeTest);
    }



    @Test
    @Transactional
    public void getAllAlerts() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList
        restAlertMockMvc.perform(get("/api/alerts?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(alert.getId().intValue())))
            .andExpect(jsonPath("$.[*].reference").value(hasItem(DEFAULT_REFERENCE.toString())))
            .andExpect(jsonPath("$.[*].criticalityLevel").value(hasItem(DEFAULT_CRITICALITY_LEVEL.toString())))
            .andExpect(jsonPath("$.[*].state").value(hasItem(DEFAULT_STATE.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].createAt").value(hasItem(sameInstant(DEFAULT_CREATE_AT))));
    }

    @Test
    @Transactional
    public void getAlert() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get the alert
        restAlertMockMvc.perform(get("/api/alerts/{id}", alert.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(alert.getId().intValue()))
            .andExpect(jsonPath("$.reference").value(DEFAULT_REFERENCE.toString()))
            .andExpect(jsonPath("$.criticalityLevel").value(DEFAULT_CRITICALITY_LEVEL.toString()))
            .andExpect(jsonPath("$.state").value(DEFAULT_STATE.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.createAt").value(sameInstant(DEFAULT_CREATE_AT)));
    }

    @Test
    @Transactional
    public void getAllAlertsByReferenceIsEqualToSomething() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where reference equals to DEFAULT_REFERENCE
        defaultAlertShouldBeFound("reference.equals=" + DEFAULT_REFERENCE);

        // Get all the alertList where reference equals to UPDATED_REFERENCE
        defaultAlertShouldNotBeFound("reference.equals=" + UPDATED_REFERENCE);
    }

    @Test
    @Transactional
    public void getAllAlertsByReferenceIsInShouldWork() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where reference in DEFAULT_REFERENCE or UPDATED_REFERENCE
        defaultAlertShouldBeFound("reference.in=" + DEFAULT_REFERENCE + "," + UPDATED_REFERENCE);

        // Get all the alertList where reference equals to UPDATED_REFERENCE
        defaultAlertShouldNotBeFound("reference.in=" + UPDATED_REFERENCE);
    }

    @Test
    @Transactional
    public void getAllAlertsByReferenceIsNullOrNotNull() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where reference is not null
        defaultAlertShouldBeFound("reference.specified=true");

        // Get all the alertList where reference is null
        defaultAlertShouldNotBeFound("reference.specified=false");
    }

    @Test
    @Transactional
    public void getAllAlertsByCriticalityLevelIsEqualToSomething() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where criticalityLevel equals to DEFAULT_CRITICALITY_LEVEL
        defaultAlertShouldBeFound("criticalityLevel.equals=" + DEFAULT_CRITICALITY_LEVEL);

        // Get all the alertList where criticalityLevel equals to UPDATED_CRITICALITY_LEVEL
        defaultAlertShouldNotBeFound("criticalityLevel.equals=" + UPDATED_CRITICALITY_LEVEL);
    }

    @Test
    @Transactional
    public void getAllAlertsByCriticalityLevelIsInShouldWork() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where criticalityLevel in DEFAULT_CRITICALITY_LEVEL or UPDATED_CRITICALITY_LEVEL
        defaultAlertShouldBeFound("criticalityLevel.in=" + DEFAULT_CRITICALITY_LEVEL + "," + UPDATED_CRITICALITY_LEVEL);

        // Get all the alertList where criticalityLevel equals to UPDATED_CRITICALITY_LEVEL
        defaultAlertShouldNotBeFound("criticalityLevel.in=" + UPDATED_CRITICALITY_LEVEL);
    }

    @Test
    @Transactional
    public void getAllAlertsByCriticalityLevelIsNullOrNotNull() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where criticalityLevel is not null
        defaultAlertShouldBeFound("criticalityLevel.specified=true");

        // Get all the alertList where criticalityLevel is null
        defaultAlertShouldNotBeFound("criticalityLevel.specified=false");
    }

    @Test
    @Transactional
    public void getAllAlertsByStateIsEqualToSomething() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where state equals to DEFAULT_STATE
        defaultAlertShouldBeFound("state.equals=" + DEFAULT_STATE);

        // Get all the alertList where state equals to UPDATED_STATE
        defaultAlertShouldNotBeFound("state.equals=" + UPDATED_STATE);
    }

    @Test
    @Transactional
    public void getAllAlertsByStateIsInShouldWork() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where state in DEFAULT_STATE or UPDATED_STATE
        defaultAlertShouldBeFound("state.in=" + DEFAULT_STATE + "," + UPDATED_STATE);

        // Get all the alertList where state equals to UPDATED_STATE
        defaultAlertShouldNotBeFound("state.in=" + UPDATED_STATE);
    }

    @Test
    @Transactional
    public void getAllAlertsByStateIsNullOrNotNull() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where state is not null
        defaultAlertShouldBeFound("state.specified=true");

        // Get all the alertList where state is null
        defaultAlertShouldNotBeFound("state.specified=false");
    }

    @Test
    @Transactional
    public void getAllAlertsByDescriptionIsEqualToSomething() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where description equals to DEFAULT_DESCRIPTION
        defaultAlertShouldBeFound("description.equals=" + DEFAULT_DESCRIPTION);

        // Get all the alertList where description equals to UPDATED_DESCRIPTION
        defaultAlertShouldNotBeFound("description.equals=" + UPDATED_DESCRIPTION);
    }

    @Test
    @Transactional
    public void getAllAlertsByDescriptionIsInShouldWork() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where description in DEFAULT_DESCRIPTION or UPDATED_DESCRIPTION
        defaultAlertShouldBeFound("description.in=" + DEFAULT_DESCRIPTION + "," + UPDATED_DESCRIPTION);

        // Get all the alertList where description equals to UPDATED_DESCRIPTION
        defaultAlertShouldNotBeFound("description.in=" + UPDATED_DESCRIPTION);
    }

    @Test
    @Transactional
    public void getAllAlertsByDescriptionIsNullOrNotNull() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where description is not null
        defaultAlertShouldBeFound("description.specified=true");

        // Get all the alertList where description is null
        defaultAlertShouldNotBeFound("description.specified=false");
    }

    @Test
    @Transactional
    public void getAllAlertsByCreateAtIsEqualToSomething() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where createAt equals to DEFAULT_CREATE_AT
        defaultAlertShouldBeFound("createAt.equals=" + DEFAULT_CREATE_AT);

        // Get all the alertList where createAt equals to UPDATED_CREATE_AT
        defaultAlertShouldNotBeFound("createAt.equals=" + UPDATED_CREATE_AT);
    }

    @Test
    @Transactional
    public void getAllAlertsByCreateAtIsInShouldWork() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where createAt in DEFAULT_CREATE_AT or UPDATED_CREATE_AT
        defaultAlertShouldBeFound("createAt.in=" + DEFAULT_CREATE_AT + "," + UPDATED_CREATE_AT);

        // Get all the alertList where createAt equals to UPDATED_CREATE_AT
        defaultAlertShouldNotBeFound("createAt.in=" + UPDATED_CREATE_AT);
    }

    @Test
    @Transactional
    public void getAllAlertsByCreateAtIsNullOrNotNull() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where createAt is not null
        defaultAlertShouldBeFound("createAt.specified=true");

        // Get all the alertList where createAt is null
        defaultAlertShouldNotBeFound("createAt.specified=false");
    }

    @Test
    @Transactional
    public void getAllAlertsByCreateAtIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where createAt greater than or equals to DEFAULT_CREATE_AT
        defaultAlertShouldBeFound("createAt.greaterOrEqualThan=" + DEFAULT_CREATE_AT);

        // Get all the alertList where createAt greater than or equals to UPDATED_CREATE_AT
        defaultAlertShouldNotBeFound("createAt.greaterOrEqualThan=" + UPDATED_CREATE_AT);
    }

    @Test
    @Transactional
    public void getAllAlertsByCreateAtIsLessThanSomething() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);

        // Get all the alertList where createAt less than or equals to DEFAULT_CREATE_AT
        defaultAlertShouldNotBeFound("createAt.lessThan=" + DEFAULT_CREATE_AT);

        // Get all the alertList where createAt less than or equals to UPDATED_CREATE_AT
        defaultAlertShouldBeFound("createAt.lessThan=" + UPDATED_CREATE_AT);
    }


    @Test
    @Transactional
    @Ignore
    public void getAllAlertsByDeviceIsEqualToSomething() throws Exception {
        // Initialize the database
        Device device = DeviceResourceIntTest.createEntity(em);
        em.persist(device);
        em.flush();
        alert.setDevice(device);
        alertRepository.saveAndFlush(alert);
        Long deviceId = device.getId();

        // Get all the alertList where device equals to deviceId
        defaultAlertShouldBeFound("deviceId.equals=" + deviceId);

        // Get all the alertList where device equals to deviceId + 1
        defaultAlertShouldNotBeFound("deviceId.equals=" + (deviceId + 1));
    }

    /**
     * Executes the search, and checks that the default entity is returned
     */
    private void defaultAlertShouldBeFound(String filter) throws Exception {
        restAlertMockMvc.perform(get("/api/alerts?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(alert.getId().intValue())))
            .andExpect(jsonPath("$.[*].reference").value(hasItem(DEFAULT_REFERENCE.toString())))
            .andExpect(jsonPath("$.[*].criticalityLevel").value(hasItem(DEFAULT_CRITICALITY_LEVEL.toString())))
            .andExpect(jsonPath("$.[*].state").value(hasItem(DEFAULT_STATE.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].createAt").value(hasItem(sameInstant(DEFAULT_CREATE_AT))));
    }

    /**
     * Executes the search, and checks that the default entity is not returned
     */
    private void defaultAlertShouldNotBeFound(String filter) throws Exception {
        restAlertMockMvc.perform(get("/api/alerts?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());
    }


    @Test
    @Transactional
    public void getNonExistingAlert() throws Exception {
        // Get the alert
        restAlertMockMvc.perform(get("/api/alerts/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void shouldUpdateAlert() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);
        int databaseSizeBeforeUpdate = alertRepository.findAll().size();

        // Update the alert
        Alert updatedAlert = alertRepository.findById(alert.getId()).get();
        // Disconnect from session so that the updates on updatedAlert are not directly saved in db
        em.detach(updatedAlert);
        updatedAlert
            .reference(UPDATED_REFERENCE)
            .criticalityLevel(UPDATED_CRITICALITY_LEVEL)
            .state(UPDATED_STATE)
            .description(UPDATED_DESCRIPTION)
            .createAt(UPDATED_CREATE_AT);
        AlertDTO alertDTO = alertMapper.toDto(updatedAlert);

        restAlertExtMockMvc.perform(put("/api/alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(alertDTO)))
            .andExpect(status().isOk());

        // Validate the Alert in the database
        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeUpdate);
        Alert testAlert = alertList.get(alertList.size() - 1);
        assertThat(testAlert.getReference()).isEqualTo(DEFAULT_REFERENCE);
        assertThat(testAlert.getCriticalityLevel()).isEqualTo(DEFAULT_CRITICALITY_LEVEL);
        assertThat(testAlert.getState()).isEqualTo(UPDATED_STATE);
        assertThat(testAlert.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testAlert.getCreateAt()).isEqualTo(UPDATED_CREATE_AT);
    }

    @Test
    @Transactional
    public void updateNonExistingAlert() throws Exception {
        int databaseSizeBeforeUpdate = alertRepository.findAll().size();

        // Create the Alert
        AlertDTO alertDTO = alertMapper.toDto(alert);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restAlertExtMockMvc.perform(put("/api/alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(alertDTO)))
            .andExpect(status().isCreated());

        // Validate the Alert in the database
        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteAlert() throws Exception {
        // Initialize the database
        alertRepository.saveAndFlush(alert);
        int databaseSizeBeforeDelete = alertRepository.findAll().size();

        // Get the alert
        restAlertMockMvc.perform(delete("/api/alerts/{id}", alert.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Alert> alertList = alertRepository.findAll();
        assertThat(alertList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Alert.class);
        Alert alert1 = new Alert();
        alert1.setId(1L);
        Alert alert2 = new Alert();
        alert2.setId(alert1.getId());
        assertThat(alert1).isEqualTo(alert2);
        alert2.setId(2L);
        assertThat(alert1).isNotEqualTo(alert2);
        alert1.setId(null);
        assertThat(alert1).isNotEqualTo(alert2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(AlertDTO.class);
        AlertDTO alertDTO1 = new AlertDTO();
        alertDTO1.setId(1L);
        AlertDTO alertDTO2 = new AlertDTO();
        assertThat(alertDTO1).isNotEqualTo(alertDTO2);
        alertDTO2.setId(alertDTO1.getId());
        assertThat(alertDTO1).isEqualTo(alertDTO2);
        alertDTO2.setId(2L);
        assertThat(alertDTO1).isNotEqualTo(alertDTO2);
        alertDTO1.setId(null);
        assertThat(alertDTO1).isNotEqualTo(alertDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(alertMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(alertMapper.fromId(null)).isNull();
    }
}

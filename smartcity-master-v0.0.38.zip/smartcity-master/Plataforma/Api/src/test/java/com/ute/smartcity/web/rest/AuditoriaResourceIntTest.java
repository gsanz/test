package com.ute.smartcity.web.rest;

import com.ute.smartcity.SmartcityApp;

import com.ute.smartcity.domain.Auditoria;
import com.ute.smartcity.repository.AuditoriaRepository;
import com.ute.smartcity.service.AuditoriaService;
import com.ute.smartcity.service.dto.AuditoriaDTO;
import com.ute.smartcity.service.mapper.AuditoriaMapper;
import com.ute.smartcity.web.rest.errors.ExceptionTranslator;
import com.ute.smartcity.service.dto.AuditoriaCriteria;
import com.ute.smartcity.service.AuditoriaQueryService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;


import static com.ute.smartcity.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.ute.smartcity.domain.enumeration.TipoCambio;
/**
 * Test class for the AuditoriaResource REST controller.
 *
 * @see AuditoriaResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmartcityApp.class)
public class AuditoriaResourceIntTest {

    private static final String DEFAULT_ENTITY_NAME = "AAAAAAAAAA";
    private static final String UPDATED_ENTITY_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_USUARIO_LOGIN = "AAAAAAAAAA";
    private static final String UPDATED_USUARIO_LOGIN = "BBBBBBBBBB";

    private static final TipoCambio DEFAULT_TIPO_CAMBIO = TipoCambio.ALTA;
    private static final TipoCambio UPDATED_TIPO_CAMBIO = TipoCambio.BAJA;

    private static final Instant DEFAULT_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final Integer DEFAULT_ENTITY_ID = 1;
    private static final Integer UPDATED_ENTITY_ID = 2;

    @Autowired
    private AuditoriaRepository auditoriaRepository;

    @Autowired
    private AuditoriaMapper auditoriaMapper;

    @Autowired
    private AuditoriaService auditoriaService;

    @Autowired
    private AuditoriaQueryService auditoriaQueryService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restAuditoriaMockMvc;

    private Auditoria auditoria;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final AuditoriaResource auditoriaResource = new AuditoriaResource(auditoriaService, auditoriaQueryService);
        this.restAuditoriaMockMvc = MockMvcBuilders.standaloneSetup(auditoriaResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Auditoria createEntity(EntityManager em) {
        Auditoria auditoria = new Auditoria()
            .entityName(DEFAULT_ENTITY_NAME)
            .usuarioLogin(DEFAULT_USUARIO_LOGIN)
            .tipoCambio(DEFAULT_TIPO_CAMBIO)
            .date(DEFAULT_DATE)
            .entityId(DEFAULT_ENTITY_ID);
        return auditoria;
    }

    @Before
    public void initTest() {
        auditoria = createEntity(em);
    }

    @Test
    @Transactional
    public void createAuditoria() throws Exception {
        int databaseSizeBeforeCreate = auditoriaRepository.findAll().size();

        // Create the Auditoria
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(auditoria);
        restAuditoriaMockMvc.perform(post("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isCreated());

        // Validate the Auditoria in the database
        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeCreate + 1);
        Auditoria testAuditoria = auditoriaList.get(auditoriaList.size() - 1);
        assertThat(testAuditoria.getEntityName()).isEqualTo(DEFAULT_ENTITY_NAME);
        assertThat(testAuditoria.getUsuarioLogin()).isEqualTo(DEFAULT_USUARIO_LOGIN);
        assertThat(testAuditoria.getTipoCambio()).isEqualTo(DEFAULT_TIPO_CAMBIO);
        assertThat(testAuditoria.getDate()).isEqualTo(DEFAULT_DATE);
        assertThat(testAuditoria.getEntityId()).isEqualTo(DEFAULT_ENTITY_ID);
    }

    @Test
    @Transactional
    public void createAuditoriaWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = auditoriaRepository.findAll().size();

        // Create the Auditoria with an existing ID
        auditoria.setId(1L);
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(auditoria);

        // An entity with an existing ID cannot be created, so this API call must fail
        restAuditoriaMockMvc.perform(post("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Auditoria in the database
        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void checkEntityNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditoriaRepository.findAll().size();
        // set the field null
        auditoria.setEntityName(null);

        // Create the Auditoria, which fails.
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(auditoria);

        restAuditoriaMockMvc.perform(post("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isBadRequest());

        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkUsuarioLoginIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditoriaRepository.findAll().size();
        // set the field null
        auditoria.setUsuarioLogin(null);

        // Create the Auditoria, which fails.
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(auditoria);

        restAuditoriaMockMvc.perform(post("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isBadRequest());

        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTipoCambioIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditoriaRepository.findAll().size();
        // set the field null
        auditoria.setTipoCambio(null);

        // Create the Auditoria, which fails.
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(auditoria);

        restAuditoriaMockMvc.perform(post("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isBadRequest());

        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = auditoriaRepository.findAll().size();
        // set the field null
        auditoria.setDate(null);

        // Create the Auditoria, which fails.
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(auditoria);

        restAuditoriaMockMvc.perform(post("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isBadRequest());

        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllAuditorias() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList
        restAuditoriaMockMvc.perform(get("/api/auditorias?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(auditoria.getId().intValue())))
            .andExpect(jsonPath("$.[*].entityName").value(hasItem(DEFAULT_ENTITY_NAME.toString())))
            .andExpect(jsonPath("$.[*].usuarioLogin").value(hasItem(DEFAULT_USUARIO_LOGIN.toString())))
            .andExpect(jsonPath("$.[*].tipoCambio").value(hasItem(DEFAULT_TIPO_CAMBIO.toString())))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].entityId").value(hasItem(DEFAULT_ENTITY_ID)));
    }
    
    @Test
    @Transactional
    public void getAuditoria() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get the auditoria
        restAuditoriaMockMvc.perform(get("/api/auditorias/{id}", auditoria.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(auditoria.getId().intValue()))
            .andExpect(jsonPath("$.entityName").value(DEFAULT_ENTITY_NAME.toString()))
            .andExpect(jsonPath("$.usuarioLogin").value(DEFAULT_USUARIO_LOGIN.toString()))
            .andExpect(jsonPath("$.tipoCambio").value(DEFAULT_TIPO_CAMBIO.toString()))
            .andExpect(jsonPath("$.date").value(DEFAULT_DATE.toString()))
            .andExpect(jsonPath("$.entityId").value(DEFAULT_ENTITY_ID));
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityNameIsEqualToSomething() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityName equals to DEFAULT_ENTITY_NAME
        defaultAuditoriaShouldBeFound("entityName.equals=" + DEFAULT_ENTITY_NAME);

        // Get all the auditoriaList where entityName equals to UPDATED_ENTITY_NAME
        defaultAuditoriaShouldNotBeFound("entityName.equals=" + UPDATED_ENTITY_NAME);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityNameIsInShouldWork() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityName in DEFAULT_ENTITY_NAME or UPDATED_ENTITY_NAME
        defaultAuditoriaShouldBeFound("entityName.in=" + DEFAULT_ENTITY_NAME + "," + UPDATED_ENTITY_NAME);

        // Get all the auditoriaList where entityName equals to UPDATED_ENTITY_NAME
        defaultAuditoriaShouldNotBeFound("entityName.in=" + UPDATED_ENTITY_NAME);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityName is not null
        defaultAuditoriaShouldBeFound("entityName.specified=true");

        // Get all the auditoriaList where entityName is null
        defaultAuditoriaShouldNotBeFound("entityName.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditoriasByUsuarioLoginIsEqualToSomething() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where usuarioLogin equals to DEFAULT_USUARIO_LOGIN
        defaultAuditoriaShouldBeFound("usuarioLogin.equals=" + DEFAULT_USUARIO_LOGIN);

        // Get all the auditoriaList where usuarioLogin equals to UPDATED_USUARIO_LOGIN
        defaultAuditoriaShouldNotBeFound("usuarioLogin.equals=" + UPDATED_USUARIO_LOGIN);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByUsuarioLoginIsInShouldWork() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where usuarioLogin in DEFAULT_USUARIO_LOGIN or UPDATED_USUARIO_LOGIN
        defaultAuditoriaShouldBeFound("usuarioLogin.in=" + DEFAULT_USUARIO_LOGIN + "," + UPDATED_USUARIO_LOGIN);

        // Get all the auditoriaList where usuarioLogin equals to UPDATED_USUARIO_LOGIN
        defaultAuditoriaShouldNotBeFound("usuarioLogin.in=" + UPDATED_USUARIO_LOGIN);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByUsuarioLoginIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where usuarioLogin is not null
        defaultAuditoriaShouldBeFound("usuarioLogin.specified=true");

        // Get all the auditoriaList where usuarioLogin is null
        defaultAuditoriaShouldNotBeFound("usuarioLogin.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditoriasByTipoCambioIsEqualToSomething() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where tipoCambio equals to DEFAULT_TIPO_CAMBIO
        defaultAuditoriaShouldBeFound("tipoCambio.equals=" + DEFAULT_TIPO_CAMBIO);

        // Get all the auditoriaList where tipoCambio equals to UPDATED_TIPO_CAMBIO
        defaultAuditoriaShouldNotBeFound("tipoCambio.equals=" + UPDATED_TIPO_CAMBIO);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByTipoCambioIsInShouldWork() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where tipoCambio in DEFAULT_TIPO_CAMBIO or UPDATED_TIPO_CAMBIO
        defaultAuditoriaShouldBeFound("tipoCambio.in=" + DEFAULT_TIPO_CAMBIO + "," + UPDATED_TIPO_CAMBIO);

        // Get all the auditoriaList where tipoCambio equals to UPDATED_TIPO_CAMBIO
        defaultAuditoriaShouldNotBeFound("tipoCambio.in=" + UPDATED_TIPO_CAMBIO);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByTipoCambioIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where tipoCambio is not null
        defaultAuditoriaShouldBeFound("tipoCambio.specified=true");

        // Get all the auditoriaList where tipoCambio is null
        defaultAuditoriaShouldNotBeFound("tipoCambio.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditoriasByDateIsEqualToSomething() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where date equals to DEFAULT_DATE
        defaultAuditoriaShouldBeFound("date.equals=" + DEFAULT_DATE);

        // Get all the auditoriaList where date equals to UPDATED_DATE
        defaultAuditoriaShouldNotBeFound("date.equals=" + UPDATED_DATE);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByDateIsInShouldWork() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where date in DEFAULT_DATE or UPDATED_DATE
        defaultAuditoriaShouldBeFound("date.in=" + DEFAULT_DATE + "," + UPDATED_DATE);

        // Get all the auditoriaList where date equals to UPDATED_DATE
        defaultAuditoriaShouldNotBeFound("date.in=" + UPDATED_DATE);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByDateIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where date is not null
        defaultAuditoriaShouldBeFound("date.specified=true");

        // Get all the auditoriaList where date is null
        defaultAuditoriaShouldNotBeFound("date.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityIdIsEqualToSomething() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityId equals to DEFAULT_ENTITY_ID
        defaultAuditoriaShouldBeFound("entityId.equals=" + DEFAULT_ENTITY_ID);

        // Get all the auditoriaList where entityId equals to UPDATED_ENTITY_ID
        defaultAuditoriaShouldNotBeFound("entityId.equals=" + UPDATED_ENTITY_ID);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityIdIsInShouldWork() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityId in DEFAULT_ENTITY_ID or UPDATED_ENTITY_ID
        defaultAuditoriaShouldBeFound("entityId.in=" + DEFAULT_ENTITY_ID + "," + UPDATED_ENTITY_ID);

        // Get all the auditoriaList where entityId equals to UPDATED_ENTITY_ID
        defaultAuditoriaShouldNotBeFound("entityId.in=" + UPDATED_ENTITY_ID);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityIdIsNullOrNotNull() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityId is not null
        defaultAuditoriaShouldBeFound("entityId.specified=true");

        // Get all the auditoriaList where entityId is null
        defaultAuditoriaShouldNotBeFound("entityId.specified=false");
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityIdIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityId greater than or equals to DEFAULT_ENTITY_ID
        defaultAuditoriaShouldBeFound("entityId.greaterOrEqualThan=" + DEFAULT_ENTITY_ID);

        // Get all the auditoriaList where entityId greater than or equals to UPDATED_ENTITY_ID
        defaultAuditoriaShouldNotBeFound("entityId.greaterOrEqualThan=" + UPDATED_ENTITY_ID);
    }

    @Test
    @Transactional
    public void getAllAuditoriasByEntityIdIsLessThanSomething() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        // Get all the auditoriaList where entityId less than or equals to DEFAULT_ENTITY_ID
        defaultAuditoriaShouldNotBeFound("entityId.lessThan=" + DEFAULT_ENTITY_ID);

        // Get all the auditoriaList where entityId less than or equals to UPDATED_ENTITY_ID
        defaultAuditoriaShouldBeFound("entityId.lessThan=" + UPDATED_ENTITY_ID);
    }

    /**
     * Executes the search, and checks that the default entity is returned
     */
    private void defaultAuditoriaShouldBeFound(String filter) throws Exception {
        restAuditoriaMockMvc.perform(get("/api/auditorias?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(auditoria.getId().intValue())))
            .andExpect(jsonPath("$.[*].entityName").value(hasItem(DEFAULT_ENTITY_NAME.toString())))
            .andExpect(jsonPath("$.[*].usuarioLogin").value(hasItem(DEFAULT_USUARIO_LOGIN.toString())))
            .andExpect(jsonPath("$.[*].tipoCambio").value(hasItem(DEFAULT_TIPO_CAMBIO.toString())))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].entityId").value(hasItem(DEFAULT_ENTITY_ID)));

        // Check, that the count call also returns 1
        restAuditoriaMockMvc.perform(get("/api/auditorias/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(content().string("1"));
    }

    /**
     * Executes the search, and checks that the default entity is not returned
     */
    private void defaultAuditoriaShouldNotBeFound(String filter) throws Exception {
        restAuditoriaMockMvc.perform(get("/api/auditorias?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());

        // Check, that the count call also returns 0
        restAuditoriaMockMvc.perform(get("/api/auditorias/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(content().string("0"));
    }


    @Test
    @Transactional
    public void getNonExistingAuditoria() throws Exception {
        // Get the auditoria
        restAuditoriaMockMvc.perform(get("/api/auditorias/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateAuditoria() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        int databaseSizeBeforeUpdate = auditoriaRepository.findAll().size();

        // Update the auditoria
        Auditoria updatedAuditoria = auditoriaRepository.findById(auditoria.getId()).get();
        // Disconnect from session so that the updates on updatedAuditoria are not directly saved in db
        em.detach(updatedAuditoria);
        updatedAuditoria
            .entityName(UPDATED_ENTITY_NAME)
            .usuarioLogin(UPDATED_USUARIO_LOGIN)
            .tipoCambio(UPDATED_TIPO_CAMBIO)
            .date(UPDATED_DATE)
            .entityId(UPDATED_ENTITY_ID);
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(updatedAuditoria);

        restAuditoriaMockMvc.perform(put("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isOk());

        // Validate the Auditoria in the database
        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeUpdate);
        Auditoria testAuditoria = auditoriaList.get(auditoriaList.size() - 1);
        assertThat(testAuditoria.getEntityName()).isEqualTo(UPDATED_ENTITY_NAME);
        assertThat(testAuditoria.getUsuarioLogin()).isEqualTo(UPDATED_USUARIO_LOGIN);
        assertThat(testAuditoria.getTipoCambio()).isEqualTo(UPDATED_TIPO_CAMBIO);
        assertThat(testAuditoria.getDate()).isEqualTo(UPDATED_DATE);
        assertThat(testAuditoria.getEntityId()).isEqualTo(UPDATED_ENTITY_ID);
    }

    @Test
    @Transactional
    public void updateNonExistingAuditoria() throws Exception {
        int databaseSizeBeforeUpdate = auditoriaRepository.findAll().size();

        // Create the Auditoria
        AuditoriaDTO auditoriaDTO = auditoriaMapper.toDto(auditoria);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAuditoriaMockMvc.perform(put("/api/auditorias")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(auditoriaDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Auditoria in the database
        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteAuditoria() throws Exception {
        // Initialize the database
        auditoriaRepository.saveAndFlush(auditoria);

        int databaseSizeBeforeDelete = auditoriaRepository.findAll().size();

        // Get the auditoria
        restAuditoriaMockMvc.perform(delete("/api/auditorias/{id}", auditoria.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Auditoria> auditoriaList = auditoriaRepository.findAll();
        assertThat(auditoriaList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Auditoria.class);
        Auditoria auditoria1 = new Auditoria();
        auditoria1.setId(1L);
        Auditoria auditoria2 = new Auditoria();
        auditoria2.setId(auditoria1.getId());
        assertThat(auditoria1).isEqualTo(auditoria2);
        auditoria2.setId(2L);
        assertThat(auditoria1).isNotEqualTo(auditoria2);
        auditoria1.setId(null);
        assertThat(auditoria1).isNotEqualTo(auditoria2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(AuditoriaDTO.class);
        AuditoriaDTO auditoriaDTO1 = new AuditoriaDTO();
        auditoriaDTO1.setId(1L);
        AuditoriaDTO auditoriaDTO2 = new AuditoriaDTO();
        assertThat(auditoriaDTO1).isNotEqualTo(auditoriaDTO2);
        auditoriaDTO2.setId(auditoriaDTO1.getId());
        assertThat(auditoriaDTO1).isEqualTo(auditoriaDTO2);
        auditoriaDTO2.setId(2L);
        assertThat(auditoriaDTO1).isNotEqualTo(auditoriaDTO2);
        auditoriaDTO1.setId(null);
        assertThat(auditoriaDTO1).isNotEqualTo(auditoriaDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(auditoriaMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(auditoriaMapper.fromId(null)).isNull();
    }
}

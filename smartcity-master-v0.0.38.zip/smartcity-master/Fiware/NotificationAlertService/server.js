var express = require("express"),
    app = express(),
    bodyParser = require("body-parser"),
    methodOverride = require("method-override");


var rp = require('request-promise-native');
const config = require('./config');

//
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(methodOverride());


var router = express.Router();



router.get('/', function(req, res) {
    res.send("Hello World!");
});
router.get('/version', function(req, res) {
    const result = {
        version: "0.0.4"
    }
    res.send(result);
});
router.post('/', function(req, res) {
    console.log('Recibido....', req.body)
    let options = {
        method: 'POST',
        json: true,
        uri: config.smartcity.authenticate_endpoint,
        body: {
            username: config.smartcity.username,
            password: config.smartcity.password
        }
    }
    rp(options)
        .then(function(parsedBody) {
            // Authentication succeeded..
            var token = parsedBody.id_token;

            //parseamos alert
            var alert = {
                id: null,
             //   reference: req.body.rule,
				reference: req.body.id,
                criticalityLevel: req.body.level,
                state: "OPEN",
                description: JSON.stringify(req.body),
                message: JSON.stringify(req.body),
                deviceReference: req.body.id,
				rule: req.body.rule
            }
            let optionsAlert = {
                headers: {
                    Authorization: "Bearer " + token
                },
                method: 'POST',
                json: true,
                uri: config.smartcity.alerts_endpoint,
                body: alert
            }


            rp(optionsAlert)
                .then(function(parsedBody) {
                    console.log("options:", optionsAlert);
                    res.send(parsedBody);
                }).catch(function(err) {
                    // alert failed...
                    console.log(err);
                    res.status(err.statusCode).send(err.message);
                });

        })
        .catch(function(err) {
            // Authentication failed...
            console.log(err);
            res.status(err.statusCode).send(err.message);
        });


});
app.use(router);

let port = config.app.port || 3000;
app.set('port', port);
app.listen(port, function() {
    console.log("Node server running on http://localhost:", port);
});
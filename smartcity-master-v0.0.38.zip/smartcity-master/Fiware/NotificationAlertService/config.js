const config = {};

function toBoolean(env, defaultValue) {
    return env !== undefined ? env.toLowerCase() === 'true' : defaultValue;
}



config.smartcity = {
    host: process.env.SMARTCITY_HOST || 'localhost',
    port: process.env.SMARTCITY_PORT || 8000,
    authenticate_endpoint: process.env.SMARTCITY_AUTHENTICATE_ENDPOINT || 'http://localhost:8000/api/authenticate',
    alerts_endpoint: process.env.SMARTCITY_ALERTS_ENDPOINT || 'http://localhost:8000/api/alerts',
    username: process.env.SMARTCITY_USERNAME || 'admin',
    password: process.env.SMARTCITY_PASSWORD || 'admin',
};

config.app = {
    host: process.env.APP_HOST || 'www.nunsys.com',
    port: process.env.APP_PORT || '3000',
};

// in seconds
config.cache_time = 300;

module.exports = config;